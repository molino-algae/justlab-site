CREATE TABLE `poll_groups` (
	`root_id` text PRIMARY KEY NOT NULL,
	`active_room_id` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`root_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`active_room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `poll_runs` (
	`room_id` text PRIMARY KEY NOT NULL,
	`root_id` text NOT NULL,
	`previous_room_id` text,
	`request_id` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`root_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`previous_room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `poll_request_once` ON `poll_runs` (`root_id`,`request_id`);--> statement-breakpoint
CREATE INDEX `poll_runs_root_idx` ON `poll_runs` (`root_id`,`created_at`);