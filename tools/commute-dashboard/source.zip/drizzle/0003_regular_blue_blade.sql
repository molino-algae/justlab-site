ALTER TABLE `response_records` ADD `trip_count` integer;--> statement-breakpoint
ALTER TABLE `responses` ADD `trip_count` integer;