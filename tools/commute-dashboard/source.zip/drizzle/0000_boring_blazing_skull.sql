CREATE TABLE `classrooms` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`admin_hash` text NOT NULL,
	`open` integer DEFAULT true NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `responses` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`token_hash` text NOT NULL,
	`campus_days` integer NOT NULL,
	`distance_km` real NOT NULL,
	`modes` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `response_per_device_room` ON `responses` (`room_id`,`token_hash`);--> statement-breakpoint
CREATE INDEX `responses_room_idx` ON `responses` (`room_id`);