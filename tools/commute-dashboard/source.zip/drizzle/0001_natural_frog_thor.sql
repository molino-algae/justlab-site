CREATE TABLE `response_records` (
	`id` text PRIMARY KEY NOT NULL,
	`room_id` text NOT NULL,
	`token_hash` text NOT NULL,
	`collection_date` text NOT NULL,
	`campus_days` integer NOT NULL,
	`distance_km` real NOT NULL,
	`modes` text NOT NULL,
	`footprint_json` text NOT NULL,
	`scenario_id` text NOT NULL,
	`scenario_json` text NOT NULL,
	`source` text DEFAULT 'daily' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`room_id`) REFERENCES `classrooms`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_response_per_collection_day` ON `response_records` (`room_id`,`collection_date`,`token_hash`);--> statement-breakpoint
CREATE INDEX `records_room_date_idx` ON `response_records` (`room_id`,`collection_date`);