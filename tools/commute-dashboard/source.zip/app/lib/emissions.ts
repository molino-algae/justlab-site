import type { CommuteAnswer, ModeKey } from "./commute";

// Frozen ADEME source snapshot, consulted 2 November 2026:
// https://github.com/incubateur-ademe/impactco2/blob/db0e80a605e3b3fe5c49bde3bceabced4b179656/src/data/categories/deplacement.ts
// Gasoline compact/medium car: usage 0.1380123725556303 + manufacture 0.03169565217391306.
// Carpool allocation follows the official total-occupant denominator; bus is already per passenger.
const CAR = 0.1380123725556303 + 0.03169565217391306;
type Factor = { key: ModeKey; label: string; kgPerKm: number | null; note?: string };

export const EMISSION_SCENARIO = {
  id: "ademe-fr-2026-11-02-gasoline-journeys-v2",
  label: "Referência ADEME · França",
  region: "França · cenário didático, não uma média da frota brasileira",
  scope: "Estimativa do deslocamento: fabricação e uso dos veículos, incluindo a cadeia do combustível. Infraestrutura e alimentação não incluídas.",
  sourceUrl: "https://impactco2.fr/outils/transport",
  dataUrl: "https://github.com/incubateur-ademe/impactco2/blob/db0e80a605e3b3fe5c49bde3bceabced4b179656/src/data/categories/deplacement.ts",
  notes: [
    "Fatores fixados em 02/11/2026. São referências francesas para comparação em aula; o veículo, combustível e lotação reais podem alterar o resultado.",
    "Carro e caronas: carro médio a gasolina. Nas caronas, o fator do veículo é dividido pelo total de ocupantes, incluindo quem dirige.",
    "Ônibus: fator por passageiro-km; a ocupação média já está incorporada. Não dividimos novamente pela lotação.",
    "Uber/táxi: aproximação de um carro de referência com um passageiro pagante. O motorista não entra como segundo passageiro; trajetos vazios e espera não são incluídos.",
    "Moto: referência de até 250 cm³. Bicicleta inclui a fabricação; caminhada não recebe emissões neste limite de cálculo. A alimentação adicional não é estimada.",
    "Outro/combinado não tem fator definido. Quando usado, mostramos um subtotal parcial e a fração da distância coberta, sem atribuir emissão zero ao trecho desconhecido.",
    "Média por pessoa = soma das estimativas semanais ÷ todas as respostas, incluindo zero dias. Média por trajeto = estimativa semanal ÷ trajetos de ida ou volta. As respostas antigas por dias conservam seu modelo de ida e volta. Quando há trechos sem fator, o total e a média da turma são parciais.",
  ],
  factors: [
    { key: "car", label: "Carro médio a gasolina, sozinho", kgPerKm: CAR },
    { key: "bus", label: "Ônibus", kgPerKm: 0.00892 + 0.1135 },
    { key: "uber", label: "Uber / táxi · aproximação por carro", kgPerKm: CAR, note: "1 passageiro pagante; sem trajetos vazios" },
    { key: "bike", label: "Bicicleta mecânica", kgPerKm: 0.00017 },
    { key: "carpool2", label: "Carona +1 · 2 pessoas no total", kgPerKm: CAR / 2 },
    { key: "carpool3", label: "Carona +2 · 3 pessoas no total", kgPerKm: CAR / 3 },
    { key: "carpool4", label: "Carona +3 · 4 pessoas no total", kgPerKm: CAR / 4 },
    { key: "carpool5", label: "Carona +4 · 5 pessoas no total", kgPerKm: CAR / 5 },
    { key: "walk", label: "A pé", kgPerKm: 0 },
    { key: "motorcycle", label: "Moto até 250 cm³", kgPerKm: 0.0342 + 0.053 },
    { key: "other", label: "Outro / combinado", kgPerKm: null },
  ] as Factor[],
};

export type Footprint = {
  weeklyKg: number;
  perCampusDayKg: number | null;
  perTripKg?: number | null;
  totalKm: number;
  coveredKm: number;
  coverage: number;
  complete: boolean;
  unestimatedKm: number;
  byMode: { key: ModeKey; label: string; km: number; kg: number | null; kgPerKm: number | null }[];
};

export function estimateFootprint(answer: CommuteAnswer): Footprint {
  const byMode = EMISSION_SCENARIO.factors.map(factor => {
    const km = answer.distanceKm * (answer.modes[factor.key] ?? 0) * (answer.tripCount === undefined ? 2 : 1);
    return { key: factor.key, label: factor.label, km, kg: factor.kgPerKm === null ? null : km * factor.kgPerKm, kgPerKm: factor.kgPerKm };
  });
  const totalKm = byMode.reduce((sum, mode) => sum + mode.km, 0);
  const unestimatedKm = byMode.reduce((sum, mode) => sum + (mode.kg === null ? mode.km : 0), 0);
  const coveredKm = totalKm - unestimatedKm;
  const weeklyKg = byMode.reduce((sum, mode) => sum + (mode.kg ?? 0), 0);
  const tripCount = answer.tripCount ?? answer.campusDays * 2;
  return { weeklyKg, perCampusDayKg: answer.tripCount === undefined && answer.campusDays > 0 ? weeklyKg / answer.campusDays : null, perTripKg: tripCount > 0 ? weeklyKg / tripCount : null, totalKm, coveredKm, unestimatedKm, complete: unestimatedKm === 0, coverage: totalKm > 0 ? coveredKm / totalKm : 1, byMode };
}

export function summarizeFootprints(answers: CommuteAnswer[]) {
  const estimates = answers.map(estimateFootprint);
  const weeklyKg = estimates.reduce((sum, estimate) => sum + estimate.weeklyKg, 0);
  const totalKm = estimates.reduce((sum, estimate) => sum + estimate.totalKm, 0);
  const unestimatedKm = estimates.reduce((sum, estimate) => sum + estimate.unestimatedKm, 0);
  const campusDays = answers.reduce((sum, answer) => sum + answer.campusDays, 0);
  return {
    weeklyKg,
    averageWeeklyKg: answers.length ? weeklyKg / answers.length : 0,
    perCampusDayKg: answers.every(a => a.tripCount === undefined) && campusDays > 0 ? weeklyKg / campusDays : null,
    complete: unestimatedKm === 0,
    coverage: totalKm > 0 ? (totalKm - unestimatedKm) / totalKm : 1,
    unestimatedKm,
    unestimatedRespondents: estimates.filter(estimate => !estimate.complete).length,
    byMode: EMISSION_SCENARIO.factors.map((factor, i) => ({ key: factor.key, label: factor.label, km: estimates.reduce((sum, estimate) => sum + estimate.byMode[i].km, 0), kg: factor.kgPerKm === null ? null : estimates.reduce((sum, estimate) => sum + (estimate.byMode[i].kg ?? 0), 0) })),
    scenarioId: EMISSION_SCENARIO.id,
  };
}
