import { database } from "./server";
import { EMISSION_SCENARIO, estimateFootprint, type Footprint } from "./emissions";
import { localCollectionDate, mergeHistory, type HistoryAnswer } from "./history";
import type { ModeCounts } from "./commute";

export type LegacyRow = { id: string; token_hash: string; campus_days: number; distance_km: number; modes: string; created_at: string; updated_at: string };
export type RecordRow = LegacyRow & { collection_date: string; footprint_json: string; scenario_id: string; source: string };
export function legacyAnswer(row: LegacyRow): HistoryAnswer {
  const answer = { campusDays: row.campus_days, distanceKm: row.distance_km, modes: JSON.parse(row.modes) as ModeCounts };
  return { ...answer, id: row.id, tokenHash: row.token_hash, collectionDate: localCollectionDate(new Date(row.updated_at)), footprint: estimateFootprint(answer), scenarioId: EMISSION_SCENARIO.id, createdAt: row.created_at, updatedAt: row.updated_at, source: "legacy" };
}
export function savedAnswer(row: RecordRow): HistoryAnswer {
  return { id: row.id, tokenHash: row.token_hash, collectionDate: row.collection_date, campusDays: row.campus_days, distanceKm: row.distance_km, modes: JSON.parse(row.modes) as ModeCounts, footprint: JSON.parse(row.footprint_json) as Footprint, scenarioId: row.scenario_id, createdAt: row.created_at, updatedAt: row.updated_at, source: row.source === "legacy" ? "legacy" : "daily" };
}
export async function roomRecords(roomId: string, date?: string) {
  const db = database();
  const journal = await db.prepare(`SELECT id,token_hash,collection_date,campus_days,distance_km,modes,footprint_json,scenario_id,source,created_at,updated_at FROM response_records WHERE room_id=?${date ? " AND collection_date=?" : ""}`).bind(...(date ? [roomId, date] : [roomId])).all<RecordRow>();
  const latest = await db.prepare("SELECT id,token_hash,campus_days,distance_km,modes,created_at,updated_at FROM responses WHERE room_id=?").bind(roomId).all<LegacyRow>();
  return mergeHistory(journal.results.map(savedAnswer), latest.results.map(legacyAnswer).filter(answer => !date || answer.collectionDate === date));
}
export const RECORD_COLUMNS = "id,room_id,token_hash,collection_date,campus_days,distance_km,modes,footprint_json,scenario_id,scenario_json,source,created_at,updated_at";
export function archiveStatement(roomId: string, answer: HistoryAnswer, requireOpen = false) {
  return database().prepare(`INSERT OR IGNORE INTO response_records (${RECORD_COLUMNS}) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM classrooms WHERE id=?${requireOpen ? " AND open=1" : ""})`).bind(answer.id, roomId, answer.tokenHash, answer.collectionDate, answer.campusDays, answer.distanceKm, JSON.stringify(answer.modes), JSON.stringify(answer.footprint), answer.scenarioId, JSON.stringify(EMISSION_SCENARIO), answer.source, answer.createdAt, answer.updatedAt, roomId);
}
/** Explicit, idempotent data import; schema migrations contain no application data. */
export async function importLegacy(roomId: string) {
  const rows = await database().prepare("SELECT id,token_hash,campus_days,distance_km,modes,created_at,updated_at FROM responses WHERE room_id=?").bind(roomId).all<LegacyRow>();
  for (let offset = 0; offset < rows.results.length; offset += 50) await database().batch(rows.results.slice(offset, offset + 50).map(row => archiveStatement(roomId, legacyAnswer(row))));
  return rows.results.length;
}
export async function savedScenario(roomId: string, date: string) {
  const row = await database().prepare("SELECT scenario_json FROM response_records WHERE room_id=? AND collection_date=? ORDER BY created_at LIMIT 1").bind(roomId, date).first<{ scenario_json: string }>();
  return row ? JSON.parse(row.scenario_json) as typeof EMISSION_SCENARIO : EMISSION_SCENARIO;
}
