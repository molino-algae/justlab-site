// Rounded public ADEME/Impact CO2 factors, consulted 4 November 2026.
// Per passenger-km, including manufacture, fuel supply/use and contrail effects.
export const FLIGHT_PROFILES = [
  { id: "short", label: "Voo curto · 300–1.000 km", kgPerPassengerKm: 0.225, sourceUrl: "https://impactco2.fr/outils/transport/avion-courtcourrier" },
  { id: "medium", label: "Voo médio · 1.000–2.000 km", kgPerPassengerKm: 0.185, sourceUrl: "https://impactco2.fr/outils/transport/avion-moyencourrier" },
  { id: "long", label: "Voo longo · mais de 5.000 km", kgPerPassengerKm: 0.178, sourceUrl: "https://impactco2.fr/outils/transport/avion-longcourrier" },
] as const;

export function compareFlight(totalKm: number, commuteKg: number, complete: boolean, profileId = "short") {
  const profile = FLIGHT_PROFILES.find(p => p.id === profileId) || FLIGHT_PROFILES[0];
  const flightKg = totalKm * profile.kgPerPassengerKm;
  return { profile, totalKm, flightKg, commuteKg, differenceKg: complete ? flightKg - commuteKg : null, ratio: complete && commuteKg > 0 ? flightKg / commuteKg : null, complete };
}
