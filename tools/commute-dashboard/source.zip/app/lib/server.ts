import { env } from "cloudflare:workers";
import { InputError } from "./commute";
import { allowedOrigin } from "./origins";

export function database() {
  if (!env.DB) throw new Error("Database unavailable");
  return env.DB;
}
export function json(value: unknown, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}
export function originGuard(request: Request) {
  if (!allowedOrigin(request)) throw new InputError("Acesso não permitido.");
  if (Number(request.headers.get("content-length") || 0) > 8192) throw new InputError("Resposta muito longa.");
}
export async function body(request: Request) {
  originGuard(request);
  const raw = await request.text();
  if (raw.length > 8192) throw new InputError("Resposta muito longa.");
  try { return JSON.parse(raw); } catch { throw new InputError("Resposta inválida."); }
}
export function randomHex() {
  return [...crypto.getRandomValues(new Uint8Array(32))].map(x => x.toString(16).padStart(2, "0")).join("");
}
export async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}
export function roomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return [...crypto.getRandomValues(new Uint8Array(8))].map(x => alphabet[x % alphabet.length]).join("");
}
export type RoomRow = { id: string; title: string; open: number; created_at: string; admin_hash: string };
export async function findRoom(id: string) {
  if (!/^[A-Z2-9]{8}$/.test(id)) return null;
  return database().prepare("SELECT id,title,open,created_at,admin_hash FROM classrooms WHERE id=?").bind(id).first<RoomRow>();
}
export function publicRoom(room: RoomRow) {
  return { id: room.id, title: room.title, open: Boolean(room.open), createdAt: room.created_at };
}
export async function isAdmin(request: Request, room: RoomRow) {
  const raw = request.headers.get("authorization") || "";
  if (!/^Bearer [a-f0-9]{64}$/i.test(raw)) return false;
  return await hash(raw.slice(7)) === room.admin_hash;
}
export async function safely(handler: () => Promise<Response>) {
  try { return await handler(); }
  catch (error) {
    if (error instanceof InputError) return json({ error: error.message }, 400);
    console.error("Classroom request failed", error instanceof Error ? error.message : "unknown");
    return json({ error: "Não foi possível conectar à turma. Tente novamente em instantes." }, 503);
  }
}
