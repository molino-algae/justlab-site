import type { ModeCounts, ModeKey } from "./commute";
import type { Footprint } from "./emissions";

export type HistoryAnswer = {
  id: string;
  tokenHash: string;
  collectionDate: string;
  campusDays: number;
  distanceKm: number;
  modes: ModeCounts;
  footprint: Footprint;
  scenarioId: string;
  createdAt: string;
  updatedAt: string;
  source: "daily" | "legacy";
};

const collectionFormatter = new Intl.DateTimeFormat("en-US", {
  timeZone: "America/Sao_Paulo",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** Calendar date at the classroom's location, independent of the host timezone. */
export function localCollectionDate(now = new Date()): string {
  if (!Number.isFinite(now.getTime())) throw new RangeError("Invalid collection timestamp");
  const parts = collectionFormatter.formatToParts(now);
  const value = (type: "year" | "month" | "day") => parts.find(part => part.type === type)!.value;
  return `${value("year")}-${value("month")}-${value("day")}`;
}

export function isCollectionDate(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value.startsWith("0000-")) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function answerKey(answer: HistoryAnswer): string {
  if (!isCollectionDate(answer.collectionDate)) throw new RangeError("Invalid collection date");
  return JSON.stringify([answer.collectionDate, answer.tokenHash]);
}

function laterAnswer(a: HistoryAnswer, b: HistoryAnswer): HistoryAnswer {
  const aTime = Date.parse(a.updatedAt), bTime = Date.parse(b.updatedAt);
  if (Number.isFinite(aTime) && Number.isFinite(bTime) && aTime !== bTime) return aTime > bTime ? a : b;
  if (a.updatedAt !== b.updatedAt) return a.updatedAt > b.updatedAt ? a : b;
  return a.id >= b.id ? a : b;
}

/** A journal record takes precedence over a virtual legacy row for the same day/person. */
export function mergeHistory(daily: HistoryAnswer[], legacy: HistoryAnswer[]): HistoryAnswer[] {
  const older = new Map<string, HistoryAnswer>();
  const recorded = new Map<string, HistoryAnswer>();
  for (const answer of legacy) {
    const key = answerKey(answer), current = older.get(key);
    older.set(key, current ? laterAnswer(current, answer) : answer);
  }
  for (const answer of daily) {
    const key = answerKey(answer), current = recorded.get(key);
    recorded.set(key, current ? laterAnswer(current, answer) : answer);
  }
  for (const [key, answer] of recorded) older.set(key, answer);
  return [...older.values()].sort((a, b) => a.collectionDate.localeCompare(b.collectionDate) || a.tokenHash.localeCompare(b.tokenHash));
}

/** Aggregate saved snapshots only: never run today's factors over historical answers. */
export function summarizeHistory(answers: HistoryAnswer[]) {
  let weeklyKg = 0, totalKm = 0, coveredKm = 0, unestimatedKm = 0, campusDays = 0;
  const modeTotals = new Map<ModeKey, { key: ModeKey; label: string; km: number; kg: number | null }>();
  const scenarios = new Set<string>();
  for (const answer of answers) {
    const saved = answer.footprint;
    weeklyKg += saved.weeklyKg;
    totalKm += saved.totalKm;
    coveredKm += saved.coveredKm;
    unestimatedKm += saved.unestimatedKm;
    campusDays += answer.campusDays;
    scenarios.add(answer.scenarioId);
    for (const mode of saved.byMode) {
      const current = modeTotals.get(mode.key);
      if (!current) modeTotals.set(mode.key, { key: mode.key, label: mode.label, km: mode.km, kg: mode.kg });
      else {
        current.km += mode.km;
        current.kg = current.kg === null || mode.kg === null ? null : current.kg + mode.kg;
      }
    }
  }
  const scenarioIds = [...scenarios].sort();
  return {
    weeklyKg,
    averageWeeklyKg: answers.length ? weeklyKg / answers.length : 0,
    perCampusDayKg: campusDays > 0 ? weeklyKg / campusDays : null,
    complete: answers.every(answer => answer.footprint.complete),
    coverage: totalKm > 0 ? coveredKm / totalKm : 1,
    unestimatedKm,
    unestimatedRespondents: answers.filter(answer => !answer.footprint.complete).length,
    byMode: [...modeTotals.values()],
    scenarioId: scenarioIds.length === 1 ? scenarioIds[0] : scenarioIds.length ? "mixed" : "",
  };
}

/** Input is the result of mergeHistory; missing collection days remain absent. */
export function buildHistorySeries(answers: HistoryAnswer[]) {
  const groups = new Map<string, HistoryAnswer[]>();
  for (const answer of answers) {
    answerKey(answer);
    const group = groups.get(answer.collectionDate) ?? [];
    group.push(answer);
    groups.set(answer.collectionDate, group);
  }
  return [...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([date, group]) => ({
    date,
    respondents: group.length,
    campusDays: group.reduce((sum, answer) => sum + answer.campusDays, 0),
    weeklyKm: group.reduce((sum, answer) => sum + answer.footprint.totalKm, 0),
    emissions: summarizeHistory(group),
    scenarioIds: [...new Set(group.map(answer => answer.scenarioId))].sort(),
  }));
}
