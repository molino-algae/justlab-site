export const PUBLIC_FRONTEND = "https://molino-algae.github.io/justlab-site/commute/";
export const GITHUB_ORIGIN = "https://molino-algae.github.io";
export function allowedOrigin(request: Request) {
  const origin = request.headers.get("Origin");
  return !origin || origin === new URL(request.url).origin || origin === GITHUB_ORIGIN;
}
export function corsPreflight(request: Request): Response | null {
  if (!new URL(request.url).pathname.startsWith("/api/")) return null;
  if (!allowedOrigin(request)) return new Response("Origin not allowed", { status: 403 });
  if (request.method !== "OPTIONS") return null;
  const headers = new Headers({ "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization", "Access-Control-Max-Age": "600", "Vary": "Origin" });
  const origin = request.headers.get("Origin");
  if (origin) headers.set("Access-Control-Allow-Origin", origin);
  return new Response(null, { status: 204, headers });
}
export function withCors(request: Request, response: Response) {
  if (!new URL(request.url).pathname.startsWith("/api/")) return response;
  const origin = request.headers.get("Origin");
  if (!origin || !allowedOrigin(request)) return response;
  const headers = new Headers(response.headers);
  headers.set("Access-Control-Allow-Origin", origin);
  headers.set("Access-Control-Expose-Headers", "Content-Disposition");
  headers.append("Vary", "Origin");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}
