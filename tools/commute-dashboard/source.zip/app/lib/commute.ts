export const MODES = [
  { key: "car", label: "Carro, sem carona" },
  { key: "bus", label: "Ônibus" },
  { key: "uber", label: "Uber / táxi" },
  { key: "bike", label: "Bicicleta" },
  { key: "carpool2", label: "Carona +1 pessoa" },
  { key: "carpool3", label: "Carona +2 pessoas" },
  { key: "carpool4", label: "Carona +3 pessoas" },
  { key: "carpool5", label: "Carona +4 pessoas" },
  { key: "walk", label: "A pé" },
  { key: "motorcycle", label: "Moto" },
  { key: "other", label: "Outro / combinado" },
] as const;

export type ModeKey = (typeof MODES)[number]["key"];
export type ModeCounts = Record<ModeKey, number>;
export type CommuteAnswer = { campusDays: number; distanceKm: number; modes: ModeCounts };
export type StoredAnswer = CommuteAnswer & { updatedAt: string };
export class InputError extends Error {}

export function validateAnswer(input: unknown): CommuteAnswer & { token: string } {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new InputError("Resposta inválida.");
  const p = input as Record<string, unknown>;
  if (typeof p.token !== "string" || !/^[a-f0-9]{64}$/i.test(p.token)) throw new InputError("Não foi possível identificar esta resposta. Recarregue a página.");
  if (typeof p.campusDays !== "number" || !Number.isInteger(p.campusDays) || p.campusDays < 0 || p.campusDays > 7) throw new InputError("Escolha de 0 a 7 dias de presença por semana.");
  if (typeof p.distanceKm !== "number" || !Number.isFinite(p.distanceKm) || p.distanceKm < 0 || p.distanceKm > 500 || (p.campusDays > 0 && p.distanceKm < 0.1)) throw new InputError("Informe uma distância de ida entre 0,1 e 500 km.");
  if (!p.modes || typeof p.modes !== "object" || Array.isArray(p.modes)) throw new InputError("Informe os dias de cada transporte.");
  const raw = p.modes as Record<string, unknown>;
  if (Object.keys(raw).some(key => !MODES.some(mode => mode.key === key))) throw new InputError("Há um transporte não reconhecido na resposta.");
  const modes = Object.fromEntries(MODES.map(mode => [mode.key, raw[mode.key] ?? 0])) as ModeCounts;
  for (const day of Object.values(modes)) {
    if (typeof day !== "number" || !Number.isInteger(day) || day < 0 || day > 7) throw new InputError("Os dias de transporte devem ser números inteiros entre 0 e 7.");
  }
  if (Object.values(modes).reduce((sum, day) => sum + day, 0) !== p.campusDays) throw new InputError("A soma dos transportes deve ser igual aos dias de presença na universidade.");
  return { token: p.token.toLowerCase(), campusDays: p.campusDays, distanceKm: Math.round(p.distanceKm * 100) / 100, modes };
}

export function summarize(answers: StoredAnswer[]) {
  const campusDays = answers.reduce((sum, a) => sum + a.campusDays, 0);
  const commuting = answers.filter(a => a.campusDays > 0);
  const round = (x: number) => Math.round(x * 10) / 10;
  const modeDays = MODES.map(({ key, label }) => {
    const days = answers.reduce((sum, a) => sum + a.modes[key], 0);
    return { key, label, days, km: round(answers.reduce((sum, a) => sum + 2 * a.distanceKm * a.modes[key], 0)), people: answers.filter(a => a.modes[key] > 0).length, share: campusDays ? days / campusDays : 0 };
  });
  const occupancy = [2, 3, 4, 5].map(occupants => ({ occupants, days: modeDays.find(m => m.key === `carpool${occupants}`)!.days }));
  const limits = [2, 5, 10, 20, Infinity];
  const labels = ["Até 2 km", "2–5 km", "5–10 km", "10–20 km", "Mais de 20 km"];
  return {
    respondents: answers.length,
    campusDays,
    weeklyKm: round(answers.reduce((sum, a) => sum + 2 * a.distanceKm * a.campusDays, 0)),
    meanDistanceKm: commuting.length ? round(commuting.reduce((sum, a) => sum + a.distanceKm, 0) / commuting.length) : 0,
    carpoolDays: occupancy.reduce((sum, o) => sum + o.days, 0),
    modeDays,
    occupancy,
    attendanceDistribution: Array.from({ length: 8 }, (_, days) => ({ days, count: answers.filter(a => a.campusDays === days).length })),
    distanceDistribution: labels.map((label, i) => ({ label, count: commuting.filter(a => a.distanceKm <= limits[i] && (i === 0 || a.distanceKm > limits[i - 1])).length })),
    updatedAt: answers.reduce<string | null>((latest, a) => !latest || a.updatedAt > latest ? a.updatedAt : latest, null),
  };
}

export function csvEscape(value: unknown) {
  const safe = String(value ?? "").replace(/^[=+@\-\t\r]/, "'$&");
  return `"${safe.replace(/"/g, '""')}"`;
}
