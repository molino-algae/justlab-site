export const GITHUB_APP_URL = "https://molino-algae.github.io/justlab-site/commute/";
export const SERVICE_URL = "https://justlab-live-commute.pairedmalt.chatgpt.site";
function onGithub() { return typeof window !== "undefined" && window.location.hostname === "molino-algae.github.io"; }
export function apiUrl(path: string) { return `${onGithub() ? SERVICE_URL : ""}${path}`; }
export function appUrl(params: Record<string, string | undefined> = {}) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) if (value !== undefined && value !== "") query.set(key, value);
  return `${onGithub() ? "/justlab-site/commute/" : "/"}${query.size ? `?${query}` : ""}`;
}
