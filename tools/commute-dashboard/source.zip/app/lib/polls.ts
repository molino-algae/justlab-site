import { database, findRoom, publicRoom, type RoomRow } from "./server";
import { buildHistorySeries } from "./history";
import { roomRecords } from "./records";

export async function pollRoot(id: string) {
  const run = await database().prepare("SELECT root_id FROM poll_runs WHERE room_id=?").bind(id).first<{ root_id: string }>();
  return findRoom(run?.root_id || id);
}

export async function activePoll(root: RoomRow) {
  const group = await database().prepare("SELECT active_room_id FROM poll_groups WHERE root_id=?").bind(root.id).first<{ active_room_id: string }>();
  return group ? (await findRoom(group.active_room_id)) || root : root;
}

type Totals = { room_id: string; date: string; respondents: number; weekly_kg: number; total_km: number; covered_km: number; complete: number };
export async function pollArchive(root: RoomRow) {
  const db = database();
  const [rooms, totals, initial] = await Promise.all([
    db.prepare("SELECT c.id,c.title,c.open,c.created_at FROM classrooms c JOIN poll_runs p ON p.room_id=c.id WHERE p.root_id=? ORDER BY p.created_at,c.id").bind(root.id).all<Omit<RoomRow, "admin_hash">>(),
    db.prepare(`SELECT room_id,collection_date AS date,COUNT(*) AS respondents,
      SUM(json_extract(footprint_json,'$.weeklyKg')) AS weekly_kg,
      SUM(json_extract(footprint_json,'$.totalKm')) AS total_km,
      SUM(json_extract(footprint_json,'$.coveredKm')) AS covered_km,
      MIN(CASE WHEN json_extract(footprint_json,'$.complete')=1 THEN 1 ELSE 0 END) AS complete
      FROM response_records WHERE room_id IN (SELECT room_id FROM poll_runs WHERE root_id=?)
      GROUP BY room_id,collection_date ORDER BY collection_date`).bind(root.id).all<Totals>(),
    roomRecords(root.id),
  ]);
  const first = buildHistorySeries(initial).map(s => ({ date: s.date, respondents: s.respondents, weeklyKg: s.emissions.weeklyKg, averageWeeklyKg: s.emissions.averageWeeklyKg, coverage: s.emissions.coverage, complete: s.emissions.complete }));
  return [
    { room: publicRoom(root), number: 1, collections: first },
    ...rooms.results.map((room, i) => ({ room: { id: room.id, title: room.title, open: Boolean(room.open), createdAt: room.created_at }, number: i + 2,
      collections: totals.results.filter(t => t.room_id === room.id).map(t => ({ date: t.date, respondents: t.respondents, weeklyKg: t.weekly_kg, averageWeeklyKg: t.respondents ? t.weekly_kg / t.respondents : 0, coverage: t.total_km ? t.covered_km / t.total_km : 1, complete: Boolean(t.complete) })) })),
  ];
}
