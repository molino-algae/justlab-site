import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Como chegamos ao campus? · JUSTLAB", description: "Uma atividade anônima e ao vivo sobre os trajetos da turma, mobilidade e sustentabilidade.", robots: { index: false, follow: false } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt-BR"><body>{children}</body></html>; }
