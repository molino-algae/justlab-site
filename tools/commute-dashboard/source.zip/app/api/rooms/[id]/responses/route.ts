import { body, database, findRoom, hash, json, randomHex, safely } from "../../../../lib/server";
import { validateAnswer } from "../../../../lib/commute";
import { estimateFootprint, EMISSION_SCENARIO } from "../../../../lib/emissions";
import { localCollectionDate } from "../../../../lib/history";
import { archiveStatement, legacyAnswer, RECORD_COLUMNS, type LegacyRow } from "../../../../lib/records";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada. Confira o código ou o QR code." }, 404);
    if (!room.open) return json({ error: "As respostas desta turma estão encerradas." }, 409);
    const input = await body(request), collectionDate = localCollectionDate();
    if (input?.collectionDate !== collectionDate) return json({ error: "Há uma nova coleta disponível. Atualize o formulário para responder na data de hoje." }, 409);
    const answer = validateAnswer(input), tokenHash = await hash(answer.token), db = database();
    const newId = randomHex(), time = new Date().toISOString();
    const footprint = estimateFootprint(answer);
    const previous = await db.prepare("SELECT id,token_hash,campus_days,distance_km,modes,created_at,updated_at FROM responses WHERE room_id=? AND token_hash=?").bind(id, tokenHash).first<LegacyRow>();
    const journal = db.prepare(`INSERT INTO response_records (${RECORD_COLUMNS})
      SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? FROM classrooms WHERE id=? AND open=1
      ON CONFLICT(room_id,collection_date,token_hash) DO UPDATE SET campus_days=excluded.campus_days,distance_km=excluded.distance_km,modes=excluded.modes,footprint_json=excluded.footprint_json,scenario_id=excluded.scenario_id,scenario_json=excluded.scenario_json,source='daily',updated_at=excluded.updated_at
      WHERE EXISTS(SELECT 1 FROM classrooms WHERE id=? AND open=1) RETURNING id`).bind(newId, id, tokenHash, collectionDate, answer.campusDays, answer.distanceKm, JSON.stringify(answer.modes), JSON.stringify(footprint), EMISSION_SCENARIO.id, JSON.stringify(EMISSION_SCENARIO), "daily", time, time, id, id);
    const latest = db.prepare(`INSERT INTO responses (id,room_id,token_hash,campus_days,distance_km,modes,created_at,updated_at)
      SELECT ?,?,?,?,?,?,?,? FROM classrooms WHERE id=? AND open=1
      ON CONFLICT(room_id,token_hash) DO UPDATE SET campus_days=excluded.campus_days,distance_km=excluded.distance_km,modes=excluded.modes,updated_at=excluded.updated_at
      WHERE EXISTS(SELECT 1 FROM classrooms WHERE id=? AND open=1)
      RETURNING id`).bind(newId, id, tokenHash, answer.campusDays, answer.distanceKm, JSON.stringify(answer.modes), time, time, id, id);
    const operations = [...(previous ? [archiveStatement(id, legacyAnswer(previous), true)] : []), journal, latest];
    const results = await db.batch<{ id: string }>(operations);
    const saved = results[previous ? 1 : 0].results[0];
    if (!saved) return json({ error: "As respostas desta turma foram encerradas." }, 409);
    return json({ ok: true, updated: saved.id !== newId, collectionDate, footprint });
  });
}
