import { body, database, findRoom, isAdmin, json, publicRoom, roomCode, safely } from "../../../../lib/server";
import { InputError } from "../../../../lib/commute";
import { importLegacy } from "../../../../lib/records";
import { activePoll, pollArchive, pollRoot } from "../../../../lib/polls";

type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, root = await pollRoot(id);
    if (!root) return json({ error: "Turma não encontrada." }, 404);
    const admin = await isAdmin(request, root);
    if (request.headers.has("authorization") && !admin) return json({ error: "Use o link de gestão da turma para abrir os controles do professor." }, 403);
    const current = await activePoll(root);
    return json({ rootId: root.id, current: publicRoom(current), canManage: admin, ...(admin ? { archive: await pollArchive(root) } : {}) });
  });
}

export async function POST(request: Request, context: Context) {
  return safely(async () => {
    const data = await body(request);
    const { id } = await context.params, root = await pollRoot(id);
    if (!root) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, root)) return json({ error: "Somente o professor pode salvar e iniciar uma enquete." }, 403);
    if (typeof data?.requestId !== "string" || !/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(data.requestId)) throw new InputError("Atualize a página antes de iniciar uma enquete.");
    if (typeof data?.expectedRoomId !== "string" || !/^[A-Z2-9]{8}$/.test(data.expectedRoomId)) throw new InputError("Atualize a enquete antes de continuar.");
    if (data.title !== undefined && (typeof data.title !== "string" || !data.title.trim() || data.title.trim().length > 80)) throw new InputError("Use um nome com até 80 caracteres.");
    const db = database();
    const repeat = await db.prepare("SELECT room_id FROM poll_runs WHERE root_id=? AND request_id=?").bind(root.id, data.requestId).first<{ room_id: string }>();
    if (repeat) return json({ created: false, rootId: root.id, room: publicRoom((await findRoom(repeat.room_id))!), current: publicRoom(await activePoll(root)) });
    const previous = await activePoll(root);
    if (previous.id !== data.expectedRoomId) return json({ error: "Outra enquete já foi iniciada. O painel foi atualizado; confira antes de continuar." }, 409);
    // Preserve legacy latest rows using the same explicit import as the history view.
    await importLegacy(previous.id);
    const newId = roomCode(), now = new Date().toISOString(), title = data.title?.trim() || root.title;
    await db.batch([
      db.prepare("INSERT OR IGNORE INTO poll_groups (root_id,active_room_id,updated_at) VALUES (?,?,?)").bind(root.id, root.id, now),
      db.prepare(`INSERT INTO classrooms (id,title,admin_hash,open,created_at)
        SELECT ?,?,?,1,? FROM poll_groups WHERE root_id=? AND active_room_id=?
        AND NOT EXISTS(SELECT 1 FROM poll_runs WHERE root_id=? AND request_id=?)`).bind(newId, title, root.admin_hash, now, root.id, previous.id, root.id, data.requestId),
      db.prepare(`INSERT INTO poll_runs (room_id,root_id,previous_room_id,request_id,created_at)
        SELECT ?,?,?,?,? FROM classrooms c JOIN poll_groups g ON g.root_id=?
        WHERE c.id=? AND c.created_at=? AND c.admin_hash=? AND g.active_room_id=?
        AND NOT EXISTS(SELECT 1 FROM poll_runs WHERE root_id=? AND request_id=?)`).bind(newId, root.id, previous.id, data.requestId, now, root.id, newId, now, root.admin_hash, previous.id, root.id, data.requestId),
      db.prepare(`UPDATE classrooms SET open=0 WHERE id=?
        AND EXISTS(SELECT 1 FROM poll_runs WHERE room_id=? AND root_id=? AND request_id=?)`).bind(previous.id, newId, root.id, data.requestId),
      db.prepare(`UPDATE poll_groups SET active_room_id=?,updated_at=? WHERE root_id=? AND active_room_id=?
        AND EXISTS(SELECT 1 FROM poll_runs WHERE room_id=? AND root_id=? AND request_id=?)`).bind(newId, now, root.id, previous.id, newId, root.id, data.requestId),
    ]);
    const result = await db.prepare("SELECT room_id FROM poll_runs WHERE root_id=? AND request_id=?").bind(root.id, data.requestId).first<{ room_id: string }>();
    if (!result) return json({ error: "Outra enquete já foi iniciada. Atualize o painel e tente novamente." }, 409);
    return json({ created: result.room_id === newId, rootId: root.id, room: publicRoom((await findRoom(result.room_id))!), current: publicRoom(await activePoll(root)) }, result.room_id === newId ? 201 : 200);
  });
}
