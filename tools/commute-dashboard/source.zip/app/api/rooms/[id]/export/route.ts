import { findRoom, isAdmin, json, safely } from "../../../../lib/server";
import { csvEscape, MODES, InputError } from "../../../../lib/commute";
import { isCollectionDate, localCollectionDate } from "../../../../lib/history";
import { roomRecords } from "../../../../lib/records";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, room)) return json({ error: "A exportação está disponível no link de gerenciamento." }, 403);
    const query = new URL(request.url).searchParams, all = query.get("all") === "true", today = localCollectionDate(), date = query.get("date") || today;
    if (!isCollectionDate(date) || date > today) throw new InputError("Escolha uma data de coleta válida.");
    const answers = await roomRecords(id, all ? undefined : date);
    const rounded = (value: number) => Math.round(value * 1e6) / 1e6;
    const rows: unknown[][] = [["Resposta", "Data da coleta", "Dias no campus por semana", "Distância de ida (km)", "Distância semanal estimada (passageiro-km)", ...MODES.map(m => `${m.label} (dias/semana)`), "CO2e estimado (kg/semana)", "CO2e médio por dia presencial (kg)", "Estimativa completa", "Distância coberta pelo cálculo (%)", "Cenário de cálculo", "Origem do registro", "Enviada em", "Atualizada em"], ...answers.map((a, i) => [i + 1, a.collectionDate, a.campusDays, a.distanceKm, rounded(a.footprint.totalKm), ...MODES.map(m => a.modes[m.key] ?? 0), rounded(a.footprint.weeklyKg), a.footprint.perCampusDayKg === null ? "" : rounded(a.footprint.perCampusDayKg), a.footprint.complete ? "Sim" : "Parcial", rounded(a.footprint.coverage * 100), a.scenarioId, a.source === "legacy" ? "Legado: última resposta preservada" : "Coleta diária", a.createdAt, a.updatedAt])];
    return new Response("\ufeff" + rows.map(row => row.map(csvEscape).join(";")).join("\r\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="deslocamento-${id}-${all ? "historico" : date}.csv"`, "Cache-Control": "no-store" } });
  });
}
