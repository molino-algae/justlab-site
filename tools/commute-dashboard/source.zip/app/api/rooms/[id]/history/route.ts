import { body, findRoom, isAdmin, json, safely } from "../../../../lib/server";
import { buildHistorySeries, localCollectionDate } from "../../../../lib/history";
import { importLegacy, roomRecords } from "../../../../lib/records";
type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, room)) return json({ error: "O histórico está disponível no link de gerenciamento." }, 403);
    return json({ today: localCollectionDate(), timeZone: "America/Sao_Paulo", series: buildHistorySeries(await roomRecords(id)) });
  });
}
export async function POST(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, room)) return json({ error: "Use o link de gerenciamento desta turma." }, 403);
    await body(request);
    return json({ ok: true, inspected: await importLegacy(id) });
  });
}
