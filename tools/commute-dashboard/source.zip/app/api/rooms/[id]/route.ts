import { body, database, findRoom, isAdmin, json, publicRoom, safely } from "../../../lib/server";
import { InputError, summarize, type ModeCounts } from "../../../lib/commute";
import { isCollectionDate, localCollectionDate, summarizeHistory } from "../../../lib/history";
import { roomRecords, savedScenario } from "../../../lib/records";

type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada. Confira o código ou o QR code." }, 404);
    const today = localCollectionDate(), date = new URL(request.url).searchParams.get("date") || today;
    if (!isCollectionDate(date) || date > today) throw new InputError("Escolha uma data de coleta válida, até hoje.");
    if (date !== today && !await isAdmin(request, room)) return json({ error: "Use o link de gerenciamento para consultar coletas anteriores." }, 403);
    const answers = await roomRecords(id, date);
    return json({ room: publicRoom(room), collection: { date, today, timeZone: "America/Sao_Paulo", readOnly: date !== today, scenario: await savedScenario(id, date), scenarioIds: [...new Set(answers.map(a => a.scenarioId))] }, stats: { ...summarize(answers), emissions: summarizeHistory(answers) } });
  });
}
export async function PATCH(request: Request, context: Context) {
  return safely(async () => {
    const data = await body(request);
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, room)) return json({ error: "Use o link de gerenciamento desta turma." }, 403);
    if (typeof data?.open !== "boolean") throw new InputError("Escolha abrir ou encerrar as respostas.");
    const changed = await database().prepare(`UPDATE classrooms SET open=? WHERE id=?
      AND (?=0 OR NOT EXISTS(SELECT 1 FROM poll_groups g
        WHERE (g.root_id=? OR g.root_id IN (SELECT root_id FROM poll_runs WHERE room_id=?))
        AND g.active_room_id<>?)) RETURNING id`).bind(data.open ? 1 : 0, id, data.open ? 1 : 0, id, id, id).first<{ id: string }>();
    if (!changed) return json({ error: "Esta enquete já está salva no histórico. Inicie uma nova enquete na apresentação." }, 409);
    return json({ room: publicRoom({ ...room, open: data.open ? 1 : 0 }) });
  });
}
