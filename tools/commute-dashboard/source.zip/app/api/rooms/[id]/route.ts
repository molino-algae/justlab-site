import { body, database, findRoom, isAdmin, json, publicRoom, safely } from "../../../lib/server";
import { InputError, summarize, type ModeCounts } from "../../../lib/commute";
import { isCollectionDate, localCollectionDate, summarizeHistory } from "../../../lib/history";
import { roomRecords, savedScenario } from "../../../lib/records";

type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada. Confira o código ou o QR code." }, 404);
    const today = localCollectionDate(), date = new URL(request.url).searchParams.get("date") || today;
    if (!isCollectionDate(date) || date > today) throw new InputError("Escolha uma data de coleta válida, até hoje.");
    if (date !== today && !await isAdmin(request, room)) return json({ error: "Use o link de gerenciamento para consultar coletas anteriores." }, 403);
    const answers = await roomRecords(id, date);
    return json({ room: publicRoom(room), collection: { date, today, timeZone: "America/Sao_Paulo", readOnly: date !== today, scenario: await savedScenario(id, date), scenarioIds: [...new Set(answers.map(a => a.scenarioId))] }, stats: { ...summarize(answers), emissions: summarizeHistory(answers) } });
  });
}
export async function PATCH(request: Request, context: Context) {
  return safely(async () => {
    const { id } = await context.params, room = await findRoom(id);
    if (!room) return json({ error: "Turma não encontrada." }, 404);
    if (!await isAdmin(request, room)) return json({ error: "Use o link de gerenciamento desta turma." }, 403);
    const data = await body(request);
    if (typeof data?.open !== "boolean") throw new InputError("Escolha abrir ou encerrar as respostas.");
    await database().prepare("UPDATE classrooms SET open=? WHERE id=?").bind(data.open ? 1 : 0, id).run();
    return json({ room: publicRoom({ ...room, open: data.open ? 1 : 0 }) });
  });
}
