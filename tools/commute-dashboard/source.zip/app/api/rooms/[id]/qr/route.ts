import QRCode from "qrcode";
import { findRoom, json, safely } from "../../../../lib/server";
import { PUBLIC_FRONTEND } from "../../../../lib/origins";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  return safely(async () => {
    const { id } = await context.params;
    if (!await findRoom(id)) return json({ error: "Turma não encontrada." }, 404);
    const join = new URL(PUBLIC_FRONTEND);
    join.searchParams.set("room", id);
    const svg = await QRCode.toString(join.href, { type: "svg", errorCorrectionLevel: "M", margin: 3, color: { dark: "#123B2D", light: "#FFFFFF" } });
    return new Response(svg, { headers: { "Content-Type": "image/svg+xml", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
  });
}
