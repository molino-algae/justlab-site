import { body, database, hash, json, publicRoom, randomHex, roomCode, safely } from "../../lib/server";
import { InputError } from "../../lib/commute";

export async function POST(request: Request) {
  return safely(async () => {
    const data = await body(request);
    if (typeof data?.title !== "string" || !data.title.trim() || data.title.trim().length > 80) throw new InputError("Dê um nome à turma, com até 80 caracteres.");
    const id = roomCode(), adminKey = randomHex(), createdAt = new Date().toISOString();
    const row = { id, title: data.title.trim(), open: 1, created_at: createdAt, admin_hash: await hash(adminKey) };
    await database().prepare("INSERT INTO classrooms (id,title,admin_hash,open,created_at) VALUES (?,?,?,1,?)").bind(id, row.title, row.admin_hash, createdAt).run();
    return json({ room: publicRoom(row), adminKey }, 201);
  });
}
