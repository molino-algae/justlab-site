import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import path from "node:path";

const projectRoot = fileURLToPath(new URL(".", import.meta.url));
const outputsRoot = path.resolve(projectRoot, "outputs/github-pages");
const outDir = path.resolve(outputsRoot, "commute");
if (path.relative(outputsRoot, outDir) !== "commute") {
  throw new Error("A saída deve ficar em outputs/github-pages/commute.");
}

export default defineConfig({
  root: path.resolve(projectRoot, "github-client"),
  base: "/justlab-site/commute/",
  plugins: [react()],
  publicDir: path.resolve(projectRoot, "public"),
  resolve: { dedupe: ["react", "react-dom"] },
  // Reuse the existing Tailwind PostCSS configuration, outside the client root.
  css: { postcss: projectRoot },
  build: {
    outDir,
    emptyOutDir: true,
    assetsDir: "assets",
    target: "es2022",
    sourcemap: false,
  },
});
