import React from "react";
import { createRoot } from "react-dom/client";
import App from "../app/page";
import "../app/globals.css";

const root = document.getElementById("root");
if (!root) throw new Error("O ponto de entrada da atividade não foi encontrado.");

createRoot(root).render(<React.StrictMode><App /></React.StrictMode>);
