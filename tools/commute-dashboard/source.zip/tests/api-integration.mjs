import assert from 'node:assert/strict';

const base = new URL(process.env.BASE_URL || 'http://127.0.0.1:5194');
assert.ok(['localhost', '127.0.0.1', '[::1]', '::1'].includes(base.hostname), 'These API tests may run only against a local preview, never production.');
assert.ok(['http:', 'https:'].includes(base.protocol), 'BASE_URL must be an HTTP URL.');
assert.ok(!base.username && !base.password, 'BASE_URL must not contain credentials.');

let checks = 0;
let roomId;
let adminKey;
let finished = false;
let collectionDate;
const tokenA = '1'.repeat(64);
const tokenB = '2'.repeat(64);
const tokenC = '3'.repeat(64);

function verify(condition, message) {
  assert.ok(condition, message);
  checks += 1;
}

async function request(path, { method = 'GET', data, key } = {}) {
  if (method === 'POST' && path.endsWith('/responses')) data = { collectionDate, ...data };
  const headers = {};
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET') headers.Origin = base.origin;
  if (key) headers.Authorization = `Bearer ${key}`;
  return fetch(new URL(path, base), {
    method,
    headers,
    ...(data !== undefined ? { body: JSON.stringify(data) } : {}),
    signal: AbortSignal.timeout(15000),
  });
}

async function jsonRequest(path, options, expectedStatus) {
  const response = await request(path, options);
  verify(response.status === expectedStatus, `${options?.method || 'GET'} ${path}: expected HTTP ${expectedStatus}, received ${response.status}`);
  return { response, data: await response.json() };
}

function assertPublicAggregate(data) {
  verify(data && typeof data === 'object' && data.room && data.stats, 'Public room endpoint must return room metadata and aggregate stats.');
  const forbidden = /^(?:adminKey|adminHash|admin_hash|token|tokenHash|token_hash|responses|answers)$/i;
  const scan = value => {
    if (!value || typeof value !== 'object') return false;
    return Object.entries(value).some(([key, child]) => forbidden.test(key) || scan(child));
  };
  verify(!scan(data), 'Public aggregates must not expose editing tokens, management credentials or individual response lists.');
  const serialized = JSON.stringify(data);
  verify(![adminKey, tokenA, tokenB, tokenC].filter(Boolean).some(secret => serialized.includes(secret)), 'Public aggregates must not contain any submitted secret.');
}

const answerA = { token: tokenA, campusDays: 3, distanceKm: 10, modes: { car: 1, bus: 2 } };
const answerB = { token: tokenB, campusDays: 2, distanceKm: 5, modes: { bike: 2 } };
const editedA = { token: tokenA, campusDays: 5, distanceKm: 10, modes: { car: 2, bus: 3 } };

try {
  const created = await jsonRequest('/api/rooms', {
    method: 'POST', data: { title: `TESTE LOCAL — API ${new Date().toISOString()}` },
  }, 201);
  roomId = created.data.room?.id;
  adminKey = created.data.adminKey;
  verify(typeof roomId === 'string' && /^[A-Z2-9]{8}$/.test(roomId), 'Room creation must return an eight-character classroom code.');
  verify(typeof adminKey === 'string' && /^[a-f0-9]{64}$/.test(adminKey), 'Room creation must return a management key.');
  verify(created.data.room.open === true, 'A new test room must be open.');
  const roomPath = `/api/rooms/${roomId}`;
  const responsePath = `${roomPath}/responses`;
  const initial = await jsonRequest(roomPath, undefined, 200);
  collectionDate = initial.data.collection?.date;
  verify(/^\d{4}-\d{2}-\d{2}$/.test(collectionDate), 'The server must provide the active collection date.');

  const submitted = await Promise.all([answerA, answerB].map(data => jsonRequest(responsePath, { method: 'POST', data }, 200)));
  verify(submitted.every(result => result.data.ok === true && result.data.updated === false), 'Both different-token submissions must create distinct replies.');
  let state = await jsonRequest(roomPath, undefined, 200);
  verify(state.response.headers.get('cache-control')?.includes('no-store'), 'Dashboard results must not be cached.');
  assertPublicAggregate(state.data);
  verify(state.data.stats.respondents === 2, 'Two concurrent distinct tokens must produce two respondents.');
  verify(state.data.stats.campusDays === 5, 'Initial attendance must total five campus days.');
  verify(state.data.stats.weeklyKm === 80, 'Initial return journeys must total 80 passenger-km per week.');

  const edited = await jsonRequest(responsePath, { method: 'POST', data: editedA }, 200);
  verify(edited.data.ok === true && edited.data.updated === true, 'Submitting an existing token must edit its reply.');
  state = await jsonRequest(roomPath, undefined, 200);
  verify(state.data.stats.respondents === 2, 'Editing must not add a respondent.');
  verify(state.data.stats.campusDays === 7, 'Edited attendance must total seven campus days.');
  verify(state.data.stats.weeklyKm === 120, 'Edited return journeys must total 120 passenger-km per week.');
  const modes = Object.fromEntries(state.data.stats.modeDays.map(mode => [mode.key, mode]));
  verify(modes.car.days === 2 && modes.bus.days === 3 && modes.bike.days === 2, 'Mode-day aggregates must reflect the replacement reply.');
  verify(modes.car.km === 40 && modes.bus.km === 60 && modes.bike.km === 20, 'Mode kilometres must use one-way distance × 2 × mode days.');

  await jsonRequest(responsePath, { method: 'POST', data: { ...editedA, campusDays: 4 } }, 400);
  state = await jsonRequest(roomPath, undefined, 200);
  verify(state.data.stats.respondents === 2 && state.data.stats.weeklyKm === 120, 'Rejected totals must leave existing replies unchanged.');
  await jsonRequest(roomPath, { method: 'PATCH', data: { open: false } }, 403);
  await jsonRequest(roomPath, { method: 'PATCH', data: { open: false }, key: 'f'.repeat(64) }, 403);
  await jsonRequest(`${roomPath}/export`, undefined, 403);

  const qr = await request(`${roomPath}/qr`);
  verify(qr.status === 200, 'A classroom QR must be available.');
  verify(qr.headers.get('content-type')?.includes('image/svg+xml'), 'QR endpoint must return SVG content.');
  const qrText = await qr.text();
  verify(/<svg\b/.test(qrText) && /xmlns="http:\/\/www\.w3\.org\/2000\/svg"/.test(qrText) && /<path\b/.test(qrText) && /<\/svg>/.test(qrText), 'QR payload must be a complete SVG with rendered paths.');

  const csvResponse = await request(`${roomPath}/export`, { key: adminKey });
  verify(csvResponse.status === 200, 'Authorized CSV export must succeed.');
  verify(csvResponse.headers.get('content-type')?.includes('text/csv'), 'Export must have a CSV MIME type.');
  const bytes = new Uint8Array(await csvResponse.arrayBuffer());
  verify(bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf, 'CSV must start with a UTF-8 BOM for accented headers.');
  const csv = Buffer.from(bytes).toString('utf8');
  const lines = csv.slice(1).split('\r\n');
  verify(lines.length === 3, 'CSV must contain one header and two anonymous response rows.');
  verify(lines[0].startsWith('"Resposta";') && lines[0].includes('Distância de ida (km)'), 'CSV must contain the expected Portuguese survey headers.');
  verify(lines.every(line => line.split(';').length === 24), 'CSV must contain the dated survey, footprint, model and timestamp columns in every row.');
  verify(!csv.includes(adminKey) && !csv.includes(tokenA) && !csv.includes(tokenB), 'CSV must exclude management and editing secrets.');

  const closed = await jsonRequest(roomPath, { method: 'PATCH', data: { open: false }, key: adminKey }, 200);
  verify(closed.data.room.open === false, 'Authorized management must close the room.');
  await Promise.all([
    editedA,
    { token: tokenC, campusDays: 1, distanceKm: 1, modes: { walk: 1 } },
  ].map(data => jsonRequest(responsePath, { method: 'POST', data }, 409)));
  state = await jsonRequest(roomPath, undefined, 200);
  verify(state.data.room.open === false && state.data.stats.respondents === 2 && state.data.stats.weeklyKm === 120, 'A closed room must reject both edits and new responses without changing aggregates.');

  const reopened = await jsonRequest(roomPath, { method: 'PATCH', data: { open: true }, key: adminKey }, 200);
  verify(reopened.data.room.open === true, 'Authorized management must reopen the room.');
  const sameToken = [
    { token: tokenC, campusDays: 3, distanceKm: 1, modes: { car: 3 } },
    { token: tokenC, campusDays: 4, distanceKm: 2, modes: { bus: 4 } },
  ];
  const concurrentEdits = await Promise.all(sameToken.map(data => jsonRequest(responsePath, { method: 'POST', data }, 200)));
  verify(concurrentEdits.every(result => result.data.ok === true), 'Both same-token concurrent requests must complete.');
  verify(JSON.stringify(concurrentEdits.map(result => result.data.updated).sort()) === '[false,true]', 'Concurrent requests with a new shared token must report one insertion and one edit.');
  state = await jsonRequest(roomPath, undefined, 200);
  assertPublicAggregate(state.data);
  verify(state.data.stats.respondents === 3, 'Concurrent writes for one new token must add exactly one respondent.');
  verify((state.data.stats.campusDays === 10 && state.data.stats.weeklyKm === 126) || (state.data.stats.campusDays === 11 && state.data.stats.weeklyKm === 136), 'The final concurrent result must contain one complete valid answer, with no double counting or partially mixed values.');

  const finalClose = await jsonRequest(roomPath, { method: 'PATCH', data: { open: false }, key: adminKey }, 200);
  verify(finalClose.data.room.open === false, 'The dedicated local test room must be left closed.');
  finished = true;
  console.log(JSON.stringify({ ok: true, checks, room: roomId, respondents: 3, baseUrl: base.origin, testOnly: true }));
} finally {
  if (!finished && roomId && adminKey) {
    try {
      await request(`/api/rooms/${roomId}`, { method: 'PATCH', data: { open: false }, key: adminKey });
    } catch {
      console.error('Could not close the dedicated local API test room after a failed check.');
    }
  }
}
