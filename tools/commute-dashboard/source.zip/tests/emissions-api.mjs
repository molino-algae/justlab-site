import assert from 'node:assert/strict';

const base = new URL(process.env.BASE_URL || 'http://127.0.0.1:5194');
assert.ok(['localhost', '127.0.0.1', '[::1]', '::1'].includes(base.hostname), 'Emission API tests are restricted to local preview, never production.');
assert.ok(['http:', 'https:'].includes(base.protocol), 'BASE_URL must be HTTP or HTTPS.');
assert.ok(!base.username && !base.password, 'BASE_URL must not contain credentials.');

const CAR = 0.16970802472954336, BUS = 0.12242, BIKE = 0.00017;
const MODEL = 'ademe-fr-2026-11-02-gasoline-v1';
let roomId, adminKey, checks = 0;
let collectionDate;
const tokenA = 'a'.repeat(64), tokenB = 'b'.repeat(64), tokenC = 'c'.repeat(64);
const answerA = { token: tokenA, campusDays: 5, distanceKm: 10, modes: { car: 2, bus: 2, bike: 1 } };
const answerB = { token: tokenB, campusDays: 2, distanceKm: 5, modes: { carpool2: 2 } };
const expectedA = 40 * CAR + 40 * BUS + 20 * BIKE;
const expectedB = 20 * CAR / 2;
function verify(value, message) { assert.ok(value, message); checks++; }
function near(actual, expected, message) {
  verify(Number.isFinite(actual) && Math.abs(actual - expected) <= Math.max(1, Math.abs(expected)) * 1e-11, `${message}: ${actual} != ${expected}`);
}
async function request(path, { method = 'GET', data, key } = {}) {
  if (method === 'POST' && path.endsWith('/responses')) data = { collectionDate, ...data };
  const headers = {};
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET') headers.Origin = base.origin;
  if (key) headers.Authorization = `Bearer ${key}`;
  return fetch(new URL(path, base), { method, headers, ...(data !== undefined ? { body: JSON.stringify(data) } : {}), signal: AbortSignal.timeout(15000) });
}
async function json(path, options, status = 200) {
  const result = await request(path, options);
  verify(result.status === status, `${options?.method || 'GET'} ${path}: expected ${status}, got ${result.status}`);
  return result.json();
}
function cell(line) { return line.split(';').map(value => value.replace(/^"|"$/g, '').replace(/""/g, '"')); }

try {
  const created = await json('/api/rooms', { method: 'POST', data: { title: `TESTE LOCAL — CO2e ${new Date().toISOString()}` } }, 201);
  roomId = created.room?.id;
  adminKey = created.adminKey;
  verify(typeof roomId === 'string' && /^[A-Z2-9]{8}$/.test(roomId), 'Creation must return a classroom code.');
  verify(typeof adminKey === 'string' && /^[a-f0-9]{64}$/.test(adminKey), 'Creation must return a management key.');
  const path = `/api/rooms/${roomId}`;
  const initial = await json(path);
  collectionDate = initial.collection?.date;
  verify(/^\d{4}-\d{2}-\d{2}$/.test(collectionDate), 'The active collection date must come from the server.');
  const submitted = await Promise.all([answerA, answerB].map(data => json(`${path}/responses`, { method: 'POST', data })));
  near(submitted[0].footprint.weeklyKg, expectedA, 'Student A weekly footprint');
  near(submitted[0].footprint.perCampusDayKg, expectedA / 5, 'Student A daily average');
  near(submitted[1].footprint.weeklyKg, expectedB, 'Student B shared-car footprint');
  verify(submitted.every(reply => reply.footprint.complete && reply.footprint.coverage === 1), 'Known modes must return complete personal footprints.');

  let state = await json(path);
  verify(state.stats.respondents === 2, 'Two students must be represented.');
  near(state.stats.emissions.weeklyKg, expectedA + expectedB, 'Class weekly sum');
  near(state.stats.emissions.averageWeeklyKg, (expectedA + expectedB) / 2, 'Class per-student weekly mean');
  near(state.stats.emissions.perCampusDayKg, (expectedA + expectedB) / 7, 'Class per-presence-day mean');
  verify(state.stats.emissions.scenarioId === MODEL, 'Dashboard must identify the frozen calculation model.');

  const edited = await json(`${path}/responses`, { method: 'POST', data: { token: tokenA, campusDays: 1, distanceKm: 10, modes: { car: 1 } } });
  verify(edited.updated === true, 'Changing a known token must be an edit.');
  near(edited.footprint.weeklyKg, 20 * CAR, 'Edited individual footprint');
  state = await json(path);
  verify(state.stats.respondents === 2, 'Editing must not duplicate a student.');
  near(state.stats.emissions.weeklyKg, 20 * CAR + expectedB, 'Class sum after replacement');
  near(state.stats.emissions.averageWeeklyKg, (20 * CAR + expectedB) / 2, 'Class mean after replacement');

  const partial = await json(`${path}/responses`, { method: 'POST', data: { token: tokenC, campusDays: 2, distanceKm: 5, modes: { bus: 1, other: 1 } } });
  verify(partial.footprint.complete === false, 'Unknown mode must make the individual estimate partial.');
  verify(partial.footprint.coverage === 0.5 && partial.footprint.unestimatedKm === 10, 'Unknown distance must remain visible.');
  verify(partial.footprint.byMode.find(item => item.key === 'other').kg === null, 'Other must remain unknown rather than zero.');
  near(partial.footprint.weeklyKg, 10 * BUS, 'Partial known subtotal');
  state = await json(path);
  verify(state.stats.respondents === 3, 'The partial response must be retained.');
  verify(state.stats.emissions.complete === false && state.stats.emissions.unestimatedRespondents === 1, 'Class aggregation must propagate partial coverage.');
  near(state.stats.emissions.coverage, 50 / 60, 'Class distance-weighted coverage');
  near(state.stats.emissions.weeklyKg, 20 * CAR + expectedB + 10 * BUS, 'Class known subtotal');
  near(state.stats.emissions.averageWeeklyKg, (20 * CAR + expectedB + 10 * BUS) / 3, 'Partial per-student subtotal uses all responses');

  const exported = await request(`${path}/export`, { key: adminKey });
  verify(exported.status === 200, 'Authorized emission CSV must export.');
  const bytes = new Uint8Array(await exported.arrayBuffer());
  verify(bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf, 'CSV must retain its UTF-8 BOM.');
  const lines = Buffer.from(bytes).toString('utf8').slice(1).split('\r\n');
  verify(lines.length === 4, 'CSV must contain three personal estimates plus its header.');
  const headers = cell(lines[0]), rows = lines.slice(1).map(cell);
  const indexes = Object.fromEntries(headers.map((header, i) => [header, i]));
  for (const header of ['CO2e estimado (kg/semana)', 'CO2e médio por dia presencial (kg)', 'Estimativa completa', 'Distância coberta pelo cálculo (%)', 'Cenário de cálculo']) {
    verify(Number.isInteger(indexes[header]), `CSV must include ${header}.`);
  }
  verify(headers.length === 24 && rows.every(row => row.length === headers.length), 'CSV rows must align with the dated 24-column header.');
  verify(rows.every(row => row[indexes['Cenário de cálculo']] === MODEL), 'Every exported row must retain the model version.');
  const partialRow = rows.find(row => row[indexes['Estimativa completa']] === 'Parcial');
  verify(Boolean(partialRow), 'CSV must identify the incomplete footprint.');
  near(Number(partialRow[indexes['Distância coberta pelo cálculo (%)']]), 50, 'CSV coverage percent');
  near(Number(partialRow[indexes['CO2e estimado (kg/semana)']]), 1.2242, 'CSV partial subtotal');
  verify(!lines.join('').includes(adminKey) && ![tokenA, tokenB, tokenC].some(token => lines.join('').includes(token)), 'Export must not disclose management or editing keys.');

  const closed = await json(path, { method: 'PATCH', data: { open: false }, key: adminKey });
  verify(closed.room.open === false, 'Test room must be closed after verification.');
  await json(`${path}/responses`, { method: 'POST', data: answerA }, 409);
  console.log(JSON.stringify({ ok: true, checks, room: roomId, baseUrl: base.origin, testOnly: true, feature: 'personal-and-class-co2e' }));
} finally {
  if (roomId && adminKey) {
    try { await request(`/api/rooms/${roomId}`, { method: 'PATCH', data: { open: false }, key: adminKey }); }
    catch { console.error('Could not close the dedicated local emissions test room.'); }
  }
}
