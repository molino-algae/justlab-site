import test from 'node:test';
import assert from 'node:assert/strict';
import { MODES, validateAnswer, summarize, csvEscape, InputError } from '../app/lib/commute.ts';

const TOKEN = 'ab'.repeat(32);
const input = (changes = {}) => ({ token: TOKEN, campusDays: 5, distanceKm: 10, modes: { car: 5 }, ...changes });
const stored = (campusDays, distanceKm, modes, updatedAt = '2026-11-02T12:00:00.000Z') => ({
  ...validateAnswer(input({ campusDays, distanceKm, modes })), updatedAt,
});

test('a sparse valid reply is normalized without changing the original input', () => {
  const original = input({ token: TOKEN.toUpperCase(), distanceKm: 4.567, modes: { bus: 3, bike: 2 } });
  const result = validateAnswer(original);
  assert.equal(result.token, TOKEN);
  assert.equal(result.distanceKm, 4.57);
  assert.deepEqual(Object.keys(result.modes), MODES.map(mode => mode.key));
  assert.equal(result.modes.bus, 3);
  assert.equal(result.modes.bike, 2);
  assert.equal(result.modes.car, 0);
  assert.deepEqual(original.modes, { bus: 3, bike: 2 });
});

test('a week with no campus attendance accepts zero distance and no journeys', () => {
  const result = validateAnswer(input({ campusDays: 0, distanceKm: 0, modes: {} }));
  assert.equal(result.campusDays, 0);
  assert.equal(result.distanceKm, 0);
  assert.ok(Object.values(result.modes).every(days => days === 0));
});

test('mode totals must equal attendance, including zero-attendance replies', () => {
  for (const specimen of [
    input({ modes: { car: 2, bus: 2 } }),
    input({ modes: { car: 4, bike: 2 } }),
    input({ campusDays: 0, distanceKm: 0, modes: { car: 1 } }),
  ]) assert.throws(() => validateAnswer(specimen), InputError);
});

test('attendance must be a whole number from zero to seven', () => {
  for (const campusDays of [NaN, Infinity, -1, 2.5, 8, '5', null]) {
    assert.throws(() => validateAnswer(input({ campusDays })), InputError, `attendance: ${String(campusDays)}`);
  }
  assert.equal(validateAnswer(input({ campusDays: 7, modes: { bus: 7 } })).campusDays, 7);
});

test('each mode count must be a finite whole number from zero to seven', () => {
  for (const days of [NaN, Infinity, -1, 0.5, 8, '5', false]) {
    assert.throws(() => validateAnswer(input({ modes: { car: days } })), InputError, `mode days: ${String(days)}`);
  }
});

test('unknown modes are rejected even when their count is zero', () => {
  assert.throws(() => validateAnswer(input({ modes: { car: 5, helicopter: 0 } })), InputError);
});

test('invalid distances cannot enter an otherwise valid reply', () => {
  for (const distanceKm of [NaN, Infinity, -Infinity, -1, 0, 0.09, 500.01, '10', null]) {
    assert.throws(() => validateAnswer(input({ distanceKm })), InputError, `distance: ${String(distanceKm)}`);
  }
  assert.equal(validateAnswer(input({ distanceKm: 0.1 })).distanceKm, 0.1);
  assert.equal(validateAnswer(input({ distanceKm: 500 })).distanceKm, 500);
});

test('malformed reply and mode structures are rejected', () => {
  for (const specimen of [null, undefined, [], 'reply', 42, input({ modes: null }), input({ modes: [] })]) {
    assert.throws(() => validateAnswer(specimen), InputError);
  }
});

test('a reply requires a correctly formed editing token', () => {
  for (const token of [undefined, '', 'a'.repeat(63), 'a'.repeat(65), 'z'.repeat(64), 123]) {
    assert.throws(() => validateAnswer(input({ token })), InputError);
  }
});

test('weekly aggregation uses return distance and mode-days without multiplying occupants', () => {
  const result = summarize([
    stored(5, 10, { car: 2, bus: 2, bike: 1 }),
    stored(3, 2.5, { carpool2: 1, carpool5: 2 }),
    stored(0, 0, {}),
    stored(2, 3, { bus: 1, walk: 1 }, '2026-11-02T13:00:00.000Z'),
  ]);
  assert.equal(result.respondents, 4);
  assert.equal(result.campusDays, 10);
  assert.equal(result.weeklyKm, 127);
  assert.equal(result.meanDistanceKm, 5.2, 'zero-attendance replies do not reduce the commuter distance mean');
  assert.equal(result.updatedAt, '2026-11-02T13:00:00.000Z');

  const modes = Object.fromEntries(result.modeDays.map(mode => [mode.key, mode]));
  assert.deepEqual(['car', 'bus', 'bike', 'carpool2', 'carpool5', 'walk'].map(key => ({
    key, days: modes[key].days, km: modes[key].km, people: modes[key].people, share: modes[key].share,
  })), [
    { key: 'car', days: 2, km: 40, people: 1, share: 0.2 },
    { key: 'bus', days: 3, km: 46, people: 2, share: 0.3 },
    { key: 'bike', days: 1, km: 20, people: 1, share: 0.1 },
    { key: 'carpool2', days: 1, km: 5, people: 1, share: 0.1 },
    { key: 'carpool5', days: 2, km: 10, people: 1, share: 0.2 },
    { key: 'walk', days: 1, km: 6, people: 1, share: 0.1 },
  ]);
  assert.equal(result.modeDays.reduce((sum, mode) => sum + mode.days, 0), result.campusDays);
  assert.equal(result.modeDays.reduce((sum, mode) => sum + mode.km, 0), result.weeklyKm);
  assert.equal(result.carpoolDays, 3);
  assert.deepEqual(result.occupancy, [
    { occupants: 2, days: 1, trips: 2 }, { occupants: 3, days: 0, trips: 0 }, { occupants: 4, days: 0, trips: 0 }, { occupants: 5, days: 2, trips: 4 },
  ]);
});

test('a participant can use multiple modes; people counts are deliberately overlapping', () => {
  const result = summarize([stored(3, 5, { bus: 1, bike: 2 })]);
  assert.equal(result.respondents, 1);
  assert.equal(result.modeDays.find(mode => mode.key === 'bus').people, 1);
  assert.equal(result.modeDays.find(mode => mode.key === 'bike').people, 1);
  assert.equal(result.modeDays.reduce((sum, mode) => sum + mode.people, 0), 2);
  assert.equal(result.modeDays.find(mode => mode.key === 'bus').share, 1 / 3);
});

test('empty data has stable zero totals and complete categories, without NaN values', () => {
  const result = summarize([]);
  assert.equal(result.respondents, 0);
  assert.equal(result.campusDays, 0);
  assert.equal(result.weeklyKm, 0);
  assert.equal(result.meanDistanceKm, 0);
  assert.equal(result.carpoolDays, 0);
  assert.equal(result.updatedAt, null);
  assert.equal(result.modeDays.length, MODES.length);
  assert.ok(result.modeDays.every(mode => mode.days === 0 && mode.km === 0 && mode.people === 0 && mode.share === 0));
  assert.equal(result.attendanceDistribution.length, 8);
  assert.ok(result.attendanceDistribution.every(bin => bin.count === 0));
  assert.equal(result.distanceDistribution.length, 5);
  assert.ok(result.distanceDistribution.every(bin => bin.count === 0));
});

test('distance buckets put boundary values in exactly one category and exclude non-attendees', () => {
  const answers = [2, 5, 10, 20, 20.1].map(km => stored(1, km, { walk: 1 }));
  answers.push(stored(0, 0, {}));
  const result = summarize(answers);
  assert.deepEqual(result.distanceDistribution.map(bin => bin.count), [1, 1, 1, 1, 1]);
  assert.equal(result.attendanceDistribution.find(bin => bin.days === 0).count, 1);
  assert.equal(result.attendanceDistribution.find(bin => bin.days === 1).count, 5);
});

test('CSV cells quote separators, line breaks and embedded quotes safely', () => {
  assert.equal(csvEscape('a,b\n"quoted"'), '"a,b\n""quoted"""');
  assert.equal(csvEscape(null), '""');
  assert.equal(csvEscape(undefined), '""');
  assert.equal(csvEscape(127), '"127"');
});

test('CSV formula-leading cells are neutralized before quoting', () => {
  for (const dangerous of ['=1+1', '+SUM(A1:A2)', '-1+1', '@SUM(A1)', '\t=1', '\r=1']) {
    assert.equal(csvEscape(dangerous), `"'${dangerous}"`);
  }
  assert.equal(csvEscape('bus = 2'), '"bus = 2"');
});
