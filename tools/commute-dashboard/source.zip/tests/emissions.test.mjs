import test from 'node:test';
import assert from 'node:assert/strict';
import { EMISSION_SCENARIO, estimateFootprint, summarizeFootprints } from '../app/lib/emissions.ts';

// Independent expected values from the frozen ADEME source snapshot.
const CAR = 0.16970802472954336;
const BUS = 0.12242;
const BIKE = 0.00017;
const keys = ['car', 'bus', 'uber', 'bike', 'carpool2', 'carpool3', 'carpool4', 'carpool5', 'walk', 'motorcycle', 'other'];
const week = (campusDays, distanceKm, modes = {}) => ({ campusDays, distanceKm, modes: Object.fromEntries(keys.map(key => [key, modes[key] || 0])) });
function near(actual, expected, message) {
  assert.ok(Number.isFinite(actual), `${message || 'result'} must be finite`);
  assert.ok(Math.abs(actual - expected) <= Math.max(1, Math.abs(expected)) * 1e-12, `${message || 'result'}: ${actual} != ${expected}`);
}
const mode = (footprint, key) => footprint.byMode.find(item => item.key === key);

test('the mixed week uses return distance and adds each mode before averaging by campus day', () => {
  const result = estimateFootprint(week(5, 10, { car: 2, bus: 2, bike: 1 }));
  const expected = 40 * CAR + 40 * BUS + 20 * BIKE;
  near(result.weeklyKg, expected, 'weekly kg CO2e');
  near(result.perCampusDayKg, expected / 5, 'kg per campus day');
  assert.equal(result.totalKm, 100);
  assert.equal(result.coveredKm, 100);
  assert.equal(result.unestimatedKm, 0);
  assert.equal(result.complete, true);
  assert.equal(result.coverage, 1);
  assert.equal(mode(result, 'car').km, 40);
  assert.equal(mode(result, 'bus').km, 40);
  assert.equal(mode(result, 'bike').km, 20);
  near(mode(result, 'car').kg, 40 * CAR);
  near(mode(result, 'bus').kg, 40 * BUS);
  near(mode(result, 'bike').kg, 20 * BIKE);
});

test('carpool +1 allocates to two total occupants, including the driver exactly once', () => {
  const result = estimateFootprint(week(1, 10, { carpool2: 1 }));
  near(result.weeklyKg, 20 * CAR / 2);
  near(mode(result, 'carpool2').kgPerKm, CAR / 2);
  assert.equal(result.totalKm, 20, 'Passenger-km for one respondent must not be multiplied by other occupants.');
});

test('carpool +4 allocates to five total occupants rather than four or six', () => {
  const result = estimateFootprint(week(1, 10, { carpool5: 1 }));
  near(result.weeklyKg, 20 * CAR / 5);
  near(mode(result, 'carpool5').kgPerKm, CAR / 5);
});

test('all four carpool sizes share one vehicle factor and keep their distinct denominators', () => {
  for (const occupants of [2, 3, 4, 5]) {
    const result = estimateFootprint(week(2, 3, { [`carpool${occupants}`]: 2 }));
    near(result.weeklyKg, 12 * CAR / occupants, `${occupants} occupants`);
  }
});

test('the bus factor is already per passenger-km and is not divided by occupancy again', () => {
  const result = estimateFootprint(week(4, 5, { bus: 4 }));
  near(result.weeklyKg, 40 * BUS);
  near(mode(result, 'bus').kgPerKm, BUS);
});

test('Uber is an explicit single-paying-passenger car proxy, without counting the paid driver as a commuter', () => {
  const result = estimateFootprint(week(2, 7, { uber: 2 }));
  const solo = estimateFootprint(week(2, 7, { car: 2 }));
  near(result.weeklyKg, 28 * CAR);
  near(result.weeklyKg, solo.weeklyKg);
  assert.match(EMISSION_SCENARIO.factors.find(factor => factor.key === 'uber').note, /1 passageiro/);
});

test('walking is zero within the stated scenario while bicycle manufacture remains positive', () => {
  const walked = estimateFootprint(week(5, 2, { walk: 5 }));
  const cycled = estimateFootprint(week(5, 2, { bike: 5 }));
  assert.equal(walked.weeklyKg, 0);
  assert.equal(walked.complete, true);
  near(cycled.weeklyKg, 20 * BIKE);
  assert.ok(cycled.weeklyKg > 0);
});

test('the motorcycle scenario is explicitly the small-motorcycle factor', () => {
  const result = estimateFootprint(week(3, 10, { motorcycle: 3 }));
  near(result.weeklyKg, 60 * 0.0872);
  assert.match(mode(result, 'motorcycle').label, /250/);
});

test('Other has an unknown mode footprint and leaves a clearly partial known subtotal', () => {
  const result = estimateFootprint(week(2, 10, { car: 1, other: 1 }));
  assert.equal(mode(result, 'other').kg, null);
  assert.equal(mode(result, 'other').kgPerKm, null);
  assert.equal(result.complete, false);
  assert.equal(result.coveredKm, 20);
  assert.equal(result.unestimatedKm, 20);
  assert.equal(result.coverage, 0.5);
  near(result.weeklyKg, 20 * CAR, 'known subtotal');
  near(result.perCampusDayKg, 10 * CAR, 'partial subtotal per campus day');
});

test('an entirely unknown journey is not mislabeled a complete zero-emission journey', () => {
  const result = estimateFootprint(week(2, 5, { other: 2 }));
  assert.equal(result.weeklyKg, 0, 'The numeric known subtotal can be zero while the full estimate remains unavailable.');
  assert.equal(result.complete, false);
  assert.equal(result.coverage, 0);
  assert.equal(result.unestimatedKm, 20);
  assert.equal(mode(result, 'other').kg, null);
});

test('zero attendance has no weekly commute and no per-campus-day denominator', () => {
  const result = estimateFootprint(week(0, 0));
  assert.equal(result.weeklyKg, 0);
  assert.equal(result.perCampusDayKg, null);
  assert.equal(result.totalKm, 0);
  assert.equal(result.complete, true);
  assert.equal(result.coverage, 1);
});

test('the class total sums people and the per-person mean includes zero-attendance responses', () => {
  const classWeek = summarizeFootprints([
    week(5, 10, { car: 2, bus: 2, bike: 1 }),
    week(1, 10, { carpool2: 1 }),
    week(0, 0),
  ]);
  const total = 40 * CAR + 40 * BUS + 20 * BIKE + 10 * CAR;
  near(classWeek.weeklyKg, total);
  near(classWeek.averageWeeklyKg, total / 3);
  near(classWeek.perCampusDayKg, total / 6);
  assert.equal(classWeek.complete, true);
  assert.equal(classWeek.unestimatedRespondents, 0);
  assert.equal(classWeek.coverage, 1);
  near(classWeek.byMode.find(item => item.key === 'carpool2').kg, 10 * CAR);
  assert.equal(classWeek.scenarioId, EMISSION_SCENARIO.id);
});

test('class coverage is distance-weighted and counts respondents with unknown segments', () => {
  const result = summarizeFootprints([
    week(1, 20, { car: 1 }),
    week(2, 5, { bus: 1, other: 1 }),
    week(0, 0),
  ]);
  assert.equal(result.complete, false);
  assert.equal(result.unestimatedRespondents, 1);
  assert.equal(result.unestimatedKm, 10);
  near(result.coverage, 50 / 60);
  near(result.weeklyKg, 40 * CAR + 10 * BUS);
  near(result.averageWeeklyKg, (40 * CAR + 10 * BUS) / 3);
  assert.equal(result.byMode.find(item => item.key === 'other').kg, null);
});

test('empty class data yields stable finite zero totals and a null per-campus-day mean', () => {
  const result = summarizeFootprints([]);
  assert.equal(result.weeklyKg, 0);
  assert.equal(result.averageWeeklyKg, 0);
  assert.equal(result.perCampusDayKg, null);
  assert.equal(result.coverage, 1);
  assert.equal(result.complete, true);
  assert.equal(result.unestimatedRespondents, 0);
  assert.equal(result.unestimatedKm, 0);
  assert.equal(result.byMode.length, keys.length);
});

test('calculations retain precision until display instead of rounding each day or person', () => {
  const tiny = week(1, 0.1, { carpool3: 1 });
  const one = estimateFootprint(tiny);
  near(one.weeklyKg, 0.2 * CAR / 3);
  assert.notEqual(one.weeklyKg, Math.round(one.weeklyKg * 100) / 100);
  const many = summarizeFootprints([tiny, tiny, tiny]);
  near(many.weeklyKg, 0.2 * CAR);
  near(many.averageWeeklyKg, 0.2 * CAR / 3);
  assert.notEqual(many.weeklyKg, 3 * (Math.round(one.weeklyKg * 100) / 100));
});
