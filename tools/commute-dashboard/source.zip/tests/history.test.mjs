import test from 'node:test';
import assert from 'node:assert/strict';
import { localCollectionDate, isCollectionDate, mergeHistory, summarizeHistory, buildHistorySeries } from '../app/lib/history.ts';

function record(changes = {}) {
  return {
    id: 'row-a', tokenHash: 'person-a', collectionDate: '2026-11-04',
    campusDays: 2, distanceKm: 5, modes: { car: 2 },
    footprint: {
      weeklyKg: 4, perCampusDayKg: 2, totalKm: 20, coveredKm: 20,
      coverage: 1, complete: true, unestimatedKm: 0,
      byMode: [{ key: 'car', label: 'Carro no cenário salvo', km: 20, kg: 4, kgPerKm: 0.2 }],
    },
    scenarioId: 'saved-scenario-v1',
    createdAt: '2026-11-04T12:00:00.000Z', updatedAt: '2026-11-04T12:00:00.000Z',
    source: 'daily', ...changes,
  };
}

test('São Paulo calendar date rolls over at 03:00 UTC rather than UTC midnight', () => {
  assert.equal(localCollectionDate(new Date('2026-11-04T02:59:59.999Z')), '2026-11-03');
  assert.equal(localCollectionDate(new Date('2026-11-04T03:00:00.000Z')), '2026-11-04');
  assert.equal(localCollectionDate(new Date('2027-01-01T02:00:00.000Z')), '2026-12-31');
});

test('date formatting honors timezone rules, including historical São Paulo daylight saving', () => {
  assert.equal(localCollectionDate(new Date('2018-12-01T02:30:00.000Z')), '2018-12-01');
  assert.equal(localCollectionDate(new Date('2026-12-01T02:30:00.000Z')), '2026-11-30');
  assert.throws(() => localCollectionDate(new Date('invalid')), RangeError);
});

test('collection dates require a real, strictly formatted calendar day', () => {
  for (const valid of ['2026-11-04', '2024-02-29', '2000-02-29', '0001-01-01', '9999-12-31']) assert.equal(isCollectionDate(valid), true, valid);
  for (const invalid of [undefined, null, 20261104, '', '2026-2-01', '2026-02-1', '2026-02-29', '1900-02-29', '2026-04-31', '2026-00-01', '2026-13-01', '2026-11-00', '0000-01-01', '2026-11-04T00:00:00Z', ' 2026-11-04', '2026-11-04 ']) assert.equal(isCollectionDate(invalid), false, String(invalid));
});

test('a recorded daily answer wins over a later virtual legacy row on the same day', () => {
  const daily = record({ id: 'journal' });
  const legacy = record({ id: 'legacy', source: 'legacy', updatedAt: '2026-11-04T23:00:00.000Z', campusDays: 7 });
  assert.deepEqual(mergeHistory([daily], [legacy]), [daily]);
});

test('revisions deduplicate within a source, without removing another date or participant', () => {
  const first = record();
  const edit = record({ id: 'row-b', updatedAt: '2026-11-04T13:00:00.000Z' });
  const previousDay = record({ id: 'previous-day', collectionDate: '2026-11-03' });
  const anotherPerson = record({ id: 'another-person', tokenHash: 'person-b' });
  const rows = mergeHistory([first, edit, first, anotherPerson], [previousDay]);
  assert.deepEqual(rows, [previousDay, edit, anotherPerson]);
  assert.equal(mergeHistory([], [first, edit]).length, 1);
  assert.equal(mergeHistory([], [first, edit])[0].id, 'row-b');
});

test('merge is deterministic for tied timestamps and does not mutate inputs', () => {
  const a = record({ id: 'a' }), z = record({ id: 'z' });
  const input = [z, a];
  assert.equal(mergeHistory(input, [])[0].id, 'z');
  assert.equal(mergeHistory([a, z], [])[0].id, 'z');
  assert.deepEqual(input, [z, a]);
  assert.throws(() => mergeHistory([record({ collectionDate: '2026-02-30' })], []), RangeError);
});

test('class summaries sum saved footprints rather than applying current or implied factors', () => {
  const saved = record({ distanceKm: 500, modes: { car: 7 }, footprint: { ...record().footprint, weeklyKg: 42, byMode: [{ key: 'car', label: 'Fator antigo', km: 20, kg: 42, kgPerKm: 2.1 }] } });
  const result = summarizeHistory([saved]);
  assert.equal(result.weeklyKg, 42);
  assert.equal(result.averageWeeklyKg, 42);
  assert.equal(result.perCampusDayKg, 21);
  assert.deepEqual(result.byMode, [{ key: 'car', label: 'Fator antigo', km: 20, kg: 42 }]);
  assert.equal(result.scenarioId, 'saved-scenario-v1');
});

test('zero-attendance replies remain in the per-person denominator but not the day denominator', () => {
  const absent = record({ id: 'absent', tokenHash: 'person-b', campusDays: 0, distanceKm: 0, modes: {}, footprint: { weeklyKg: 0, perCampusDayKg: null, totalKm: 0, coveredKm: 0, coverage: 1, complete: true, unestimatedKm: 0, byMode: [] } });
  const result = summarizeHistory([record(), absent]);
  assert.equal(result.weeklyKg, 4);
  assert.equal(result.averageWeeklyKg, 2);
  assert.equal(result.perCampusDayKg, 2);
  assert.equal(summarizeHistory([absent]).perCampusDayKg, null);
});

test('coverage is distance-weighted and missing factors remain unknown', () => {
  const partial = record({ id: 'partial', tokenHash: 'person-b', footprint: { weeklyKg: 10, perCampusDayKg: 5, totalKm: 100, coveredKm: 50, coverage: 0.5, complete: false, unestimatedKm: 50, byMode: [{ key: 'car', label: 'Carro', km: 50, kg: 10, kgPerKm: 0.2 }, { key: 'other', label: 'Outro', km: 50, kg: null, kgPerKm: null }] } });
  const result = summarizeHistory([record(), partial]);
  assert.equal(result.weeklyKg, 14);
  assert.equal(result.averageWeeklyKg, 7);
  assert.equal(result.coverage, 70 / 120);
  assert.equal(result.unestimatedKm, 50);
  assert.equal(result.unestimatedRespondents, 1);
  assert.equal(result.complete, false);
  assert.deepEqual(result.byMode.find(mode => mode.key === 'other'), { key: 'other', label: 'Outro', km: 50, kg: null });
});

test('an unknown mode stays null across snapshots even when another scenario estimated it', () => {
  const old = record({ footprint: { ...record().footprint, byMode: [{ key: 'other', label: 'Outro', km: 20, kg: null, kgPerKm: null }] } });
  const newer = record({ tokenHash: 'person-b', scenarioId: 'saved-scenario-v2', footprint: { ...record().footprint, byMode: [{ key: 'other', label: 'Outro agora estimado', km: 20, kg: 4, kgPerKm: 0.2 }] } });
  assert.equal(summarizeHistory([old, newer]).byMode[0].kg, null);
  assert.equal(summarizeHistory([newer, old]).byMode[0].kg, null);
  assert.equal(summarizeHistory([old, newer]).scenarioId, 'mixed');
});

test('empty histories have finite totals, complete coverage, no modes and no daily denominator', () => {
  assert.deepEqual(summarizeHistory([]), { weeklyKg: 0, averageWeeklyKg: 0, perCampusDayKg: null, complete: true, coverage: 1, unestimatedKm: 0, unestimatedRespondents: 0, byMode: [], scenarioId: '' });
  assert.deepEqual(buildHistorySeries([]), []);
});

test('trends sort observed dates and do not insert zero points for missing days', () => {
  const day4a = record();
  const day4b = record({ id: 'b', tokenHash: 'person-b', scenarioId: 'saved-scenario-v2' });
  const day1 = record({ id: 'old', collectionDate: '2026-11-01' });
  const result = buildHistorySeries([day4a, day1, day4b]);
  assert.deepEqual(result.map(point => point.date), ['2026-11-01', '2026-11-04']);
  assert.equal(result[1].respondents, 2);
  assert.equal(result[1].campusDays, 4);
  assert.equal(result[1].weeklyKm, 40);
  assert.equal(result[1].emissions.weeklyKg, 8);
  assert.equal(result[1].emissions.averageWeeklyKg, 4);
  assert.deepEqual(result[1].scenarioIds, ['saved-scenario-v1', 'saved-scenario-v2']);
  assert.equal(result[1].emissions.scenarioId, 'mixed');
});

test('historical distance and values use the frozen snapshot without display rounding', () => {
  const small = record({ footprint: { weeklyKg: 0.000034, perCampusDayKg: 0.000017, totalKm: 0.2, coveredKm: 0.2, coverage: 1, complete: true, unestimatedKm: 0, byMode: [{ key: 'bike', label: 'Bicicleta', km: 0.2, kg: 0.000034, kgPerKm: 0.00017 }] } });
  const result = buildHistorySeries([small]);
  assert.equal(result[0].weeklyKm, 0.2);
  assert.equal(result[0].emissions.weeklyKg, 0.000034);
  assert.equal(result[0].emissions.byMode[0].kg, 0.000034);
});
