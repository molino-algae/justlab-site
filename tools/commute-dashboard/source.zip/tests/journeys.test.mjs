import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAnswer, summarize, InputError } from '../app/lib/commute.ts';
import { estimateFootprint } from '../app/lib/emissions.ts';
import { compareFlight } from '../app/lib/flight.ts';
import { summarizeHistory } from '../app/lib/history.ts';
const token='a'.repeat(64);
const answer=(tripCount,distanceKm,modes)=>validateAnswer({token,tripCount,distanceKm,modes});
test('five bus arrivals and five bicycle returns total ten single trips, with no extra return multiplier',()=>{
 const a=answer(10,8,{bus:5,bike:5}),f=estimateFootprint(a);
 assert.equal(f.totalKm,80);assert.equal(f.byMode.find(x=>x.key==='bus').km,40);
 assert.ok(Math.abs(f.weeklyKg-(40*.12242+40*.00017))<1e-12);
 assert.equal(f.perTripKg,f.weeklyKg/10);assert.equal(f.perCampusDayKg,null);
});
test('fourteen trips may all use one mode; fifteen, fractions, inconsistent totals and mixed units fail',()=>{
 assert.equal(answer(14,2,{bike:14}).tripCount,14);
 for(const [n,m] of [[15,{bike:15}],[1.5,{bike:1.5}],[14,{bike:13}],[-1,{}]])assert.throws(()=>answer(n,2,m),InputError);
 assert.throws(()=>validateAnswer({token,campusDays:5,tripCount:10,distanceKm:2,modes:{bike:10}}),InputError);
 assert.equal(estimateFootprint(answer(0,0,{})).perTripKg,null);
});
test('a legacy two-day answer and a new four-trip answer have identical distances and footprints',()=>{
 const legacy=validateAnswer({token,campusDays:2,distanceKm:10,modes:{car:2}}),fresh=answer(4,10,{car:4});
 assert.equal(estimateFootprint(legacy).weeklyKg,estimateFootprint(fresh).weeklyKg);
 const stats=summarize([legacy,fresh].map(a=>({...a,updatedAt:'2026-11-04T12:00:00Z'})));
 assert.equal(stats.weeklyKm,80);assert.equal(stats.tripCount,8);assert.equal(stats.modeDays.find(m=>m.key==='car').trips,8);
});
test('class comparison uses the total passenger distance, not one distance per aircraft or another return multiplier',()=>{
 const result=compareFlight(100,5,true);assert.equal(result.flightKg,22.5);assert.equal(result.ratio,4.5);assert.equal(result.differenceKg,17.5);
 assert.equal(compareFlight(100,5,true,'long').flightKg,17.8);
 assert.equal(compareFlight(100,0,true).ratio,null);assert.equal(compareFlight(0,0,true).flightKg,0);
 assert.equal(compareFlight(100,5,false).ratio,null);assert.equal(compareFlight(100,5,false).differenceKg,null);
 assert.ok(compareFlight(100,30,true).differenceKg<0);
});
test('historical frozen distances and carbon are not recalculated when trip models mix',()=>{
 const result=summarizeHistory([{campusDays:2,modes:{car:2},scenarioId:'old',footprint:{weeklyKg:123,totalKm:40,coveredKm:40,unestimatedKm:0,complete:true,byMode:[]}}, {campusDays:0,tripCount:4,modes:{bus:4},scenarioId:'new',footprint:{weeklyKg:7,totalKm:60,coveredKm:60,unestimatedKm:0,complete:true,byMode:[]}}]);
 assert.equal(result.weeklyKg,130);assert.equal(result.totalKm,100);assert.equal(result.perCampusDayKg,null);
});
