import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';

const base = new URL(process.env.BASE_URL || 'http://127.0.0.1:5194');
assert.ok(['localhost', '127.0.0.1', '[::1]', '::1'].includes(base.hostname), 'History API tests are restricted to loopback preview, never production.');
assert.ok(['http:', 'https:'].includes(base.protocol) && !base.username && !base.password, 'BASE_URL must be a plain HTTP(S) preview URL.');
const projectRoot = process.cwd();
assert.equal(path.basename(projectRoot).toLowerCase(), 'commute-live', 'Run from the commute-live checkout; fixtures use only its local D1 database.');

const GITHUB = 'https://molino-algae.github.io';
const token = randomBytes(32).toString('hex');
const tokenHash = createHash('sha256').update(token).digest('hex');
const MODEL = 'ademe-fr-2026-11-02-gasoline-v1';
const FROZEN_MODEL = 'test-frozen-v0';
const CAR = 0.16970802472954336;
let roomId, adminKey, checks = 0;

function verify(value, message) { assert.ok(value, message); checks++; }
function near(actual, expected, message) {
  verify(Number.isFinite(actual) && Math.abs(actual - expected) <= Math.max(1, Math.abs(expected)) * 1e-10, `${message}: ${actual} != ${expected}`);
}
function localDate(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  return ['year', 'month', 'day'].map(type => parts.find(part => part.type === type).value).join('-');
}
function relativeDate(date, days) {
  const value = new Date(`${date}T12:00:00.000Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}
async function request(target, { method = 'GET', data, key, origin = base.origin, headers: extras = {} } = {}) {
  const headers = { ...extras, Origin: origin };
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  if (key) headers.Authorization = `Bearer ${key}`;
  return fetch(new URL(target, base), { method, headers, ...(data !== undefined ? { body: JSON.stringify(data) } : {}), signal: AbortSignal.timeout(15000) });
}
async function json(target, options, status = 200) {
  const response = await request(target, options);
  verify(response.status === status, `${options?.method || 'GET'} ${target}: expected ${status}, got ${response.status}`);
  return response.json();
}
function csvCells(line) { return line.split(';').map(cell => cell.replace(/^"|"$/g, '').replace(/""/g, '"')); }
const sqlValue = value => `'${String(value).replace(/'/g, "''")}'`;

async function seedLocalHistory(today, scenario) {
  const yesterday = relativeDate(today, -1), oldDate = relativeDate(today, -2);
  const modes = Object.fromEntries(scenario.factors.map(factor => [factor.key, factor.key === 'car' ? 1 : 0]));
  const historicalScenario = {
    ...scenario, id: FROZEN_MODEL, label: 'TESTE LOCAL · cenário histórico congelado',
    factors: scenario.factors.map(factor => factor.key === 'car' ? { ...factor, kgPerKm: 61.728 } : factor),
  };
  const frozen = {
    weeklyKg: 123.456, perCampusDayKg: 123.456, totalKm: 2, coveredKm: 2,
    coverage: 1, complete: true, unestimatedKm: 0,
    byMode: historicalScenario.factors.map(factor => ({
      key: factor.key, label: factor.label, km: factor.key === 'car' ? 2 : 0,
      kg: factor.kgPerKm === null ? null : factor.key === 'car' ? 123.456 : 0,
      kgPerKm: factor.kgPerKm,
    })),
  };
  verify(/^[A-Z2-9]{8}$/.test(roomId) && /^[a-f0-9]{64}$/.test(tokenHash), 'Fixture identifiers must be generated from this local test room and token.');
  const recordValues = [randomBytes(32).toString('hex'), roomId, tokenHash, yesterday, 1, 1, JSON.stringify(modes), JSON.stringify(frozen), FROZEN_MODEL, JSON.stringify(historicalScenario), 'daily', `${yesterday}T12:00:00.000Z`, `${yesterday}T12:00:00.000Z`];
  const legacyValues = [randomBytes(32).toString('hex'), roomId, tokenHash, 1, 1, JSON.stringify(modes), `${oldDate}T12:00:00.000Z`, `${oldDate}T12:00:00.000Z`];
  const sql = `-- Synthetic records for TESTE LOCAL classroom ${roomId}; local D1 only.\nINSERT INTO response_records (id,room_id,token_hash,collection_date,campus_days,distance_km,modes,footprint_json,scenario_id,scenario_json,source,created_at,updated_at) VALUES (${recordValues.map(sqlValue).join(',')});\nINSERT INTO responses (id,room_id,token_hash,campus_days,distance_km,modes,created_at,updated_at) VALUES (${legacyValues.map(sqlValue).join(',')});\n`;
  await mkdir(path.join(projectRoot, 'outputs'), { recursive: true });
  const fixturePath = path.join(projectRoot, 'outputs', `history-fixture-${roomId}.sql`);
  await writeFile(fixturePath, sql, 'utf8');
  const result = spawnSync(process.execPath, ['--import', './scripts/sites-env.mjs', './node_modules/wrangler/bin/wrangler.js', 'd1', 'execute', 'DB', '--local', '--config', 'dist/server/wrangler.json', '--persist-to', '.wrangler/state', '--file', fixturePath], { cwd: projectRoot, encoding: 'utf8', windowsHide: true, timeout: 30000 });
  verify(result.status === 0, `Local fixture import must succeed: ${result.error?.message || result.stderr || result.stdout}`);
  return { yesterday, oldDate };
}

try {
  const created = await json('/api/rooms', { method: 'POST', data: { title: `TESTE LOCAL — histórico ${new Date().toISOString()}` } }, 201);
  roomId = created.room?.id; adminKey = created.adminKey;
  verify(/^[A-Z2-9]{8}$/.test(roomId), 'A dedicated classroom must be created for this local test.');
  verify(/^[a-f0-9]{64}$/.test(adminKey), 'Local classroom creation must provide its management key.');
  const roomPath = `/api/rooms/${roomId}`, replyPath = `${roomPath}/responses`, historyPath = `${roomPath}/history`;
  const initial = await json(roomPath);
  const today = initial.collection?.date;
  verify(today === localDate(), 'Default collection date must be today in America/Sao_Paulo.');
  verify(initial.collection.today === today && initial.collection.timeZone === 'America/Sao_Paulo' && !initial.collection.readOnly, 'Live collection metadata must identify its date, timezone and writable state.');
  verify(initial.stats.respondents === 0, 'The dedicated room must initially be empty.');

  await json(historyPath, undefined, 403);
  await json(historyPath, { method: 'POST', data: {} }, 403);
  await json(`${roomPath}?date=${relativeDate(today, -1)}`, undefined, 403);
  await json(`${roomPath}?date=2026-02-30`, { key: adminKey }, 400);
  await json(`${roomPath}?date=${relativeDate(today, 1)}`, { key: adminKey }, 400);

  const answer = { token, campusDays: 5, distanceKm: 10, modes: { car: 5 } };
  for (const bad of [answer, { ...answer, collectionDate: relativeDate(today, -1) }, { ...answer, collectionDate: relativeDate(today, 1) }]) {
    await json(replyPath, { method: 'POST', data: bad }, 409);
  }
  verify((await json(roomPath)).stats.respondents === 0, 'Missing, stale and future collection dates must not save a reply.');

  const preflight = await request(replyPath, { method: 'OPTIONS', origin: GITHUB, headers: { 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type,authorization' } });
  verify(preflight.status === 204, 'GitHub Pages must receive a successful API preflight.');
  verify(preflight.headers.get('access-control-allow-origin') === GITHUB, 'CORS must allow the exact GitHub origin rather than a wildcard.');
  verify(/POST/.test(preflight.headers.get('access-control-allow-methods') || '') && /PATCH/.test(preflight.headers.get('access-control-allow-methods') || ''), 'CORS must preserve submission and instructor update methods.');
  verify(/content-type/i.test(preflight.headers.get('access-control-allow-headers') || '') && /authorization/i.test(preflight.headers.get('access-control-allow-headers') || ''), 'CORS must permit JSON and the existing management header.');
  verify(/origin/i.test(preflight.headers.get('vary') || ''), 'CORS preflight caching must vary by origin.');
  verify(preflight.headers.get('access-control-allow-credentials') !== 'true', 'Anonymous GitHub access must not require browser credential sharing.');
  const denied = await request(replyPath, { method: 'OPTIONS', origin: 'https://untrusted.invalid', headers: { 'Access-Control-Request-Method': 'POST' } });
  verify(denied.status === 403 && !denied.headers.get('access-control-allow-origin'), 'An untrusted origin must be rejected without a CORS grant.');
  verify((await request(roomPath, { origin: 'https://untrusted.invalid' })).status === 403, 'An untrusted actual request must also be rejected.');

  const { yesterday, oldDate } = await seedLocalHistory(today, initial.collection.scenario);
  let imported = await json(historyPath, { method: 'POST', data: {}, key: adminKey });
  verify(imported.ok === true && imported.inspected === 1, 'Explicit import must inspect the one retained legacy response.');
  await json(historyPath, { method: 'POST', data: {}, key: adminKey });
  let history = await json(historyPath, { key: adminKey });
  verify(history.timeZone === 'America/Sao_Paulo' && history.today === today, 'History metadata must use the classroom calendar.');
  verify(history.series.length === 2 && history.series.every(point => point.respondents === 1), 'Repeated legacy imports must not duplicate dated replies.');
  verify(history.series.map(point => point.date).join(',') === `${oldDate},${yesterday}`, 'Observed history dates must be sorted without extra zero-filled dates.');
  near(history.series.find(point => point.date === oldDate).emissions.weeklyKg, 2 * CAR, 'Retained legacy footprint');
  const archived = await json(`${roomPath}?date=${yesterday}`, { key: adminKey });
  verify(archived.collection.readOnly && archived.collection.date === yesterday, 'Past collection views must be read-only.');
  verify(archived.collection.scenario.id === FROZEN_MODEL, 'An archive must expose its saved historical calculation scenario.');
  near(archived.stats.emissions.weeklyKg, 123.456, 'Historical total must use the saved snapshot rather than current factors');
  near(archived.stats.emissions.averageWeeklyKg, 123.456, 'Historical per-person mean must use the saved snapshot');

  const submitted = await json(replyPath, { method: 'POST', origin: GITHUB, data: { ...answer, collectionDate: today } });
  verify(submitted.ok && !submitted.updated && submitted.collectionDate === today, 'The same person on a new collection day must create a dated reply.');
  near(submitted.footprint.weeklyKg, 100 * CAR, 'New-day personal footprint');
  let live = await json(roomPath);
  verify(live.stats.respondents === 1 && live.collection.date === today, 'The live dashboard must count only today, not the historical replies.');
  near(live.stats.emissions.weeklyKg, 100 * CAR, 'New-day class total');
  const edited = await json(replyPath, { method: 'POST', data: { ...answer, campusDays: 4, modes: { car: 4 }, collectionDate: today } });
  verify(edited.updated === true, 'A same-day submission must edit its dated answer.');
  await json(historyPath, { method: 'POST', data: {}, key: adminKey });
  history = await json(historyPath, { key: adminKey });
  verify(history.series.length === 3 && history.series.every(point => point.respondents === 1), 'Same-day edits and subsequent imports must preserve one reply per person per date.');
  near(history.series.find(point => point.date === today).emissions.weeklyKg, 80 * CAR, 'Edited live total');
  near(history.series.find(point => point.date === yesterday).emissions.weeklyKg, 123.456, 'Today must not change yesterday’s frozen result');
  verify(history.series.find(point => point.date === yesterday).scenarioIds.join() === FROZEN_MODEL, 'History must retain the old model identifier.');
  await json(replyPath, { method: 'POST', data: { ...answer, collectionDate: yesterday } }, 409);

  const exported = await request(`${roomPath}/export?all=true`, { key: adminKey, origin: GITHUB });
  verify(exported.status === 200 && exported.headers.get('access-control-allow-origin') === GITHUB, 'The instructor must be able to export history from GitHub Pages.');
  verify(/content-disposition/i.test(exported.headers.get('access-control-expose-headers') || ''), 'CORS must expose the downloadable filename.');
  const csvBytes = new Uint8Array(await exported.arrayBuffer());
  verify(csvBytes[0] === 0xef && csvBytes[1] === 0xbb && csvBytes[2] === 0xbf, 'Historical CSV must keep its UTF-8 BOM.');
  const csv = Buffer.from(csvBytes).toString('utf8');
  const lines = csv.slice(1).split('\r\n'), headers = csvCells(lines[0]), rows = lines.slice(1).map(csvCells);
  verify(headers.length === 24 && rows.every(row => row.length === 24), 'All historical CSV rows must match the dated 24-column schema.');
  verify(rows.length === 3, 'The all-dates CSV must contain three dated answers without import duplicates.');
  const column = name => { const index = headers.indexOf(name); verify(index >= 0, `CSV header ${name} must exist.`); return index; };
  const dateColumn = column('Data da coleta'), co2Column = column('CO2e estimado (kg/semana)'), modelColumn = column('Cenário de cálculo');
  const sourceColumn = column('Origem do registro'), createdColumn = column('Enviada em'), updatedColumn = column('Atualizada em');
  verify(rows.map(row => row[dateColumn]).join(',') === `${oldDate},${yesterday},${today}`, 'CSV must retain the actual collection dates in order.');
  const historicalRow = rows.find(row => row[dateColumn] === yesterday);
  verify(historicalRow[modelColumn] === FROZEN_MODEL && historicalRow[co2Column] === '123.456', 'CSV must retain saved model and numerical snapshot.');
  verify(rows.some(row => row[sourceColumn].startsWith('Legado')), 'Imported legacy provenance must be visible.');
  verify(rows.every(row => !Number.isNaN(Date.parse(row[createdColumn])) && !Number.isNaN(Date.parse(row[updatedColumn]))), 'Each exported record must preserve valid original and update timestamps.');
  verify(![token, tokenHash, adminKey].some(secret => csv.includes(secret)), 'Historical export must not expose device tokens, hashes or management credentials.');
  const currentCsv = await request(`${roomPath}/export`, { key: adminKey });
  verify((await currentCsv.text()).replace(/^\ufeff/, '').split('\r\n').length === 2, 'Default export must remain restricted to the current day.');
  live = await json(roomPath);
  verify(live.stats.respondents === 1, 'History browsing and exports must not alter today’s counts.');
  const closed = await json(roomPath, { method: 'PATCH', data: { open: false }, key: adminKey });
  verify(closed.room.open === false, 'The synthetic local classroom must finish closed.');
  await json(replyPath, { method: 'POST', data: { ...answer, collectionDate: today } }, 409);
  console.log(JSON.stringify({ ok: true, checks, room: roomId, testOnly: true, baseUrl: base.origin, feature: 'dated-frozen-history-and-github-cors' }));
} finally {
  if (roomId && adminKey) {
    try { await request(`/api/rooms/${roomId}`, { method: 'PATCH', data: { open: false }, key: adminKey }); }
    catch { console.error('Could not close the dedicated local history test room.'); }
  }
}
