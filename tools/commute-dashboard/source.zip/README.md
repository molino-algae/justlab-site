# JUSTLAB — Como chegamos ao campus

Formulário anônimo e painel da turma para a atividade inicial de Sustainable Future.

## Na aula

1. Abra o site e crie uma turma com o nome da aula.
2. Guarde o link de gerenciamento. Ele permite abrir/encerrar respostas e baixar o CSV.
3. Projete o painel e o QR code. Cada estudante responde sobre uma semana típica.
4. O painel consulta as respostas compartilhadas a cada três segundos. A mesma turma e o mesmo QR iniciam uma coleta nova a cada data de São Paulo.
5. No link de gerenciamento, consulte o histórico, escolha uma coleta anterior e exporte a data selecionada ou todo o histórico.
6. Encerre as respostas e reabra a turma quando desejar. Coletas de datas anteriores permanecem somente para consulta.

O QR code contém somente o link do formulário. O acesso de gerenciamento fica no fragmento do link do professor, separado do QR code. Quem tiver o link de gerenciamento pode controlar essa turma. Não há cadastro ou recuperação de conta.

## O que os números significam

- O novo formulário conta de 0 a 14 trajetos por semana. Cada ida e cada volta contam separadamente: 5 idas de ônibus e 5 voltas de bicicleta são 10 trajetos. A soma dos transportes precisa coincidir com esse total.
- A distância informada é de um trajeto, sem somar ida e volta. Usamos a mesma distância aproximada em cada direção. A distância semanal é essa distância multiplicada pelos trajetos, sem duplicar novamente. Em um trajeto com vários modos, informa-se o principal ou Outro/combinado.
- Carona +1 significa a pessoa respondente mais uma outra pessoa no veículo, duas no total; +4 significa cinco no total.
- Passageiro-km não é veículo-km. Pessoas no mesmo carro não são automaticamente identificadas ou agrupadas.
- O formulário mostra a estimativa semanal de CO₂e da pessoa e a média por trajeto. O painel mostra o total da turma, a média semanal por resposta e a distribuição por transporte.
- Cada nova resposta salva a data da coleta, o resultado calculado e uma cópia do cenário de cálculo no banco compartilhado. Uma edição substitui somente a resposta dessa pessoa nessa data; as outras datas ficam preservadas. Uma página antiga não pode enviar silenciosamente para uma data nova.
- O histórico compara fotografias da semana habitual em datas de coleta diferentes. Os totais semanais não devem ser somados entre coletas para representar emissões acumuladas no calendário. O gráfico principal usa média por pessoa e informa participação e cobertura.
- O cenário ADEME/Impact CO₂ é uma referência francesa fixada em 02/11/2026, com fabricação e uso dos veículos, sem infraestrutura ou alimentação. Carros: médio a gasolina; moto: até 250 cm³. Uber/táxi usa uma aproximação de carro com um passageiro, sem trajetos vazios. Os fatores e fontes ficam disponíveis nos detalhes do cálculo.
- A fórmula por modo é `distância de um trajeto × trajetos × fator por passageiro-km`. Nas caronas dividimos o fator do carro pelo total de ocupantes. O fator de ônibus já é por passageiro e não é dividido novamente.
- A média semanal da turma divide o total por todas as respostas, incluindo zero dias. O painel não transforma outro/combinado em emissão zero: mostra subtotal e média parciais, cobertura por distância e número de respostas incompletas.

Não são solicitados nome, e-mail, endereço ou rota. O painel público mostra apenas agregados. O CSV do professor contém as respostas anônimas. O identificador aleatório salvo neste navegador permite substituir uma resposta; ele reduz duplicações no mesmo navegador, sem verificar uma pessoa por resposta. Trocar de navegador ou apagar os dados locais permite outra resposta.

O histórico e as exportações exigem o link de gerenciamento. Respostas anteriores à implantação do histórico conservam o último conteúdo disponível, datado pelo horário da última atualização e identificado como legado. A importação idempotente guarda uma fotografia do cálculo no cenário vigente; conteúdos substituídos antes de existir o histórico não podem ser reconstruídos.

## GitHub Pages e banco

A apresentação HTML possui o botão **Enquete → Salvar e iniciar nova enquete**. Com o link de gestão, o professor pode encerrar a enquete ativa e criar outra vazia, inclusive no mesmo dia. A apresentação atualiza automaticamente o QR code e o painel. A API `/api/rooms/:id/polls` conserva o grupo da aula, a enquete ativa e todas as anteriores no banco; o histórico e os CSV continuam protegidos pela chave do professor. Uma enquete arquivada não pode ser reaberta. Repetições da mesma solicitação não criam enquetes duplicadas.

O endereço público é `https://molino-algae.github.io/justlab-site/commute/`. O GitHub Pages publica HTML, CSS e JavaScript; a API e o banco D1 continuam no serviço existente. Respostas individuais e chaves de gerenciamento não são publicadas no repositório. A API permite a origem exata do site GitHub, com autorização própria para histórico, exportação e controles da turma.

`node scripts/build-pages.mjs` gera `outputs/github-pages/commute/`. A página, os recursos compilados e o logo vão para `public/commute/` no repositório JUSTLAB. O pacote de fontes saneadas em `tools/commute-dashboard/source.zip` permite reproduzir a construção. As referências e os limites da hospedagem ficam em `docs/github-hosting.md`.

## Desenvolvimento

Vinext / React, Cloudflare Worker e D1. `.openai/hosting.json` preserva a identidade do Site e a ligação `DB`. Os dados de produção são compartilhados; o armazenamento local contém apenas o identificador anônimo, preferências e o link de gerenciamento do professor.

O esquema fica em `db/schema.ts`; as migrações geradas em `drizzle/` são aplicadas pela publicação. Não há criação de tabelas durante requisições.

`npm run dev`, `npm run build` e `npm run db:generate` seguem o fluxo do starter. Os testes de domínio usam o test runner do Node.

## Comparação com avião

O painel compara a mesma soma de passageiro-km da turma com fatores constantes por passageiro de voo curto (0,225 kg/km), médio (0,185) ou longo (0,178). Fonte: páginas oficiais Impact CO₂/ADEME, consultadas em 04/11/2026. Incluem fabricação, combustível e trilhas de condensação; infraestrutura fica fora. Não é uma rota real ou um avião inteiro. Mostramos o resultado calculado, inclusive quando menor. A razão não aparece para zero ou subtotal parcial da turma.

`trip_count` nulo identifica respostas antigas por dias. Elas continuam guardadas com suas pegadas congeladas. Na leitura, cada dia antigo equivale a dois trajetos. O CSV identifica o modelo original e exporta contagens por transporte em trajetos, além da média por trajeto. A nova migração apenas adiciona campos opcionais; não reescreve respostas antigas.
