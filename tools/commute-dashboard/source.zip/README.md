# JUSTLAB — Como chegamos ao campus

Formulário anônimo e painel da turma para a atividade inicial de Sustainable Future.

## Na aula

1. Abra o site e crie uma turma com o nome da aula.
2. Guarde o link de gerenciamento. Ele permite abrir/encerrar respostas e baixar o CSV.
3. Projete o painel e o QR code. Cada estudante responde sobre uma semana típica.
4. O painel consulta as respostas compartilhadas a cada três segundos. A mesma turma e o mesmo QR iniciam uma coleta nova a cada data de São Paulo.
5. No link de gerenciamento, consulte o histórico, escolha uma coleta anterior e exporte a data selecionada ou todo o histórico.
6. Encerre as respostas e reabra a turma quando desejar. Coletas de datas anteriores permanecem somente para consulta.

O QR code contém somente o link do formulário. O acesso de gerenciamento fica no fragmento do link do professor, separado do QR code. Quem tiver o link de gerenciamento pode controlar essa turma. Não há cadastro ou recuperação de conta.

## O que os números significam

- Dias por transporte somam os dias de presença no campus; uma pessoa pode usar modos diferentes ao longo da semana.
- A distância informada é de ida. A distância semanal estima uma ida e uma volta por dia, usando o transporte principal informado.
- Carona +1 significa a pessoa respondente mais uma outra pessoa no veículo, duas no total; +4 significa cinco no total.
- Passageiro-km não é veículo-km. Pessoas no mesmo carro não são automaticamente identificadas ou agrupadas.
- O formulário mostra a estimativa semanal de CO₂e da pessoa e a média por dia presencial. O painel mostra o total da turma, a média semanal por resposta e a distribuição por transporte.
- Cada nova resposta salva a data da coleta, o resultado calculado e uma cópia do cenário de cálculo no banco compartilhado. Uma edição substitui somente a resposta dessa pessoa nessa data; as outras datas ficam preservadas. Uma página antiga não pode enviar silenciosamente para uma data nova.
- O histórico compara fotografias da semana habitual em datas de coleta diferentes. Os totais semanais não devem ser somados entre coletas para representar emissões acumuladas no calendário. O gráfico principal usa média por pessoa e informa participação e cobertura.
- O cenário ADEME/Impact CO₂ é uma referência francesa fixada em 02/11/2026, com fabricação e uso dos veículos, sem infraestrutura ou alimentação. Carros: médio a gasolina; moto: até 250 cm³. Uber/táxi usa uma aproximação de carro com um passageiro, sem trajetos vazios. Os fatores e fontes ficam disponíveis nos detalhes do cálculo.
- A fórmula por modo é `2 × distância de ida × dias × fator por passageiro-km`. Nas caronas dividimos o fator do carro pelo total de ocupantes. O fator de ônibus já é por passageiro e não é dividido novamente.
- A média semanal da turma divide o total por todas as respostas, incluindo zero dias. O painel não transforma outro/combinado em emissão zero: mostra subtotal e média parciais, cobertura por distância e número de respostas incompletas.

Não são solicitados nome, e-mail, endereço ou rota. O painel público mostra apenas agregados. O CSV do professor contém as respostas anônimas. O identificador aleatório salvo neste navegador permite substituir uma resposta; ele reduz duplicações no mesmo navegador, sem verificar uma pessoa por resposta. Trocar de navegador ou apagar os dados locais permite outra resposta.

O histórico e as exportações exigem o link de gerenciamento. Respostas anteriores à implantação do histórico conservam o último conteúdo disponível, datado pelo horário da última atualização e identificado como legado. A importação idempotente guarda uma fotografia do cálculo no cenário vigente; conteúdos substituídos antes de existir o histórico não podem ser reconstruídos.

## GitHub Pages e banco

O endereço público é `https://molino-algae.github.io/justlab-site/commute/`. O GitHub Pages publica HTML, CSS e JavaScript; a API e o banco D1 continuam no serviço existente. Respostas individuais e chaves de gerenciamento não são publicadas no repositório. A API permite a origem exata do site GitHub, com autorização própria para histórico, exportação e controles da turma.

`node scripts/build-pages.mjs` gera `outputs/github-pages/commute/`. Os três arquivos compilados vão para `public/commute/` no repositório JUSTLAB. O pacote de fontes saneadas em `tools/commute-dashboard/source.zip` permite reproduzir a construção. As referências e os limites da hospedagem ficam em `docs/github-hosting.md`.

## Desenvolvimento

Vinext / React, Cloudflare Worker e D1. `.openai/hosting.json` preserva a identidade do Site e a ligação `DB`. Os dados de produção são compartilhados; o armazenamento local contém apenas o identificador anônimo, preferências e o link de gerenciamento do professor.

O esquema fica em `db/schema.ts`; as migrações geradas em `drizzle/` são aplicadas pela publicação. Não há criação de tabelas durante requisições.

`npm run dev`, `npm run build` e `npm run db:generate` seguem o fluxo do starter. Os testes de domínio usam o test runner do Node.
