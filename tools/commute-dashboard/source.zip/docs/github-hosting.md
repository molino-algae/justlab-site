# Interface no GitHub Pages

Esta compilação reutiliza `app/page.tsx` e `app/globals.css` como uma aplicação React estática. Ela não inclui o servidor, o banco de dados nem credenciais de gestão.

A entrada estática fica em `github-client/index.html` e `github-client/main.tsx`. Essa pasta é separada de `app/` e dos nomes reservados de rotas do servidor.

Execute na raiz do projeto, com o Node usado no ambiente de trabalho:

```text
node scripts/build-pages.mjs
```

A saída fica em `outputs/github-pages/commute/`. Copie essa pasta para `public/commute/` do site Astro `justlab-site`, preservando `index.html` e `assets/` juntos. O endereço previsto é:

```text
https://molino-algae.github.io/justlab-site/commute/
```

O caminho `/justlab-site/commute/` está configurado em `vite.pages.config.ts`. O script confere os caminhos dos recursos e impede que a limpeza da compilação saia da pasta de saídas do projeto.

A coleta continua usando a API compartilhada configurada pelo cliente. O serviço da API precisa aceitar a origem `https://molino-algae.github.io` para permitir respostas, leitura do painel e exportação autorizada. O site estático contém apenas o endereço público da API; chaves de gestão são recebidas quando uma sessão é criada.

Recompile a interface após alterar os componentes ou seus estilos. A compilação estática é separada da compilação do servidor Sites.
