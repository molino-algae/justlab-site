import { integer, real, sqliteTable, text, uniqueIndex, index } from "drizzle-orm/sqlite-core";

export const classrooms = sqliteTable("classrooms", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  adminHash: text("admin_hash").notNull(),
  open: integer("open", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull(),
});

export const responses = sqliteTable("responses", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull().references(() => classrooms.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(),
  campusDays: integer("campus_days").notNull(),
  tripCount: integer("trip_count"),
  distanceKm: real("distance_km").notNull(),
  modes: text("modes").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (table) => [
  uniqueIndex("response_per_device_room").on(table.roomId, table.tokenHash),
  index("responses_room_idx").on(table.roomId),
]);

export const responseRecords = sqliteTable("response_records", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull().references(() => classrooms.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(),
  collectionDate: text("collection_date").notNull(),
  campusDays: integer("campus_days").notNull(),
  tripCount: integer("trip_count"),
  distanceKm: real("distance_km").notNull(),
  modes: text("modes").notNull(),
  footprint: text("footprint_json").notNull(),
  scenarioId: text("scenario_id").notNull(),
  scenario: text("scenario_json").notNull(),
  source: text("source").notNull().default("daily"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (table) => [
  uniqueIndex("one_response_per_collection_day").on(table.roomId, table.collectionDate, table.tokenHash),
  index("records_room_date_idx").on(table.roomId, table.collectionDate),
]);

export const pollGroups = sqliteTable("poll_groups", {
  rootId: text("root_id").primaryKey().references(() => classrooms.id),
  activeRoomId: text("active_room_id").notNull().references(() => classrooms.id),
  updatedAt: text("updated_at").notNull(),
});

export const pollRuns = sqliteTable("poll_runs", {
  roomId: text("room_id").primaryKey().references(() => classrooms.id),
  rootId: text("root_id").notNull().references(() => classrooms.id),
  previousRoomId: text("previous_room_id").references(() => classrooms.id),
  requestId: text("request_id").notNull(),
  createdAt: text("created_at").notNull(),
}, (table) => [
  uniqueIndex("poll_request_once").on(table.rootId, table.requestId),
  index("poll_runs_root_idx").on(table.rootId, table.createdAt),
]);
