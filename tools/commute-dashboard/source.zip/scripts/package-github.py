"""Prepare a reviewable GitHub upsert packet. This script never calls GitHub."""

from __future__ import annotations

import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile


ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"
BUILD = OUTPUTS / "github-pages" / "commute"
PACKET_PATH = OUTPUTS / "github-publication.json"
META_PATH = OUTPUTS / "github-publication-meta.json"
ZIP_PATH = OUTPUTS / "commute-dashboard-source.zip"
README_PATH = OUTPUTS / "github-source-README.md"

EXCLUDED_PARTS = {
    ".git", "node_modules", "outputs", "dist", "build", ".next", ".vinext",
    ".wrangler", ".sites-runtime", ".vite", ".cache", ".codex", ".agents", ".aws",
    "__pycache__", "coverage", "playwright-report", "test-results",
    "screenshots", "screenshot", "work", "out",
}
EXCLUDED_SUFFIXES = {
    ".zip", ".tar", ".tgz", ".gz", ".log", ".sqlite", ".sqlite3",
    ".db", ".csv", ".jsonl", ".ndjson", ".pyc", ".tsbuildinfo",
    ".pem", ".key", ".p12", ".pfx",
}
SECRET_PATTERNS = [
    re.compile(rb"art_v2_[A-Za-z0-9_]{20,}"),
    re.compile(rb"(?:sk-proj-|sk-svcacct-)[A-Za-z0-9_-]{20,}"),
    re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(rb"gh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(rb"AKIA[0-9A-Z]{16}"),
    re.compile(rb"#manage=[0-9a-fA-F]{32,}"),
    re.compile(rb"Bearer [A-Za-z0-9_-]{32,}"),
]

README = """# Painel de trajetos · JUSTLAB

Interface pública: https://molino-algae.github.io/justlab-site/commute/

O arquivo `source.zip` contém o projeto completo, incluindo interface React,
API do Worker, esquema e migrações do D1, testes e licenças dos componentes.
Dados de estudantes, arquivos de execução locais e credenciais não fazem parte
do pacote. O endereço público da API está em `app/lib/client.ts`.

## Reconstruir a interface

1. Extraia `source.zip` em uma pasta de trabalho.
2. Use Node.js 22.13 ou mais recente e execute `npm ci` na raiz do projeto.
3. Execute `node scripts/build-pages.mjs`.
4. Copie o conteúdo de `outputs/github-pages/commute/` para `public/commute/`
   do repositório Astro `justlab-site`, mantendo `index.html` e `assets/` juntos.
5. Publique o site Astro pelo fluxo de GitHub Pages já usado pelo repositório.

A entrada estática fica em `github-client/`; sua configuração é
`vite.pages.config.ts`. O caminho público é `/justlab-site/commute/`.

## API e banco de dados

O GitHub Pages serve a interface. A API compartilhada continua no Worker
existente, com os registros no D1. Alterações no backend e suas migrações devem
seguir o fluxo de publicação do Sites descrito no projeto; a compilação estática
não publica nem substitui esse serviço.

A API deve permitir a origem `https://molino-algae.github.io`. Credenciais e
tokens de gestão continuam fora do código público. Não crie outro serviço nem
substitua a identidade do serviço existente para reconstruir apenas a interface.

## Histórico por data de coleta

As respostas e o histórico diário permanecem no D1. O painel consulta essas
coleções pela API. Não salve respostas, exportações CSV, chaves de gestão ou
histórico de estudantes neste repositório. Uma compilação ou atualização do site
não deve reiniciar o banco nem apagar as coletas anteriores.
"""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_secret_bytes(data: bytes, name: str) -> None:
    if any(pattern.search(data) for pattern in SECRET_PATTERNS):
        raise RuntimeError(f"Possível credencial encontrada em {name}; revise antes de empacotar.")


def source_paths() -> tuple[list[Path], int]:
    result = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    selected: list[Path] = []
    skipped = 0
    for raw in sorted(set(result.stdout.split(b"\0"))):
        if not raw:
            continue
        relative = Path(raw.decode("utf-8"))
        parts = {part.lower() for part in relative.parts}
        name = relative.name.lower()
        if (
            parts & EXCLUDED_PARTS
            or any(part.lower().startswith(".env") or part.lower().startswith(".dev.vars") for part in relative.parts)
            or relative.suffix.lower() in EXCLUDED_SUFFIXES
            or name.endswith(("-wal", "-shm", ".log.1"))
            or "screenshot" in name
        ):
            skipped += 1
            continue
        path = ROOT / relative
        if not path.exists() or path.is_symlink() or not path.is_file():
            skipped += 1
            continue
        if not path.resolve().is_relative_to(ROOT):
            raise RuntimeError(f"Arquivo fora do projeto: {relative.as_posix()}")
        if name == ".npmrc":
            config_bytes = path.read_bytes()
            if b"\0" in config_bytes or re.search(rb"(?:_authToken|_auth|password)\s*=", config_bytes, re.IGNORECASE):
                skipped += 1
                continue
        selected.append(relative)
    if not selected:
        raise RuntimeError("Nenhum arquivo de código foi encontrado.")
    required = ["package.json", "package-lock.json", "app/page.tsx", "github-client/main.tsx", "vite.pages.config.ts", "scripts/build-pages.mjs"]
    included = {path.as_posix() for path in selected}
    if any(name not in included for name in required):
        raise RuntimeError("O pacote está incompleto; confira os arquivos de código e dependências.")
    return selected, skipped


def source_zip(paths: list[Path]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative in paths:
            data = (ROOT / relative).read_bytes()
            check_secret_bytes(data, relative.as_posix())
            info = zipfile.ZipInfo(relative.as_posix(), date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if relative.suffix == ".sh" else 0o644) << 16
            archive.writestr(info, data, compresslevel=9)
    return buffer.getvalue()


def main() -> None:
    OUTPUTS.mkdir(exist_ok=True)
    compiled = sorted(path for path in BUILD.rglob("*") if path.is_file())
    if len(compiled) != 3 or sorted(path.suffix for path in compiled) != [".css", ".html", ".js"]:
        raise RuntimeError("Compile primeiro: são esperados apenas index.html, um JS e um CSS.")
    frontend_inputs = [
        "app/page.tsx", "app/globals.css", "app/lib/client.ts", "app/lib/emissions.ts",
        "github-client/main.tsx", "github-client/index.html", "vite.pages.config.ts",
        "postcss.config.mjs", "package.json", "package-lock.json",
    ]
    oldest_output = min(path.stat().st_mtime_ns for path in compiled)
    if any((ROOT / name).stat().st_mtime_ns > oldest_output for name in frontend_inputs):
        raise RuntimeError("A interface mudou após a compilação. Execute node scripts/build-pages.mjs antes de empacotar.")
    paths, skipped = source_paths()
    archive = source_zip(paths)
    ZIP_PATH.write_bytes(archive)
    README_PATH.write_text(README, encoding="utf-8", newline="\n")
    upserts = []
    file_meta = []
    for path in compiled:
        data = path.read_bytes()
        check_secret_bytes(data, path.name)
        destination = "public/commute/" + path.relative_to(BUILD).as_posix()
        content = data.decode("utf-8")
        upserts.append({"path": destination, "content": content, "encoding": "utf-8"})
        file_meta.append({"path": destination, "encoding": "utf-8", "bytes": len(data), "sha256": sha256(data)})
    upserts.append({"path": "tools/commute-dashboard/source.zip", "content": base64.b64encode(archive).decode("ascii"), "encoding": "base64"})
    readme_data = README.encode("utf-8")
    upserts.append({"path": "tools/commute-dashboard/README.md", "content": README, "encoding": "utf-8"})
    file_meta.extend([
        {"path": "tools/commute-dashboard/source.zip", "encoding": "base64", "bytes": len(archive), "sha256": sha256(archive)},
        {"path": "tools/commute-dashboard/README.md", "encoding": "utf-8", "bytes": len(readme_data), "sha256": sha256(readme_data)},
    ])
    packet = {
        "owner": "molino-algae", "repo": "justlab-site", "branch": "main",
        "message": "Add commuting dashboard with dated collections and trends",
        "upserts": upserts, "force": False, "max_retries": 0,
    }
    # ASCII JSON makes requested character chunks identical in Python and Node.
    text = json.dumps(packet, ensure_ascii=True, separators=(",", ":"))
    PACKET_PATH.write_text(text, encoding="utf-8", newline="\n")
    metadata = {
        "packet": PACKET_PATH.name, "characters": len(text), "bytes": len(text.encode("utf-8")),
        "sha256": sha256(text.encode("utf-8")), "upserts": file_meta,
        "source_zip_bytes": len(archive), "source_zip_sha256": sha256(archive),
        "source_file_count": len(paths), "excluded_file_count": skipped,
    }
    META_PATH.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "ready", "packet": str(PACKET_PATH), "characters": len(text), "bytes": metadata["bytes"], "upsert_count": len(upserts), "source_file_count": len(paths), "source_zip_bytes": len(archive), "source_zip_sha256": metadata["source_zip_sha256"]}))


if __name__ == "__main__":
    main()
