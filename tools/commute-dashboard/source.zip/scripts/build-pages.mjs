import { spawnSync } from "node:child_process";
import { mkdir, readFile, readdir, lstat, realpath } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = fileURLToPath(new URL("..", import.meta.url));
const outputParent = path.resolve(projectRoot, "outputs/github-pages");
const outputDir = path.resolve(outputParent, "commute");
const base = "/justlab-site/commute/";
const cli = path.resolve(projectRoot, "node_modules/vite/bin/vite.js");
const config = path.resolve(projectRoot, "vite.pages.config.ts");

// Vite empties this directory. Reject redirected or out-of-workspace targets.
await mkdir(outputParent, { recursive: true });
const actualRoot = await realpath(projectRoot);
const actualParent = await realpath(outputParent);
const relativeParent = path.relative(actualRoot, actualParent);
if (relativeParent.startsWith("..") || path.isAbsolute(relativeParent) || path.relative(outputParent, outputDir) !== "commute") {
  throw new Error("O diretório de saída está fora da pasta autorizada do projeto.");
}
try {
  if ((await lstat(outputDir)).isSymbolicLink()) throw new Error("A saída não pode ser um link para outra pasta.");
} catch (error) { if (error.code !== "ENOENT") throw error; }

const result = spawnSync(process.execPath, [cli, "build", "--config", config], {
  cwd: projectRoot,
  stdio: "inherit",
  env: process.env,
});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status || 1);

const html = await readFile(path.join(outputDir, "index.html"), "utf8");
if (!html.includes('lang="pt-BR"') || html.includes('src="/main.tsx"')) throw new Error("A página inicial não foi compilada corretamente.");
const references = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(match => match[1]);
let jsCount = 0;
let cssCount = 0;
for (const reference of references) {
  if (/^(?:https?:|data:|#)/.test(reference)) continue;
  if (!reference.startsWith(base)) throw new Error(`Recurso fora do caminho do GitHub Pages: ${reference}`);
  const relative = decodeURIComponent(reference.slice(base.length).split(/[?#]/)[0]);
  const asset = path.resolve(outputDir, relative);
  const inside = path.relative(outputDir, asset);
  if (inside.startsWith("..") || path.isAbsolute(inside)) throw new Error("Um recurso aponta para fora da saída.");
  if (!(await lstat(asset)).isFile()) throw new Error(`Recurso compilado ausente: ${relative}`);
  if (/\.js$/.test(relative)) jsCount++;
  if (/\.css$/.test(relative)) cssCount++;
}
if (!jsCount || !cssCount) throw new Error("A saída deve conter JavaScript e CSS compilados.");

const assets = await readdir(path.join(outputDir, "assets"));
for (const file of assets) {
  if (file.endsWith(".map")) throw new Error("Mapas de código-fonte não devem ser publicados.");
  if (!/\.(?:js|css)$/.test(file)) continue;
  const content = await readFile(path.join(outputDir, "assets", file), "utf8");
  if (/art_v2_|sk-proj-[A-Za-z0-9_-]+|siwc_bypass_bearer_token|admin_hash|cloudflare:workers/.test(content)) {
    throw new Error(`A saída contém conteúdo reservado ao servidor: ${file}`);
  }
}
console.log(JSON.stringify({ status: "ready", base, directory: outputDir, scripts: jsCount, stylesheets: cssCount }));
