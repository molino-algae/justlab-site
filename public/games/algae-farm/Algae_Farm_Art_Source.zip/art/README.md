# Editable artwork — Algae Farm 1.0

This scene combines Kenney's free Tiny Town 1.1 and Tiny Farm 1.0 tiles with original researcher, aerator and process equipment artwork. Both Kenney packs are CC0. Their original licenses are retained beside the atlases in `assets/vendor/`. Sources: https://kenney.nl/assets/tiny-town and https://kenney.nl/assets/tiny-farm.

## Piskel

Open `art/custom/down-walk.piskel` in https://www.piskelapp.com/ using Import → Browse .piskel files → Replace. It contains four 16×24 frames at 8 fps. This document was imported and its animation and 4-column PNG export settings reviewed in the actual Piskel editor. The original pixels were constructed with the included pixel-art script, then checked in Piskel; they were not drawn by hand in the editor.

`researcher.piskel` contains all 16 directional frames. The game's `researcher.png` has four columns and four rows: down, left, right, up. Keep frame 0 as idle and the foot anchor at (8,23). `aerator.piskel` contains six 16×16 frames; its PNG uses one row of six columns. Preserve hard transparency and export at 1×. The game displays these at 2×.

## Tiled

Open `art/maps/algae-farm.tmj` in Tiled. Keep the relative folder structure so both external `.tsj` tilesets resolve their images. The map was successfully exported to TMX and rendered by the official Tiled 1.12.2 tools. `Tiled_Map_Preview.png` is that editor render.

The current map is 40×21 tiles, authored at 16 pixels per tile and displayed at 2× in the game (1280×672 world pixels). The checked TMX export has the same dimensions, and `Tiled_Map_Preview.png` is 640×336 pixels. Cultivo → Energia → Processamento → Recuperação forms a clockwise circuit. Expedição sits outside that circuit, west of Cultivo and Recuperação, at the end of the extended road.

The Ground, Paths and Ground details layers paint Kenney terrain. Scenery contains decorations; paired tree halves share a `footY` depth anchor. Stations define collision footprints and process-building locations. Interactions define navigation destinations. StationTargets separately defines clickable building/platform, label and owned-upgrade badge areas, using `stationId`, `targetKind` and `minUpgrade` properties. Hover and pointer navigation use these same targets; enlarging a drawing's click target does not enlarge its collision footprint. These map layers and objects are actually consumed by the game. Algae raceways, buildings, pipes, weather and lighting are drawn and animated by `src/scene.mjs`; their full appearance is visible in the game rather than the terrain-only Tiled preview.

The river occupies the two eastern columns. Its bank landing and “Sondar o rio” marker are original Canvas artwork. `RIVER_SITE` in `src/secrets.mjs` defines the landing at world position (1200,400), its click targets and the walkable approach tile [37,12]. Clicking the channel or marker routes the researcher to that bank. River sampling is separate from the three optional notebook discoveries; the existing EEL plaque, mushroom and stump remain in the expanded campus.

Save changes to the `.tmj` source. The `.tmx` is a checked export, not the build input. From the complete local game project, run `node tools/build.mjs` to embed the map and PNGs into `dist/index.html`. Editing a PNG alone will not update an existing built HTML file.

## Visual behavior

Water flow, paddle rotation and aeration run in cultivation. Clouds and soft shadows arrive after the first decision. Choosing LEDs lights the greenhouse windows. The researcher uses directional walking frames and stops on an idle frame. Reduced-motion preferences freeze decorative animation and use a static weather state. Seeded events originated in model version 0.2.0; the current fixed scenario uses reference weather and no random contamination, within the version 1.0 campaign economy.

No paid assets, accounts or services are required. The public art-source ZIP contains only reusable artwork, map files, the relevant rendering code and licenses; classroom notes and the original email are excluded.

Version 0.5 adds three optional discoveries defined in `src/secrets.mjs`. The EEL field plaque uses the unmodified PNG from the official EEL library visual identity page. It is a separate institutional mark, not a Kenney CC0 asset; its source and identity-rights note are in `assets/institution/REFERENCE.txt`. Before discovery, the plaque is small and weathered. The notebook reveals the complete logo after the player finds it. Climate intensity also follows the lot's light, normal or dense cloud profile.

Version 0.6 renders permanent cultivation, processing and recovery upgrades. `world.farmUpgrades` contains levels 0–3 for those three keys; missing values show the original farm. Higher levels add pumps, nutrient barrels, process equipment, reservoirs, Roman-numeral badges and operating lights inside the existing station footprints. The current batch draws its equipment snapshot; between batches the scene shows the farm's latest purchases. These additions are Canvas artwork in `src/scene.mjs`, so no new sprite imports are required.


## Historical Biolab visual pass — version 0.8

The interface uses an original shared line-icon set in `src/icons.mjs`, a five-stage production strip and a culture badge. `src/style.css` contains the responsive dark laboratory palette, clear focus states and reduced-motion alternatives. The simulation profiles and saved-game formats are unchanged.

Canvas machinery and campus details remain editable in `src/scene.mjs`. Piskel researcher/aerator sources and Tiled station footprints still drive the scene. New station feedback uses `world.celebrate(station, kind)` with a short-lived visual event; destinations and pointer hover are local navigation feedback. The camera follows the researcher smoothly, while reduced motion and resizing use a direct camera position. These effects are presentation state and do not affect yields, costs or progression.


Version 0.8.1 uses daylight across the scene and interface: natural grass, pale concrete and metal, light panels and dark teal text. Weather shading remains a modest daytime cloud effect. The updated rendering code and stylesheet preserve the same geometry and source artwork.

## Current cultivation visuals — version 1.0

Version 1.0 keeps daylight, directional researcher animation, cloud shadows, reduced-motion support and the mobile follow camera while expanding the campus. Culture-specific palettes and cell forms are original Canvas artwork in `CULTURE_VISUALS` and `cultureCells()` in `src/scene.mjs`. C. pacifica uses green oval cells with two flagellum strokes; its culture-selection illustration is original inline SVG in `cultureIcon()` in `src/app.mjs`. These cells and icons are schematic illustrations, not microscopy or Kenney sprites, and do not require a new external sprite sheet. The researcher and aerator remain editable through the Piskel sources above.
