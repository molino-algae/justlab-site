import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'art/maps'); fs.mkdirSync(out, {recursive: true});
const width = 40, height = 21, tw = 16, campusShift = 8;
const ground = [], pathTiles = [], detail = [];
const pathAt = (x, y) => x > 0 && x < width - 2 && (
  ((y === 8 || y === 9) && x >= 8 && x <= 36) ||
  ((y === 16 || y === 17) && x >= 9 && x <= 36) ||
  ((x === 9 || x === 10 || x === 35 || x === 36) && y >= 9 && y <= 17) ||
  ((x === 15 || x === 16 || x === 33 || x === 34) && y >= 15 && y <= 17) ||
  (x === 30 && y >= 8 && y <= 10) ||
  (x === 37 && y >= 9 && y <= 17));
for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
  ground.push(x >= width - 2 ? 0 : (x * 17 + y * 7) % 13 === 0 ? 2 : 1);
  const rr = !pathAt(x, y - 1) ? 0 : !pathAt(x, y + 1) ? 2 : 1;
  const cc = !pathAt(x - 1, y) ? 0 : !pathAt(x + 1, y) ? 2 : 1;
  pathTiles.push(pathAt(x, y) ? [12, 13, 14, 24, 25, 26, 36, 37, 38][rr * 3 + cc] + 1 : 0);
  const flower = x < width - 2 && !pathAt(x, y) && ((x * 7 + y * 13) % 71 === 0);
  detail.push(flower ? 3 : 0);
}
let nextObjectId = 1;
const scenery = [];
const prop = (name, gid, x, y, size = 16, shifted = true) => scenery.push({id: nextObjectId++, name, type: 'decoration', gid, x:x + (shifted ? campusShift * tw : 0), y, width: size, height: size, rotation: 0, visible: true});
for (let x = 1; x < width - 2; x++) prop('North fence', (x === 1 ? 80 : x === width - 3 ? 82 : 81) + 1, x * 16, 22, 16, false);
// Tiles 4/16 are the crown and trunk of one tree, not standalone trees.
// A shared footY keeps both halves together in the runtime depth order.
for (const [x,y] of [[1,4],[28,4],[1,10],[1,18],[29,20]]) {
  prop('Tree crown', 5, x * 16, y * 16 - 16);
  scenery.at(-1).properties = [{name:'footY',type:'int',value:y*16},{name:'castShadow',type:'bool',value:false}];
  prop('Tree trunk', 17, x * 16, y * 16);
  scenery.at(-1).properties = [{name:'footY',type:'int',value:y*16}];
}
for (const [x,y] of [[14,3],[29,11],[11,12],[20,20]]) prop('Small tree', 29, x * 16, y * 16);
for (const [x,y,id] of [[13,7,73],[18,8,84],[9,15,124],[21,14,72],[27,18,73],[12,18,76]]) prop('Farm equipment', 133 + id, x * 16, y * 16);
for (const [x,y,id] of [[2,5,29],[12,2,29],[10,13,107],[27,18,106],[19,10,43]]) prop('Garden detail', id + 1, x * 16, y * 16);
const stationSpecs = [
  ['cultivation','Cultivo',12,3,9,4,16,8,'#37654d'],
  ['weather','Energia',27,3,7,5,30,9,'#ab813d'],
  ['processing','Processamento',30,11,7,4,33,16,'#955b42'],
  ['recovery','Recuperação',11,11,6,4,15,16,'#447d84'],
  ['delivery','Expedição',2,8,6,3,8,9,'#a27537']
];
const stations = stationSpecs.map(([id,name,x,y,w,h,px,py,color]) => ({
  id: nextObjectId++, name, type: 'station', x:x*16, y:y*16, width:w*16, height:h*16, rotation:0, visible:true,
  properties:[{name:'stationId',type:'string',value:id},{name:'color',type:'color',value:color}]
}));
const interactions = stationSpecs.map(([id,name,x,y,w,h,px,py]) => ({
  id: nextObjectId++, name:`${name}: arrival`, type:'arrival', x:(px+.5)*16, y:(py+.5)*16, point:true, rotation:0, visible:true,
  properties:[{name:'stationId',type:'string',value:id}]
}));
// Click targets follow the drawn platform/body and labels, not collision space.
const stationTargets = [];
const target = (id, name, kind, x, y, w, h, minUpgrade = 0) => stationTargets.push({
  id:nextObjectId++,name:`${name}: ${kind}`,type:'station-target',x:x/2,y:y/2,width:w/2,height:h/2,rotation:0,visible:true,
  properties:[{name:'stationId',type:'string',value:id},{name:'targetKind',type:'string',value:kind},{name:'minUpgrade',type:'int',value:minUpgrade}]
});
for (const [id,name,tx,ty,tw,th] of stationSpecs) {
  const x=tx*32,y=ty*32,w=tw*32,h=th*32,labelWidth=Math.max(126,name.length*7+55);
  target(id,name,'body',x-10,y-14,w+20,h+26);
  target(id,name,'label',x+w/2-labelWidth/2-1,y-41,labelWidth+2,28);
  if (['cultivation','processing','recovery'].includes(id)) target(id,name,'upgrade',x+w/2+labelWidth/2+5,y-37,26,20,1);
}
const bounds = [[0,0,16,height*16],[0,0,width*16,16],[(width-2)*16,0,32,height*16],[0,(height-1)*16,width*16,16]].map(([x,y,w,h]) => ({id:nextObjectId++,name:'Farm boundary',type:'boundary',x,y,width:w,height:h,rotation:0,visible:true}));
const riverSite = [{id:nextObjectId++,name:'River sampling bank',type:'river-arrival',x:(width-2.5)*16,y:12.5*16,point:true,rotation:0,visible:true}];
const layer = (id,name,data) => ({id,name,type:'tilelayer',x:0,y:0,width,height,data,opacity:1,visible:true});
const objects = (id,name,objects,color,visible=true) => ({id,name,type:'objectgroup',x:0,y:0,objects,opacity:1,visible,color,draworder:'topdown'});
const map = {compressionlevel:-1,height,width,infinite:false,nextlayerid:10,nextobjectid:nextObjectId,orientation:'orthogonal',renderorder:'right-down',tiledversion:'1.12.2',tileheight:16,tilewidth:16,type:'map',version:'1.10',backgroundcolor:'#639a9b',
  properties:[{name:'worldScale',type:'int',value:2},{name:'campusShift',type:'int',value:campusShift},{name:'riverColumn',type:'int',value:width-2},{name:'notes',type:'string',value:'Kenney Tiny Town/Farm CC0 terrain. Stations are collision footprints. StationTargets cover visible structures and labels for pointer/touch input. Scenery is visual only. Arrival points drive routes. Dispatch is west of the production loop; river sampling stays separate from the three discoveries.'}],
  layers:[layer(1,'Ground',ground),layer(2,'Paths',pathTiles),layer(3,'Ground details',detail),objects(4,'Scenery',scenery,'#ccac74'),objects(5,'Stations',stations,'#517d74'),objects(6,'Interactions',interactions,'#dca74d'),objects(7,'Boundary',bounds,'#b95f50',false),objects(8,'StationTargets',stationTargets,'#4a9981',false),objects(9,'Exploration',riverSite,'#5d99bd')],
  tilesets:[{firstgid:1,source:'tiny-town.tsj'},{firstgid:133,source:'tiny-farm.tsj'}]};
for (const name of ['town','farm']) {
  const set={columns:12,image:`../../assets/vendor/kenney-tiny-${name}/Tilemap/tilemap_packed.png`,imageheight:176,imagewidth:192,margin:0,name:`Kenney Tiny ${name === 'town' ? 'Town' : 'Farm'}`,spacing:0,tilecount:132,tiledversion:'1.12.2',tileheight:16,tilewidth:16,type:'tileset',version:'1.10'};
  fs.writeFileSync(path.join(out,`tiny-${name}.tsj`),JSON.stringify(set,null,2)+'\n');
}
fs.writeFileSync(path.join(out,'algae-farm.tmj'),JSON.stringify(map,null,2)+'\n');
console.log('Created editable Tiled map and two Kenney tilesets.');
