# Editable farm map

Open `algae-farm.tmj` in Tiled. Keep the two `.tsj` tileset files beside it; they reference the Kenney sheets in `assets/vendor` relative to this folder.

- **Ground, Paths, Ground details** are the terrain painted in the game.
- **Scenery** contains Kenney tile objects, sorted by their bottom edge at runtime. Keep tile objects at 16 × 16 so every original art pixel uses the same scale.
- **Stations** are each building's solid footprint. Their `stationId` properties connect the map to the five game decisions. The game draws the original algae equipment and buildings at these rectangles.
- **Interactions** contains the arrival point for each station. Put each point at the center of a free tile beside its station.
- **Boundary** documents the farm limits. The river occupies the two eastern columns and is original Canvas art because the Kenney packs contain no natural water terrain.

The map uses 16-pixel tiles. Runtime displays it at twice that size, giving 32-pixel walking tiles. Building art, the researcher and the aerators follow the same two-times source scale.

`tools/create-map.mjs` recreates the initial map. It overwrites hand edits, so run it only when deliberately resetting the layout. The normal build reads the saved map directly and does not regenerate it.
