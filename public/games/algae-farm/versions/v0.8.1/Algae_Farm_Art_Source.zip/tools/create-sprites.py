"""Original logical-pixel sprites for Algae Farm. No external image pixels used."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import base64
import io
import json
import math

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'art' / 'custom'
OUT.mkdir(parents=True, exist_ok=True)
P = {
    'outline': '#35463d', 'hair': '#493d32', 'hairlight': '#725442',
    'skin': '#dba778', 'skinlight': '#edc28e', 'skinshade': '#b97f57',
    'coat': '#f1ead2', 'coatlight': '#fff6db', 'coatshade': '#c8c9b0',
    'teal': '#477f77', 'teallight': '#6c9b8b', 'tealdark': '#315c59',
    'pants': '#53615a', 'pantsshade': '#3d4c49', 'boot': '#624a36', 'bootlight': '#8b6643',
    'gold': '#d8ae62', 'wood': '#ab7c4a', 'water': '#84b9b6'
}

def sprite(direction, frame):
    im = Image.new('RGBA', (16, 24))
    d = ImageDraw.Draw(im)
    bob = 1 if frame == 2 else 0
    def r(box, color, body=False):
        x1,y1,x2,y2 = box
        if body: y1 += bob; y2 += bob
        d.rectangle((x1,y1,x2,y2), fill=P.get(color,color))
    def line(points, color, width=1, body=False):
        if body: points = [(x,y+bob) for x,y in points]
        d.line(points, fill=P.get(color,color), width=width)
    # Legs are deliberately anchored independently of the subtle torso bob.
    if direction in ('down', 'up'):
        left_end = 23 if frame == 1 else 21 if frame == 3 else 22
        right_end = 21 if frame == 1 else 23 if frame == 3 else 22
        r((5,17,6,left_end-1),'pants'); r((9,17,10,right_end-1),'pantsshade')
        r((4,left_end,6,left_end),'boot'); r((9,right_end,11,right_end),'boot')
        r((5,left_end-1,6,left_end-1),'bootlight'); r((9,right_end-1,10,right_end-1),'bootlight')
    else:
        if frame == 1:
            line([(8,17),(10,19),(12,21)],'pantsshade',2)
            r((10,21,13,21),'boot')
            line([(7,17),(5,20),(4,22)],'pants',2)
            r((2,22,5,23),'boot'); r((3,22,5,22),'bootlight')
        elif frame == 3:
            line([(9,17),(7,19),(5,21)],'pantsshade',2)
            r((3,21,6,21),'boot')
            line([(7,17),(9,20),(8,22)],'pants',2)
            r((6,22,9,23),'boot'); r((7,22,9,22),'bootlight')
        else:
            r((8,17,9,21),'pantsshade'); r((7,22,10,22),'boot')
            r((6,17,7,21),'pants'); r((4,22,7,22),'boot'); r((5,21,7,21),'bootlight')
    if direction == 'down':
        # Coat silhouette, open teal shirt, lapels and a small ID badge.
        r((4,10,11,18),'outline',True); r((3,11,12,16),'outline',True)
        r((4,11,6,17),'coat',True); r((9,11,11,17),'coat',True)
        r((5,10,10,11),'coatlight',True); r((4,12,5,16),'coatlight',True)
        r((7,10,8,17),'teal',True); r((7,11,7,16),'teallight',True)
        r((6,11,6,12),'coatlight',True); r((9,11,9,12),'coatlight',True)
        r((4,17,6,18),'coatshade',True); r((9,17,11,18),'coatshade',True)
        r((5,14,6,15),'coatshade',True); r((9,13,10,14),'teal',True)
        r((9,13,9,13),'gold',True)
        swing = -1 if frame == 1 else 1 if frame == 3 else 0
        r((2,12+swing,3,16+swing),'coat',True); r((2,17+swing,3,18+swing),'skin',True)
        r((12,12,13,16),'coatshade',True); r((12,16,13,17),'skin',True)
        # The bag gives the tiny character a distinctive readable profession cue.
        line([(10,10),(11,13),(12,15)],'tealdark',1,True)
        r((11,15,14,19),'tealdark',True); r((12,16,14,18),'teal',True)
        r((12,16,13,16),'teallight',True); r((12,18,12,18),'gold',True)
        r((7,8,8,10),'skinshade',True)
        r((5,2,10,8),'outline',True); r((4,3,11,6),'hair',True)
        r((5,2,10,4),'hair',True); r((6,2,9,2),'hairlight',True)
        r((5,5,10,7),'skin',True); r((6,5,9,5),'skinlight',True)
        r((6,6,6,6),'outline',True); r((9,6,9,6),'outline',True)
        r((8,7,8,7),'skinshade',True); r((6,8,9,8),'skinshade',True)
    elif direction == 'up':
        r((4,10,11,18),'outline',True); r((3,11,12,16),'outline',True)
        r((4,11,11,17),'coat',True); r((5,10,10,11),'coatshade',True)
        r((6,11,9,12),'coatlight',True); r((5,12,6,16),'coatlight',True)
        r((8,13,8,17),'coatshade',True); r((5,18,10,18),'coatshade',True)
        swing = -1 if frame == 1 else 1 if frame == 3 else 0
        r((12,12+swing,13,16+swing),'coatshade',True); r((12,17+swing,13,18+swing),'skin',True)
        r((2,12,3,16),'coat',True); r((2,17,3,18),'skin',True)
        line([(5,10),(4,13),(3,15)],'tealdark',1,True)
        r((1,15,4,19),'tealdark',True); r((1,16,3,18),'teal',True)
        r((2,16,3,16),'teallight',True); r((3,18,3,18),'gold',True)
        r((7,8,8,10),'skinshade',True)
        r((5,2,10,8),'outline',True); r((4,3,11,7),'hair',True)
        r((5,2,10,7),'hair',True); r((6,2,9,3),'hairlight',True)
        r((4,6,4,7),'skinshade',True); r((11,6,11,7),'skinshade',True)
        r((6,8,9,8),'hair',True)
    else:
        # Profile is drawn facing left, then mirrored for the right-facing row.
        r((5,10,10,18),'outline',True); r((5,11,10,17),'coat',True)
        r((6,10,9,11),'coatlight',True); r((5,12,6,16),'coatlight',True)
        r((9,12,10,17),'coatshade',True); r((6,18,10,18),'coatshade',True)
        r((5,11,5,15),'teal',True)
        arm = -1 if frame == 1 else 1 if frame == 3 else 0
        r((4,12+arm,6,15+arm),'coatlight',True); r((4,16+arm,5,17+arm),'skin',True)
        # Visible satchel and strap remain compact enough for the 16-pixel cell.
        line([(9,10),(10,13),(11,15)],'tealdark',1,True)
        r((9,14,12,19),'tealdark',True); r((10,15,12,18),'teal',True)
        r((10,15,11,15),'teallight',True); r((10,18,10,18),'gold',True)
        r((7,8,8,10),'skinshade',True)
        r((6,2,10,8),'outline',True); r((5,3,11,6),'hair',True)
        r((6,2,10,4),'hair',True); r((7,2,9,3),'hairlight',True)
        r((5,5,8,7),'skin',True); r((6,5,8,5),'skinlight',True)
        r((4,7,5,7),'skin',True); r((6,6,6,6),'outline',True)
        r((6,8,8,8),'skinshade',True); r((9,6,9,7),'skinshade',True)
        if direction == 'right': im = ImageOps.mirror(im)
    return im

def aerator(frame):
    im = Image.new('RGBA',(16,16))
    d=ImageDraw.Draw(im)
    d.rectangle((2,11,13,13),fill=P['tealdark'])
    d.rectangle((3,11,12,11),fill=P['teallight'])
    d.rectangle((2,6,3,11),fill=P['outline']); d.rectangle((12,6,13,11),fill=P['outline'])
    d.rectangle((3,7,12,8),fill=P['coatshade'])
    d.ellipse((3,2,12,11),fill=P['outline'])
    d.ellipse((4,3,11,10),fill=P['wood'])
    cx,cy=7.5,6.5
    for spoke in range(4):
        angle=math.radians(frame*60+spoke*90)
        x=round(cx+4*math.cos(angle));y=round(cy+4*math.sin(angle))
        d.line([(round(cx),round(cy)),(x,y)],fill=P['gold'] if spoke==0 else '#c89754',width=2)
        d.rectangle((x-1,y-1,x+1,y+1),fill=P['coatlight'] if spoke==0 else P['gold'])
    d.rectangle((6,5,9,8),fill=P['tealdark']); d.rectangle((7,6,8,7),fill=P['teallight'])
    # A few spray pixels move with the wheel, without enlarging its footprint.
    if frame in (1,2,4,5):
        d.point((1 if frame<3 else 14,3 if frame%2 else 1),fill=P['water'])
    return im

def piskel(name, sheet, width, height, count, columns, fps):
    bio=io.BytesIO();sheet.save(bio,format='PNG')
    layout=[[row*columns+column for row in range(sheet.height//height) if row*columns+column<count] for column in range(columns)]
    layer={'name':'Original pixel artwork','opacity':1,'frameCount':count,'chunks':[{'layout':layout,'base64PNG':'data:image/png;base64,'+base64.b64encode(bio.getvalue()).decode()}]}
    document={'modelVersion':2,'piskel':{'name':name,'description':'Original Algae Farm pixels; editable logical-pixel frames.','fps':fps,'width':width,'height':height,'layers':[json.dumps(layer,separators=(',',':'))],'hiddenFrames':[]}}
    return document

directions=['down','left','right','up']
frames=[sprite(direction,frame) for direction in directions for frame in range(4)]
sheet=Image.new('RGBA',(64,96))
for i,im in enumerate(frames):sheet.alpha_composite(im,((i%4)*16,(i//4)*24))
sheet.save(OUT/'researcher.png')
(OUT/'researcher.piskel').write_text(json.dumps(piskel('Algae Farm researcher - all directions',sheet,16,24,16,4,8),separators=(',',':')),encoding='utf-8')
down=sheet.crop((0,0,64,24))
down.save(OUT/'down-walk.png')
(OUT/'down-walk.piskel').write_text(json.dumps(piskel('Algae Farm researcher - down walk',down,16,24,4,4,8),separators=(',',':')),encoding='utf-8')
aerator_frames=[aerator(i) for i in range(6)]
wheel=Image.new('RGBA',(96,16))
for i,im in enumerate(aerator_frames):wheel.alpha_composite(im,(i*16,0))
wheel.save(OUT/'aerator.png')
(OUT/'aerator.piskel').write_text(json.dumps(piskel('Algae Farm paddle aerator',wheel,16,16,6,6,8),separators=(',',':')),encoding='utf-8')

# Contact sheet uses nearest-neighbor enlargement; sprite pixels remain unchanged.
preview=Image.new('RGB',(800,1000),'#f5f1e5')
pd=ImageDraw.Draw(preview)
title=ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf',23)
label=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',16)
pd.text((28,20),'ALGAE FARM / ORIGINAL CHARACTER',font=title,fill=P['outline'])
pd.text((28,54),'16 x 24 px / 4 frames per direction / foot anchor (8, 23)',font=label,fill='#65755f')
for row,direction in enumerate(directions):
    y=95+row*196
    pd.text((28,y+65),direction.upper(),font=label,fill=P['outline'])
    for col in range(4):
        x=125+col*160
        pd.rectangle((x,y,x+127,y+191),fill='#e3e8d5')
        for yy in range(0,192,16):
            for xx in range(0,128,16):
                if (xx//16+yy//16)%2:pd.rectangle((x+xx,y+yy,x+xx+15,y+yy+15),fill='#d6dec6')
        preview.paste(frames[row*4+col].resize((128,192),Image.Resampling.NEAREST),(x,y),frames[row*4+col].resize((128,192),Image.Resampling.NEAREST))
pd.text((28,887),'PADDLE AERATOR / 16 x 16 px / 6 frames',font=label,fill=P['outline'])
for i,im in enumerate(aerator_frames):
    zoom=im.resize((64,64),Image.Resampling.NEAREST)
    preview.paste(zoom,(125+i*100,920),zoom)
preview.save(OUT/'Sprite_Contact_Sheet.png')

gif_frames=[]
for frame in range(4):
    im=Image.new('RGB',(512,256),'#d6dec6')
    for row in range(4):
        big=frames[row*4+frame].resize((96,144),Image.Resampling.NEAREST)
        im.paste(big,(16+row*128,40),big)
    gif_frames.append(im)
gif_frames[0].save(OUT/'researcher-walk-preview.gif',save_all=True,append_images=gif_frames[1:],duration=125,loop=0)

manifest={
    'researcher':{'file':'researcher.png','width':64,'height':96,'frameWidth':16,'frameHeight':24,'columns':4,'rows':['down','left','right','up'],'fps':8,'idleFrame':0,'anchor':[8,23]},
    'aerator':{'file':'aerator.png','width':96,'height':16,'frameWidth':16,'frameHeight':16,'columns':6,'rows':1,'fps':8},
    'source':'tools/create-sprites.py',
    'piskelFormatSources':['https://raw.githubusercontent.com/piskelapp/piskel/master/src/js/Constants.js','https://raw.githubusercontent.com/piskelapp/piskel/master/src/js/utils/serialization/Serializer.js','https://raw.githubusercontent.com/piskelapp/piskel/master/src/js/utils/serialization/Deserializer.js']
}
(OUT/'layout.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(OUT/'CUSTOM_ASSETS.md').write_text('# Algae Farm original pixel artwork\n\nResearcher and paddle aerator were drawn in logical pixels by tools/create-sprites.py. No third-party image pixels were included. The PNG sheets are ready for the game; the .piskel files are prepared for editing using Piskel model version 2. This generation step does not establish that Piskel itself was used.\n\nresearcher.png: 64 by 96; sixteen 16 by 24 frames. Rows down, left, right, up; four columns. Column 0 is neutral and idle-compatible. Feet use logical anchor (8, 23). Suggested display size 32 by 48 and animation at 8 fps.\n\naerator.png: six 16 by 16 frames in one horizontal row, total 96 by 16. Suggested 8 fps.\n\ndown-walk.piskel contains the four down-facing frames for an immediate Piskel animation preview. researcher.piskel contains all sixteen frames in row order. aerator.piskel contains the six machine frames.\n\nReuse terms follow the project owner\'s chosen license.\n',encoding='utf-8')

# Verify transparent pixel sheets and that every saved editable frame matches its PNG.
assert sheet.mode=='RGBA' and sheet.size==(64,96)
assert set(sheet.getchannel('A').getdata())=={0,255}
assert len({im.tobytes() for im in frames})==16
assert len({im.tobytes() for im in aerator_frames})==6
for name,count,fw,fh in [('researcher',16,16,24),('down-walk',4,16,24),('aerator',6,16,16)]:
    document=json.loads((OUT/(name+'.piskel')).read_text())
    assert document['modelVersion']==2
    layer=json.loads(document['piskel']['layers'][0]);assert layer['frameCount']==count
    chunk=layer['chunks'][0]
    decoded=Image.open(io.BytesIO(base64.b64decode(chunk['base64PNG'].split(',',1)[1]))).convert('RGBA')
    original=Image.open(OUT/(name+'.png')).convert('RGBA')
    assert decoded.tobytes()==original.tobytes()
    assert sorted(v for column in chunk['layout'] for v in column)==list(range(count))
print('Created original researcher and aerator sheets, editable Piskel projects, layout, contact sheet, and GIF preview.')
