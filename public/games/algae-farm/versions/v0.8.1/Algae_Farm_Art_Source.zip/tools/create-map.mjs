import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'art/maps'); fs.mkdirSync(out, {recursive: true});
const width = 32, height = 21, tw = 16;
const ground = [], pathTiles = [], detail = [];
const pathAt = (x, y) => x > 0 && x < 30 && (
  ((y === 8 || y === 9) && x >= 2 && x <= 28) ||
  ((y === 16 || y === 18) && x >= 3 && x <= 28) ||
  ((x === 7 || x === 16 || x === 25) && y >= 8 && y <= 18) ||
  (x === 22 && y >= 8 && y <= 11));
for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
  ground.push(x >= 30 ? 0 : (x * 17 + y * 7) % 13 === 0 ? 2 : 1);
  const rr = !pathAt(x, y - 1) ? 0 : !pathAt(x, y + 1) ? 2 : 1;
  const cc = !pathAt(x - 1, y) ? 0 : !pathAt(x + 1, y) ? 2 : 1;
  pathTiles.push(pathAt(x, y) ? [12, 13, 14, 24, 25, 26, 36, 37, 38][rr * 3 + cc] + 1 : 0);
  const flower = x < 30 && !pathAt(x, y) && ((x * 7 + y * 13) % 71 === 0);
  detail.push(flower ? 3 : 0);
}
let nextObjectId = 1;
const scenery = [];
const prop = (name, gid, x, y, size = 16) => scenery.push({id: nextObjectId++, name, type: 'decoration', gid, x, y, width: size, height: size, rotation: 0, visible: true});
for (let x = 1; x < 30; x++) prop('North fence', (x === 1 ? 80 : x === 29 ? 82 : 81) + 1, x * 16, 22);
// Tiles 4/16 are the crown and trunk of one tree, not standalone trees.
// A shared footY keeps both halves together in the runtime depth order.
for (const [x,y] of [[1,4],[28,4],[1,10],[1,18],[29,20]]) {
  prop('Tree crown', 5, x * 16, y * 16 - 16);
  scenery.at(-1).properties = [{name:'footY',type:'int',value:y*16},{name:'castShadow',type:'bool',value:false}];
  prop('Tree trunk', 17, x * 16, y * 16);
  scenery.at(-1).properties = [{name:'footY',type:'int',value:y*16}];
}
for (const [x,y] of [[14,3],[29,11],[11,12],[20,20]]) prop('Small tree', 29, x * 16, y * 16);
for (const [x,y,id] of [[13,7,73],[18,8,84],[9,15,124],[21,14,72],[27,18,73],[12,18,76]]) prop('Farm equipment', 133 + id, x * 16, y * 16);
for (const [x,y,id] of [[2,5,29],[12,2,29],[10,13,107],[27,18,106],[19,10,43]]) prop('Garden detail', id + 1, x * 16, y * 16);
const stationSpecs = [
  ['cultivation','Cultivo',4,3,9,4,8,8,'#37654d'],
  ['weather','Energia',19,3,7,5,22,9,'#ab813d'],
  ['processing','Processamento',22,11,7,4,25,16,'#955b42'],
  ['recovery','Recuperação',3,11,6,4,7,16,'#447d84'],
  ['delivery','Expedição',13,14,6,3,16,18,'#a27537']
];
const stations = stationSpecs.map(([id,name,x,y,w,h,px,py,color]) => ({
  id: nextObjectId++, name, type: 'station', x:x*16, y:y*16, width:w*16, height:h*16, rotation:0, visible:true,
  properties:[{name:'stationId',type:'string',value:id},{name:'color',type:'color',value:color}]
}));
const interactions = stationSpecs.map(([id,name,x,y,w,h,px,py]) => ({
  id: nextObjectId++, name:`${name}: arrival`, type:'arrival', x:(px+.5)*16, y:(py+.5)*16, point:true, rotation:0, visible:true,
  properties:[{name:'stationId',type:'string',value:id}]
}));
const bounds = [[0,0,16,336],[0,0,512,16],[480,0,32,336],[0,320,512,16]].map(([x,y,w,h]) => ({id:nextObjectId++,name:'Farm boundary',type:'boundary',x,y,width:w,height:h,rotation:0,visible:true}));
const layer = (id,name,data) => ({id,name,type:'tilelayer',x:0,y:0,width,height,data,opacity:1,visible:true});
const objects = (id,name,objects,color,visible=true) => ({id,name,type:'objectgroup',x:0,y:0,objects,opacity:1,visible,color,draworder:'topdown'});
const map = {compressionlevel:-1,height,width,infinite:false,nextlayerid:9,nextobjectid:nextObjectId,orientation:'orthogonal',renderorder:'right-down',tiledversion:'1.12.2',tileheight:16,tilewidth:16,type:'map',version:'1.10',backgroundcolor:'#639a9b',
  properties:[{name:'worldScale',type:'int',value:2},{name:'notes',type:'string',value:'Kenney Tiny Town/Farm CC0 terrain. Station rectangles are collision footprints and drive runtime structure placement. Scenery is visual only. Arrival points drive routes.'}],
  layers:[layer(1,'Ground',ground),layer(2,'Paths',pathTiles),layer(3,'Ground details',detail),objects(4,'Scenery',scenery,'#ccac74'),objects(5,'Stations',stations,'#517d74'),objects(6,'Interactions',interactions,'#dca74d'),objects(7,'Boundary',bounds,'#b95f50',false)],
  tilesets:[{firstgid:1,source:'tiny-town.tsj'},{firstgid:133,source:'tiny-farm.tsj'}]};
for (const name of ['town','farm']) {
  const set={columns:12,image:`../../assets/vendor/kenney-tiny-${name}/Tilemap/tilemap_packed.png`,imageheight:176,imagewidth:192,margin:0,name:`Kenney Tiny ${name === 'town' ? 'Town' : 'Farm'}`,spacing:0,tilecount:132,tiledversion:'1.12.2',tileheight:16,tilewidth:16,type:'tileset',version:'1.10'};
  fs.writeFileSync(path.join(out,`tiny-${name}.tsj`),JSON.stringify(set,null,2)+'\n');
}
fs.writeFileSync(path.join(out,'algae-farm.tmj'),JSON.stringify(map,null,2)+'\n');
console.log('Created editable Tiled map and two Kenney tilesets.');
