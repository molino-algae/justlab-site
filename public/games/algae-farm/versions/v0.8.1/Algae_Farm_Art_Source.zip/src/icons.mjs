// Original line icons shared by the game interface. No font or network request.
const UI_ICON_PATHS = Object.freeze({
  culture: '<path d="M19 4C10 3 4 7 5 14c1 7 10 7 13 1 2-4 1-8 1-11Z"/><path d="m7 18 9-10M9 13l4 1M12 10l-1-3"/>',
  biodiesel: '<path d="M12 3C10 7 5 11 5 15a7 7 0 0 0 14 0c0-4-5-8-7-12Z"/><path d="M9 17c2-5 6-5 7-6-1 5-3 7-7 6Z"/>',
  material: '<path d="m4 8 8-4 8 4-8 4-8-4Zm0 4 8 4 8-4M4 16l8 4 8-4"/>',
  cultivation: '<rect x="3" y="5" width="18" height="14" rx="5"/><path d="M7 9h10v6H7zM12 5v4m0 6v4"/>',
  weather: '<path d="m13 2-8 12h7l-1 8 8-12h-7l1-8Z"/>',
  processing: '<path d="M8 3h8M10 3v6l-6 9a2 2 0 0 0 2 3h12a2 2 0 0 0 2-3l-6-9V3M8 15h8"/>',
  recovery: '<path d="m17 4 3 4-5 1M20 8a8 8 0 0 0-14-2M7 20l-3-4 5-1M4 16a8 8 0 0 0 14 2"/><path d="M12 8c-2 3-3 4-3 6a3 3 0 0 0 6 0c0-2-1-3-3-6Z"/>',
  delivery: '<path d="m3 7 9-4 9 4-9 4-9-4ZM3 7v10l9 4 9-4V7M12 11v10M7 5l10 5"/>',
  upgrade: '<path d="m5 10 7-7 7 7M12 3v13M4 20h16"/>',
  coins: '<ellipse cx="10" cy="7" rx="7" ry="3"/><path d="M3 7v5c0 2 3 3 7 3M3 11v5c0 2 3 3 7 3"/><ellipse cx="16" cy="16" rx="5" ry="5"/><path d="M16 14v4"/>',
  book: '<path d="M4 4h7v16H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2ZM13 4h7a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-7V4Z"/><path d="M6 8h2M16 8h2M6 12h2M16 12h2"/>',
  scan: '<path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/><circle cx="12" cy="12" r="4"/><path d="M12 6v2M12 16v2M6 12h2M16 12h2"/>',
  check: '<path d="m5 12 5 5L20 6"/>',
  arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>'
});

export function uiIcon(name) {
  const paths = UI_ICON_PATHS[name] || UI_ICON_PATHS.culture;
  return `<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
}

export function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach(node => {node.innerHTML = uiIcon(node.dataset.icon);});
}
