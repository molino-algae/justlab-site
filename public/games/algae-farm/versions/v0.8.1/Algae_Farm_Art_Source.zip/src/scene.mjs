// Art is authored at 16 px per tile and shown at 2x in the 32 px game world.
// The embedded data comes directly from the editable Tiled map and tilesets.
import {SECRETS} from './secrets.mjs';
const WORLD_W = 1024, WORLD_H = 672;
const INK = '#284f4b', LIGHT = '#f7f5df';

function tileInfo(gid) {
  if (!gid) return null;
  const ref = [...SCENE_MAP.tilesets].reverse().find(t => gid >= t.firstgid);
  if (!ref) return null;
  const key = ref.source.includes('town') ? 'town' : 'farm';
  const set = SCENE_TILESETS[key];
  return {key, set, index: gid - ref.firstgid};
}

function tile(c, world, gid, x, y, width = 32, height = 32) {
  const info = tileInfo(gid); if (!info) return;
  const image = world.images[info.key]; if (!image?.naturalWidth) return;
  const {set, index} = info, margin = set.margin || 0, gap = set.spacing || 0;
  const sx = margin + index % set.columns * (set.tilewidth + gap);
  const sy = margin + Math.floor(index / set.columns) * (set.tileheight + gap);
  c.drawImage(image, sx, sy, set.tilewidth, set.tileheight, Math.round(x), Math.round(y), width, height);
}

// The campus surface, original lab machinery and water effects use the same
// world coordinates as the editable Tiled map. They never alter collision data.
export function cacheSceneGround(world) {
  const surface = document.createElement('canvas'); surface.width = WORLD_W; surface.height = WORLD_H;
  const c = surface.getContext('2d'); c.imageSmoothingEnabled = false;
  rect(c, 0, 0, WORLD_W, WORLD_H, '#9fbe72');
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'tilelayer' && l.name !== 'Paths' && l.visible !== false)) {
    layer.data.forEach((gid, i) => tile(c, world, gid, i % layer.width * 32, Math.floor(i / layer.width) * 32));
  }
  // Keep the untinted Kenney grass in full daylight. Pale service surfaces
  // define the experimental campus without changing the map's geometry.
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'tilelayer' && l.name === 'Paths' && l.visible !== false)) {
    const occupied = (x, y) => x >= 0 && y >= 0 && x < layer.width && y < layer.height && layer.data[y * layer.width + x];
    layer.data.forEach((gid, i) => {
      if (!gid) return;
      const tx = i % layer.width, ty = Math.floor(i / layer.width), x = tx * 32, y = ty * 32;
      rect(c, x, y, 32, 32, '#b9c9b8');
      rect(c, x + 1, y + 1, 31, 31, '#d0dac8');
      rect(c, x + 2, y + 2, 29, 1, '#edf0dd');
      rect(c, x + 31, y, 1, 32, '#adbfae');
      rect(c, x, y + 31, 32, 1, '#adbfae');
      if (!occupied(tx, ty - 1)) {rect(c, x, y, 32, 3, '#a0b7a5');rect(c, x + 3, y, 25, 1, '#f4f3df');}
      if (!occupied(tx, ty + 1)) rect(c, x, y + 29, 32, 3, '#a0b7a5');
      if (!occupied(tx - 1, ty)) rect(c, x, y, 3, 32, '#a0b7a5');
      if (!occupied(tx + 1, ty)) rect(c, x + 29, y, 3, 32, '#a0b7a5');
      if ((tx + ty) % 4 === 0) rect(c, x + 12, y + 14, 7, 3, '#f2f1dc88');
    });
  }
  // Inset service pads make each process area legible at the full-map scale.
  for (const [id, station] of Object.entries(STATIONS)) {
    const x = station.x * 32, y = station.y * 32, w = station.w * 32, h = station.h * 32;
    panel(c, x - 10, y - 12, w + 20, h + 24, '#8ca7a0', 8);
    panel(c, x - 7, y - 9, w + 14, h + 17, '#d8e1ce', 6);
    for (let xx = 0; xx < w + 10; xx += 32) rect(c, x - 5 + xx, y - 7, 1, h + 11, '#a5bdae70');
    for (let yy = 0; yy < h + 10; yy += 32) rect(c, x - 5, y - 7 + yy, w + 10, 1, '#a5bdae70');
    rect(c, x - 5, y + h + 4, w + 10, 2, id === 'recovery' ? '#62a4b3' : '#65b1a6');
    for (let i = 0; i < 4; i++) rect(c, x + 5 + i * 10, y + h + 5, 5, 3, '#b6c393');
    const px = (station.point[0] + .5) * 32, py = (station.point[1] + .5) * 32;
    panel(c, px - 16, py - 12, 32, 24, '#c2d4bb', 4);
    rect(c, px - 9, py - 1, 18, 2, '#5c9477');
  }
  rect(c, 960, 0, 64, WORLD_H, '#79b8c2');
  rect(c, 960, 0, 5, WORLD_H, '#4f929c');rect(c, 966, 0, 3, WORLD_H, '#c4e3d8');
  // Small lamps and drain grates are passive campus details, not obstacles.
  for (const [x, y] of [[275,282],[594,281],[639,448],[366,566],[119,307],[888,561]]) {
    rect(c, x - 5, y - 3, 10, 5, '#355154');rect(c, x - 3, y - 3, 6, 2, '#86cdb3');
    for (let i = 0; i < 3; i++) rect(c, x - 3 + i * 3, y + 4, 1, 8, '#345257');
  }
  world.ground = surface;
}

function rect(c, x, y, w, h, color) {
  c.fillStyle = color;c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}
function panel(c, x, y, w, h, color, radius = 5) {
  const r = Math.min(radius, w / 2, h / 2);
  c.beginPath();c.moveTo(x + r, y);c.lineTo(x + w - r, y);c.quadraticCurveTo(x + w, y, x + w, y + r);
  c.lineTo(x + w, y + h - r);c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  c.lineTo(x + r, y + h);c.quadraticCurveTo(x, y + h, x, y + h - r);c.lineTo(x, y + r);c.quadraticCurveTo(x, y, x + r, y);
  c.closePath();c.fillStyle = color;c.fill();
}
function pixelPanel(c, x, y, w, h, color, corner = 4) {
  rect(c, x + corner, y, w - corner * 2, h, color);rect(c, x, y + corner, w, h - corner * 2, color);
}
function shadow(c, x, y, w, h = 14) {
  panel(c, x + 5, y + 5, w, h, '#365b4d30', 7);
}
function metal(c, x, y, w, h, tint = '#d9e4d9') {
  panel(c, x, y + 4, w, h, '#72968e', 5);
  const fill = c.createLinearGradient(x, y, x + w, y + h);
  fill.addColorStop(0, tint);fill.addColorStop(.42, '#c7d9ce');fill.addColorStop(1, '#91ada6');
  panel(c, x, y, w, h, fill, 5);
  rect(c, x + 5, y + 2, w - 10, 2, '#e2f3e6aa');
  rect(c, x + 3, y + 5, 2, h - 12, '#c6ded6aa');
  rect(c, x + w - 4, y + 5, 2, h - 10, '#2d535f');
}
function sprite(c, image, frame, row, fw, fh, x, y) {
  if (!image?.naturalWidth) return;
  c.drawImage(image, frame * fw, row * fh, fw, fh, Math.round(x), Math.round(y), fw * 2, fh * 2);
}
function farmLevel(world, id) {
  const value = world.farmUpgrades?.[id];return Number.isFinite(value) ? Math.max(0, Math.min(3, Math.floor(value))) : 0;
}
function operatingLight(c, world, x, y, t, color = '#85edb6') {
  const opacity = world.reduced ? .03 : .025 + .015 * Math.sin(t / 850);
  panel(c, x - 5, y - 5, 14, 14, `rgba(91,232,184,${opacity})`, 6);
  rect(c, x, y, 4, 4, color);rect(c, x, y, 2, 1, '#e7ffe9');
}
function feedBarrel(c, x, y, color) {
  metal(c, x, y + 2, 23, 29, '#8eafb0');
  rect(c, x + 4, y + 7, 15, 17, color);rect(c, x + 5, y + 8, 3, 14, '#d2e9cd77');
  panel(c, x - 1, y, 25, 7, '#c5d7d0', 3);rect(c, x + 1, y + 25, 21, 3, '#bed2c6');
  rect(c, x + 10, y + 11, 5, 7, '#d4e5b4');
}
function pipe(c, x, y, w, h, color = '#a5c1bd') {
  panel(c, x, y + 2, w, h, '#1b3c49', Math.min(w,h) / 3);
  panel(c, x, y, w, h, color, Math.min(w,h) / 3);
  if (w > h) rect(c, x + 3, y + 1, w - 6, 2, '#e1f1de99');
  else rect(c, x + 1, y + 3, 2, h - 6, '#e1f1de99');
}
function controller(c, world, x, y, w, h, t) {
  metal(c, x, y, w, h, '#acc9c6');panel(c, x + 5, y + 5, w - 10, Math.max(10, h * .42), '#163d48', 2);
  rect(c, x + 8, y + 8, Math.max(6, w - 20), 2, '#6be8b3');
  rect(c, x + 8, y + 13, Math.max(5, w - 25), 2, '#60b9c5');
  for (let i = 0; i < 3; i++) rect(c, x + 7 + i * 7, y + h - 9, 3, 3, i === 0 ? '#6cdbb0' : '#4a777b');
  operatingLight(c, world, x + w - 10, y + h - 9, t);
}
const CULTURE_VISUALS = {
  chlorella: {water:'#3d936a',rim:'#1b504b',reflection:'#86cd8b',shade:'#245e53',cell:'#b5de8e',glint:'#ddf7ac',cellShade:'#82bd7d'},
  nannochloropsis: {water:'#859441',rim:'#485c35',reflection:'#bfce70',shade:'#536f3b',cell:'#d4d678',glint:'#f3eaaa',cellShade:'#9eb76a'},
  tetraselmis: {water:'#328d7d',rim:'#1e595a',reflection:'#78c7a1',shade:'#27655f',cell:'#b3e3b0',glint:'#e0f7c4',cellShade:'#7ac6ae'}
};
function cultureCells(c, world, x, y, w, t, row, culture) {
  const species = world.speciesId || 'chlorella', span = w - 48;
  // Enlarged illustrative cell forms stay in the two water lanes, clear of the island.
  for (let lane = 0; lane < 2; lane++) for (let i = 0; i < Math.floor(span / 31); i++) {
    const drift = world.reduced ? 0 : t / 180 * (lane === row ? 1 : -1);
    const xx = x + 18 + ((i * 31 + row * 11 + lane * 13 + drift) % span + span) % span;
    const yy = y + (lane ? 32 : 16) + i % 2;
    if (species === 'nannochloropsis') {
      // Small green-gold dots contrast with the larger round starter cells.
      rect(c, xx + 1, yy + 1, 2, 3, culture.cell);
      rect(c, xx, yy + 2, 3, 1, culture.cell);
      rect(c, xx + 6, yy + 3, 2, 2, culture.glint);
      if (i % 2) rect(c, xx + 10, yy, 2, 2, culture.cellShade);
    } else if (species === 'tetraselmis') {
      pixelPanel(c, xx, yy + 1, 10, 4, culture.cell, 1);
      rect(c, xx + 2, yy + 1, 4, 1, culture.glint);
      rect(c, xx + 4, yy + 4, 4, 1, culture.cellShade);
      rect(c, xx - 3, yy + 2, 3, 1, culture.cellShade);
    } else {
      pixelPanel(c, xx, yy, 6, 6, culture.cell, 2);
      rect(c, xx + 2, yy + 1, 2, 2, culture.glint);
      rect(c, xx + 2, yy + 4, 2, 1, culture.cellShade);
    }
  }
}


function pond(c, world, x, y, w, t, row) {
  const culture = CULTURE_VISUALS[world.speciesId] || CULTURE_VISUALS.chlorella;
  shadow(c, x - 2, y + 49, w + 2, 17);
  panel(c, x - 2, y, w + 4, 59, '#1b3a49', 14);
  metal(c, x, y - 3, w, 55, '#b2cbc7');
  panel(c, x + 8, y + 3, w - 16, 42, culture.rim, 14);
  const fill = c.createLinearGradient(0, y + 5, 0, y + 44);
  fill.addColorStop(0, culture.reflection);fill.addColorStop(.22, culture.water);fill.addColorStop(1, culture.shade);
  panel(c, x + 11, y + 6, w - 22, 36, fill, 12);
  panel(c, x + 45, y + 20, w - 90, 10, '#a9bbb0', 5);
  rect(c, x + 52, y + 21, w - 104, 2, '#e7efdc');
  cultureCells(c, world, x, y - 2, w, t, row, culture);
  // Narrow traveling streaks suggest circulation without obscuring cell silhouettes.
  for (let i = 0; i < 5; i++) {
    const progress = world.reduced ? i * 37 : (t / 95 + i * 43) % (w - 62);
    const xx = x + 24 + progress;
    rect(c, xx, y + 11, 10, 1, '#daf5cb66');
    rect(c, x + w - 24 - progress, y + 34, 8, 1, '#a0dfbb66');
  }
  rect(c, x + 19, y + 47, w - 38, 2, '#6dd3bd');
  for (let i = 0; i < w - 26; i += 25) rect(c, x + 13 + i, y + 49, 14, 2, '#4d777c');
  const frame = world.reduced ? 0 : Math.floor(t / 125) % 6;
  for (const offset of [17, w - 47]) {
    sprite(c, world.images.aerator, frame, 0, 16, 16, x + offset, y + 7);
    for (let j = 0; j < 4; j++) {
      const progress = world.reduced ? .45 : (t / 1050 + j / 4 + row / 2) % 1;
      c.globalAlpha = .8 - progress * .55;
      panel(c, x + offset + 17 + (j - 1.5) * 5, y + 32 - progress * 18, 2, 2, '#e4ffdc', 1);
      c.globalAlpha = 1;
    }
  }
}
function cultivation(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32;
  const level = farmLevel(world,'cultivation'), pondWidth = w - (level >= 2 ? 58 : 0);
  pipe(c,x + pondWidth - 6,y + 20,17,79);
  pond(c,world,x,y,pondWidth,t,0);pond(c,world,x,y + 66,pondWidth,t + 250,1);
  controller(c,world,x + w - (level >= 2 ? 48 : 58),y + 102,level >= 2 ? 42 : 54,28,t);
  if (level >= 1) {
    pipe(c,x + w - 10,y + 18,6,82);
    pipe(c,x + w - 48,y + 98,44,5);
    rect(c,x + w - 43,y + 91,26,4,'#4fd5ba');
  }
  if (level >= 2) {
    metal(c,x + w - 53,y,51,95,'#547d83');
    feedBarrel(c,x + w - 44,y + 9,'#6cac72');
    feedBarrel(c,x + w - 44,y + 53,'#a4ac57');
    pipe(c,x + pondWidth - 3,y + 22,30,5);pipe(c,x + pondWidth - 3,y + 88,30,5);
  }
  if (level === 3) {
    pipe(c,x + 28,y + 57,pondWidth - 22,6);
    for (let i=0;i<4;i++) {
      const xx=x + 38 + i * 46;pipe(c,xx,y + 53,5,15);operatingLight(c,world,xx,y + 58,t + i * 190);
    }
  }
  panel(c,x + 10,y - 13,69,13,'#f0f3de',3);
  c.fillStyle='#376b53';c.font='600 8px system-ui';c.textAlign='center';c.fillText('CULTURA VIVA',x + 44,y - 4);
}
function phototube(c, world, x, y, w, h, t, light, index) {
  shadow(c,x,y + h - 4,w,7);
  metal(c,x - 1,y - 4,w + 2,9,'#b6cfcb');
  const glass=c.createLinearGradient(x,y,x + w,y);
  glass.addColorStop(0,'#9cdec18c');glass.addColorStop(.2,'#bee7ba99');glass.addColorStop(.5,light ? '#afea84':'#72bd86');glass.addColorStop(.82,'#378c6a');glass.addColorStop(1,'#80c4bdaa');
  panel(c,x,y,w,h,glass,7);rect(c,x + 3,y + 7,3,h - 14,'#d7f5dc99');
  rect(c,x + w - 5,y + 7,2,h - 14,'#174f5266');
  for(let i=0;i<4;i++) {
    const v=world.reduced ? (i + 1) / 5 : (t / 2100 + i / 4 + index * .13) % 1;
    panel(c,x + 7 + i % 2 * (w - 14),y + h - 9 - v * (h - 17),2,3,'#d7ffd3aa',1);
  }
  metal(c,x - 2,y + h - 5,w + 4,9,'#adc8c0');
  if(light) {rect(c,x - 4,y + 8,2,h - 18,'#d4f59d');rect(c,x + w + 2,y + 8,2,h - 18,'#d4f59d');}
}
function greenhouse(c, world, s, t) {
  const x=s.x * 32,y=s.y * 32,w=s.w * 32,h=s.h * 32,light=world.led;
  shadow(c,x - 1,y + h - 9,w,18);
  metal(c,x,y + 18,w,h - 23,'#c1d8cf');
  panel(c,x + 7,y + 25,w - 14,h - 39,'#a7c9bc',4);
  const glow=c.createLinearGradient(0,y + 26,0,y + h - 12);
  glow.addColorStop(0,light ? '#c8ecaa44':'#d3ebc733');glow.addColorStop(1,'#d7e6ca00');
  rect(c,x + 7,y + 27,w - 14,h - 41,glow);
  for(let i=0;i<5;i++) phototube(c,world,x + 15 + i * 40,y + 40,28,86,t,light,i);
  pipe(c,x + 8,y + 30,w - 16,7);pipe(c,x + 9,y + 129,w - 18,7);
  for(let i=0;i<6;i++) {
    const xx=x + 7 + i * 41;rect(c,xx,y + 16,4,h - 25,'#b0d0cb');rect(c,xx + 1,y + 18,1,h - 32,'#e5f3df');
  }
  // A sunlit glazed roof, with structural ribs and directional reflections.
  panel(c,x + 4,y + 2,w - 8,25,'#c6e6d499',6);
  rect(c,x + 12,y + 4,w - 24,3,'#ffffe5cc');
  for(let i=0;i<5;i++) {rect(c,x + 20 + i * 41,y + 8,24,2,'#d1eed455');rect(c,x + 11 + i * 41,y + 3,3,23,'#bfdcd1');}
  rect(c,x - 3,y + 24,w + 6,5,'#c9ded3');rect(c,x - 2,y + h - 12,w + 4,8,'#9fb9b2');
  controller(c,world,x + w - 43,y + h - 36,34,23,t);
  rect(c,x + 10,y + h - 8,93,3,light ? '#d6ee8a':'#55c5aa');
  c.fillStyle='#315f4d';c.font='600 8px system-ui';c.textAlign='left';c.fillText(light ? 'LEDs ATIVOS' : 'FOTOBIORREATORES',x + 13,y + h - 17);
}
function vessel(c, world, x, y, w, h, t, fluid = '#75bc84') {
  shadow(c,x,y + h - 4,w,11);metal(c,x,y,w,h,'#c1d4cc');
  panel(c,x - 2,y - 3,w + 4,13,'#bdd4cb',7);rect(c,x + 7,y - 1,w - 14,2,'#e5f0d9');
  rect(c,x + 5,y + 23,w - 10,3,'#dae8d3');rect(c,x + 5,y + h - 19,w - 10,3,'#dae8d3');
  panel(c,x + w / 2 - 4,y + 24,9,h - 47,'#183f4b',3);
  rect(c,x + w / 2 - 1,y + 28,3,h - 55,fluid);
  const v=world.reduced ? .45 : (t / 1600) % 1;
  rect(c,x + w / 2,y + h - 30 - v * (h - 58),2,3,'#e3ffd5');
  rect(c,x + 5,y + h - 1,5,9,'#264d5b');rect(c,x + w - 11,y + h - 1,5,9,'#264d5b');
}
function processing(c, world, s, t) {
  const x=s.x * 32,y=s.y * 32,w=s.w * 32,h=s.h * 32,level=farmLevel(world,'processing');
  shadow(c,x - 5,y + h - 6,w + 8,20);
  metal(c,x,y + 12,w,h - 18,'#bfd4ce');
  panel(c,x + 7,y + 20,w - 14,h - 34,'#a9c2b8',5);
  pipe(c,x + 16,y + 19,w - 30,8);
  for(let i=0;i<3;i++) {
    const xx=x + 14 + i * 57;vessel(c,world,xx,y + 29,43,68,t + i * 400,i === 1 ? '#e4bf76':'#91c994');
    pipe(c,xx + 18,y + 15,7,17);pipe(c,xx + 38,y + 78,17,6);
  }
  rect(c,x + 7,y + 107,w - 14,4,'#85b1aa');
  controller(c,world,x + w - 42,y + 47,34,48,t);
  // The front bay becomes a visible process skid as the farm invests.
  if(level >= 1) {
    metal(c,x + 14,y + 98,82,23,'#92b0b3');
    for(let i=0;i<4;i++) {rect(c,x + 20 + i * 16,y + 104,11,9,'#244b57');rect(c,x + 22 + i * 16,y + 105,6,2,'#6cd3bb');}
  } else {for(let i=0;i<5;i++) rect(c,x + 17 + i * 7,y + 108,3,9,'#467b84');}
  if(level >= 2) {
    metal(c,x + 99,y + 100,49,22,'#a4c5be');
    rect(c,x + 105,y + 106,36,8,'#28545d');
    for(let i=0;i<5;i++) rect(c,x + 108 + i * 6,y + 107,2,6,'#83b1a9');
    pipe(c,x + w - 10,y + 8,5,86);
  }
  if(level === 3) {
    controller(c,world,x + 154,y + 98,56,26,t + 400);
    pipe(c,x + 13,y + 4,w - 26,5);rect(c,x + 18,y + 4,w - 36,1,'#83e9c5');
  }
  if(['recovery','delivery','results'].includes(world.phase)) crate(c,x + 105,y + 98,true);
}
function recovery(c, world, s, t) {
  const x=s.x * 32,y=s.y * 32,level=farmLevel(world,'recovery');
  pipe(c,x + 39,y + 89,110,10);pipe(c,x + 141,y + 76,8,40);
  vessel(c,world,x + 9,y + 11,70,100,t,'#70c5d0');
  vessel(c,world,x + 117,y + (level >= 2 ? 14:36),62,level >= 2 ? 97:75,t + 400,'#73d2c8');
  controller(c,world,x + 77,y + 92,37,28,t);
  if(level >= 1) {feedBarrel(c,x + 88,y + 48,'#77bac0');pipe(c,x + 98,y + 75,6,18);}
  if(level >= 2) {rect(c,x + 143,y + 35,8,50,'#1b515d');rect(c,x + 146,y + 38,2,44,'#a2eee1');}
  if(level === 3) {
    metal(c,x + 86,y + 11,27,68,'#c0d5c5');
    for(let i=0;i<5;i++) {rect(c,x + 91,y + 20 + i * 10,17,5,'#4a7b80');rect(c,x + 94,y + 21 + i * 10,10,1,'#a6d9c7');}
    pipe(c,x + 40,y + 4,109,6);pipe(c,x + 98,y + 5,6,10);
  }
}
function crate(c, x, y, product=false) {
  metal(c,x,y,28,23,'#a3b8ae');rect(c,x + 3,y + 7,22,2,'#48717b');rect(c,x + 3,y + 16,22,2,'#48717b');
  rect(c,x + 11,y + 3,7,5,'#dce9c9');
  if(product) {rect(c,x + 10,y - 5,9,11,'#8abe91');rect(c,x + 12,y - 8,5,4,'#d4e9c5');}
}
function delivery(c,s) {
  const x=s.x * 32,y=s.y * 32,w=s.w * 32;
  shadow(c,x,y + 82,w,17);metal(c,x,y + 11,w,78,'#cfdfd0');
  panel(c,x + 11,y + 33,w - 22,48,'#b1c9bc',3);
  rect(c,x + 11,y + 34,4,48,'#bad0c6');rect(c,x + w - 15,y + 34,4,48,'#bad0c6');
  metal(c,x - 6,y + 4,w + 12,30,'#d6e4da');
  // Solar canopy and clearly defined dispatch bay replace the market awning.
  for(let i=0;i<6;i++) {
    panel(c,x + 5 + i * 31,y + 8,27,18,'#1e4e62',2);
    rect(c,x + 8 + i * 31,y + 10,20,1,'#81bbc4');rect(c,x + 18 + i * 31,y + 10,1,13,'#679ba8');
  }
  rect(c,x + 4,y + 86,w - 8,5,'#bed0ba');
  for(let i=0;i<10;i++) rect(c,x + 8 + i * 18,y + 86,8,5,i % 2 ? '#b8b774':'#314e57');
  crate(c,x + 21,y + 53,true);crate(c,x + 53,y + 52,true);crate(c,x + 84,y + 54);
  panel(c,x + 130,y + 49,40,25,'#2b6269',3);rect(c,x + 135,y + 55,26,3,'#80c7b3');rect(c,x + 135,y + 63,16,3,'#b9dfb4');
}
function stationLabel(c,world,id,s,t) {
  const x=(s.x + s.w/2)*32,y=s.y*32 - 40,active=id===world.active;
  const done=world.completedStations?.has(id),width=Math.max(126,s.name.length*7+55);
  const number={cultivation:'01',weather:'02',processing:'03',recovery:'04',delivery:'05'}[id];
  shadow(c,x-width/2,y+15,width,9);
  panel(c,x-width/2-1,y-1,width+2,28,active ? '#338e73':'#8da99b',5);
  panel(c,x-width/2,y,width,26,active ? '#f1f7df':'#f7f6e8',4);
  rect(c,x-width/2+7,y+6,3,14,done ? '#689447':active ? '#2d9a77':'#8ba798');
  c.font='600 9px system-ui';c.fillStyle=active ? '#286a54':'#678371';c.textAlign='left';c.fillText(number,x-width/2+16,y+17);
  c.font='600 12px system-ui';c.fillStyle='#294f45';c.fillText(s.name,x-width/2+35,y+17);
  if(done) {c.font='bold 11px system-ui';c.fillStyle='#4e813d';c.fillText('✓',x+width/2-14,y+17);}
  const level=farmLevel(world,id);
  if(level) {
    const bx=x+width/2+5;panel(c,bx,y+3,26,20,'#dfeacd',3);rect(c,bx+3,y+4,20,1,'#faf7df');
    c.fillStyle='#386b45';c.font='600 10px system-ui';c.textAlign='center';c.fillText(['','I','II','III'][level],bx+13,y+17);
  }
  if(active && world.enabled) {
    const px=(s.point[0]+.5)*32,py=(s.point[1]+.5)*32;
    const lift=world.reduced ? 0:Math.sin(t/520)*2;
    c.strokeStyle='#217c65';c.lineWidth=2;c.beginPath();c.ellipse(px,py+4,15,6,0,0,Math.PI*2);c.stroke();
    c.fillStyle='#287e5b';c.beginPath();c.moveTo(px,py-12+lift);c.lineTo(px-5,py-18+lift);c.lineTo(px+5,py-18+lift);c.closePath();c.fill();
  }
}
function fieldPlaque(c, world) {
  const {x, y} = SECRETS.find(secret => secret.id === 'eel');
  const logo = world.images.eelLogo;
  if (!world.discoveredSecrets?.has('eel')) {
    // Before discovery this is a small weathered detail in the grass.
    rect(c, x - 10, y + 11, 20, 3, '#304f4925');
    rect(c, x - 2, y + 7, 4, 10, '#788268');
    pixelPanel(c, x - 12, y - 10, 24, 18, '#7d896d', 2);
    rect(c, x - 10, y - 8, 20, 14, '#b1b59a');
    if (logo?.naturalWidth) {
      const fit = Math.min(18 / logo.naturalWidth, 12 / logo.naturalHeight);
      const width = logo.naturalWidth * fit, height = logo.naturalHeight * fit;
      c.save(); c.globalAlpha = .55;
      c.drawImage(logo, Math.round(x - width / 2), Math.round(y - 1 - height / 2), width, height);
      c.restore();
    }
    return;
  }
  shadow(c, x - 24, y + 20, 44, 9);
  rect(c, x - 18, y + 13, 5, 18, '#6a6846'); rect(c, x + 13, y + 13, 5, 18, '#6a6846');
  pixelPanel(c, x - 25, y - 23, 50, 39, '#6b775b', 3);
  pixelPanel(c, x - 23, y - 21, 46, 35, '#c3b98a', 2);
  rect(c, x - 21, y - 19, 42, 30, '#e8e2c5');
  rect(c, x - 23, y + 12, 46, 2, '#a59c72');
  rect(c, x - 21, y - 20, 4, 2, '#eee7ca'); rect(c, x + 17, y + 9, 3, 2, '#c8c3a3');
  if (logo?.naturalWidth) {
    // Fit the whole official image; retain its aspect ratio and all lettering.
    const fit = Math.min(39 / logo.naturalWidth, 26 / logo.naturalHeight);
    const width = logo.naturalWidth * fit, height = logo.naturalHeight * fit;
    c.drawImage(logo, Math.round(x - width / 2), Math.round(y - 4 - height / 2), width, height);
  }
}

function discoveredMarkers(c, world, t) {
  for (const secret of SECRETS) {
    if (!world.discoveredSecrets?.has(secret.id)) continue;
    const x = secret.x + 21, y = secret.y - 17 + (world.reduced ? 0 : Math.round(Math.sin(t / 480 + secret.x) * 2));
    rect(c, x - 1, y - 4, 2, 9, '#f5dfa0'); rect(c, x - 4, y - 1, 8, 2, '#f5dfa0');
    rect(c, x - 1, y - 1, 2, 2, '#fff3c5');
  }
}


function atmosphere(c,world,t) {
  const mix=world.reduced ? (world.cloudy ? Math.max(0,Math.min(1.5,world.weatherIntensity ?? 1)):0):world.weatherMix;
  if(!mix)return;
  rect(c,0,0,WORLD_W,WORLD_H,`rgba(86,115,122,${mix*.045})`);
  for(let i=0;i<3;i++) {
    const x=world.reduced ? i*360-60:(t/60+i*410)%1450-280,y=45+i*172;
    panel(c,x,y+30,230,54,`rgba(76,105,104,${mix*.035})`,24);
    panel(c,x+35,y+12,154,68,`rgba(76,105,104,${mix*.025})`,22);
  }
  c.globalAlpha=Math.min(.72,mix*.55);
  for(let i=0;i<3;i++) {
    const x=world.reduced ? i*400:(t/100+i*400)%1350-170,y=2+i%2*17;
    panel(c,x,y+14,125,22,'#c4d8cd',11);panel(c,x+11,y+5,103,25,'#e3ecdb',12);panel(c,x+34,y-3,47,24,'#fbfae7',13);
  }
  c.globalAlpha=1;
}
function sceneNavigation(c,world,t) {
  for(const[id,s]of Object.entries(STATIONS)) {
    const active=id===world.active,hover=id===world.hoverStation;
    if(!active&&!hover)continue;
    const x=s.x*32-8,y=s.y*32-10,w=s.w*32+16,h=s.h*32+20;
    const color=active ? '#32886e':'#6d9e89';
    c.save();c.globalAlpha=active ? .9:.65;
    for(const[px,py,dx,dy]of [[x,y,1,1],[x+w,y,-1,1],[x,y+h,1,-1],[x+w,y+h,-1,-1]]) {
      rect(c,dx>0?px:px-16,py,16,2,color);rect(c,px,dy>0?py:py-12,2,12,color);
    }
    c.restore();
  }
  if(world.path.length) {
    for(let i=1;i<world.path.length;i+=2) {
      const p=world.path[i];panel(c,p.x-3,p.y-2,6,4,'#4a8c6dcc',2);
    }
  }
  const destination=world.destination;
  if(destination && world.enabled) {
    const a=world.reduced ? 0:(t-destination.startedAt)/600;
    const radius=world.reduced ? 14:12+Math.sin(a)*2;
    c.strokeStyle='#2e8269';c.lineWidth=1.5;c.beginPath();c.ellipse(destination.x,destination.y+3,radius,radius*.45,0,0,Math.PI*2);c.stroke();
    rect(c,destination.x-1,destination.y-7,2,5,'#315f4c');
  }
}
function sceneFeedback(c,world,t) {
  // World owns the short-lived feedback clock. It never changes the simulation.
  const feedback=world.feedback;if(!feedback)return;
  const s=STATIONS[feedback.station];if(!s)return;
  const elapsed=Math.max(0,t-feedback.startedAt),duration=feedback.duration||1100;
  if(elapsed>duration)return;
  const x=(s.point[0]+.5)*32,y=(s.point[1]+.5)*32;
  const age=world.reduced ? .25:elapsed/duration;
  c.save();c.globalAlpha=world.reduced ? .95:1-age;
  c.strokeStyle=feedback.kind==='sale' ? '#b68c36':'#3a9168';c.lineWidth=2;
  c.beginPath();c.ellipse(x,y+2,15+age*23,7+age*9,0,0,Math.PI*2);c.stroke();
  panel(c,x-12,y-46-(world.reduced?0:age*9),24,24,'#f6f7e3',6);
  c.fillStyle=feedback.kind==='sale' ? '#a57623':'#37774a';c.font='bold 15px system-ui';c.textAlign='center';c.fillText(feedback.kind==='sale' ? '+':'✓',x,y-28-(world.reduced?0:age*9));
  c.restore();
}
export function drawFarmScene(world,t) {
  const c=world.ctx,w=world.width||WORLD_W,h=world.height||560,scale=world.scale||1;
  if(world.camX===undefined)world.updateCamera?.(0,true);
  c.setTransform(world.dpr||1,0,0,world.dpr||1,0,0);c.clearRect(0,0,w,h);
  rect(c,0,0,w,h,'#a5c98b');
  if(!world.artReady) {c.fillStyle=INK;c.font='14px system-ui';c.textAlign='center';c.fillText('Preparando a fazenda…',w/2,h/2);return;}
  c.save();c.imageSmoothingEnabled=false;c.scale(scale,scale);c.translate(-(world.camX||0),-(world.camY||0));
  if(world.ground)c.drawImage(world.ground,0,0);
  const clock=world.reduced ? 0:t;
  for(let i=0;i<16;i++)rect(c,971+i%2*24+(clock/180+i*5)%9,17+i*42,13,1,'#a8e4d06b');
  sceneNavigation(c,world,t);
  const things=[];
  things.push({depth:199,draw:()=>fieldPlaque(c,world)});
  for(const layer of SCENE_MAP.layers.filter(l=>l.type==='objectgroup'&&l.name==='Scenery')) {
    for(const o of layer.objects)if(o.gid) {
      const properties=Object.fromEntries((o.properties||[]).map(p=>[p.name,p.value]));
      things.push({depth:(properties.footY??o.y)*2,draw:()=>{
        if(properties.castShadow!==false)shadow(c,o.x*2,o.y*2-9,o.width*2,12);
        tile(c,world,o.gid,o.x*2,(o.y-o.height)*2,o.width*2,o.height*2);
      }});
    }
  }
  for(const [id,s]of Object.entries(STATIONS))things.push({depth:(s.y+s.h)*32,draw:()=>{
    if(id==='cultivation')cultivation(c,world,s,clock);
    else if(id==='weather')greenhouse(c,world,s,clock);
    else if(id==='processing')processing(c,world,s,clock);
    else if(id==='recovery')recovery(c,world,s,clock);
    else delivery(c,s);
  }});
  things.push({depth:world.avatar.y,draw:()=>{
    const x=Math.round(world.avatar.x),y=Math.round(world.avatar.y);
    shadow(c,x-15,y-8,24,8);
    const frame=world.moving&&!world.reduced ? Math.floor(world.walkTime*8)%4:0;
    const row={down:0,left:1,right:2,up:3}[world.avatar.facing]??0;
    sprite(c,world.images.researcher,frame,row,16,24,x-16,y-46);
  }});
  things.sort((a,b)=>a.depth-b.depth).forEach(o=>o.draw());
  atmosphere(c,world,clock);discoveredMarkers(c,world,clock);
  for(const[id,s]of Object.entries(STATIONS))stationLabel(c,world,id,s,clock);
  sceneFeedback(c,world,t);
  c.restore();
}
