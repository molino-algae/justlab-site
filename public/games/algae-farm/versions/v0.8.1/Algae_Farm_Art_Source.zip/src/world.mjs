import {cacheSceneGround, drawFarmScene} from './scene.mjs';
import {SECRETS, findSecretAt} from './secrets.mjs';
export const STATIONS = {
  cultivation: {name: 'Cultivo', x: 4, y: 3, w: 9, h: 4, point: [8, 8], color: '#37654d'},
  weather: {name: 'Energia', x: 19, y: 3, w: 7, h: 5, point: [22, 9], color: '#ab813d'},
  processing: {name: 'Processamento', x: 22, y: 11, w: 7, h: 4, point: [25, 16], color: '#955b42'},
  recovery: {name: 'Recuperação', x: 3, y: 11, w: 6, h: 4, point: [7, 16], color: '#447d84'},
  delivery: {name: 'Expedição', x: 13, y: 14, w: 6, h: 3, point: [16, 18], color: '#a27537'}
};

// Tiled is the source of station footprints and route destinations. Keep the
// named defaults above as a readable reference and for isolated module use.
if (typeof SCENE_MAP !== 'undefined') {
  const properties = object => Object.fromEntries((object.properties || []).map(p => [p.name, p.value]));
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'objectgroup')) {
    for (const object of layer.objects) {
      const p = properties(object), s = STATIONS[p.stationId]; if (!s) continue;
      if (layer.name === 'Stations') Object.assign(s, {name:object.name, x:object.x/16, y:object.y/16, w:object.width/16, h:object.height/16, color:p.color || s.color});
      if (layer.name === 'Interactions') s.point = [object.x/16-.5, object.y/16-.5];
    }
  }
}

const TILE = 32, COLS = 32, ROWS = 21;

export class FarmWorld {
  constructor(canvas, onArrive, onSecret = () => {}) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d'); this.onArrive = onArrive;
    this.onSecret = onSecret; this.discoveredSecrets = new Set();
    this.avatar = {x: 8.5 * TILE, y: 8.5 * TILE, facing: 'up'};
    this.path = []; this.active = 'cultivation'; this.phase = 'cultivation'; this.targetStation = null;
    this.destination = null; this.hoverStation = null; this.feedback = null;
    this.camX = 0; this.camY = 0; this.cameraX = 0; this.cameraY = 0; this.cameraReady = false;
    this.keys = new Set(); this.moving = false; this.last = 0; this.cloudy = false; this.led = false;
    this.reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.weatherMix = 0; this.weatherIntensity = 1; this.walkTime = 0; this.images = {}; this.artReady = false;
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    motion.addEventListener('change', e => {this.reduced = e.matches; this.updateCamera(0, true);});
    Promise.all(Object.entries(SCENE_ASSETS).map(([key, source]) => new Promise(resolve => {
      const image = new Image(); this.images[key] = image;
      image.onload = resolve; image.onerror = () => {console.error(`Could not load scene asset: ${key}`); resolve();}; image.src = source;
    }))).then(() => {this.artReady = true; this.cacheGround();});
    this.resizeObserver = new ResizeObserver(() => this.resize()); this.resizeObserver.observe(canvas);
    canvas.addEventListener('pointerdown', event => this.pointer(event));
    canvas.addEventListener('pointermove', event => this.pointerHover(event));
    canvas.addEventListener('pointerleave', () => {this.hoverStation = null; canvas.style.cursor = 'default';});
    document.addEventListener('keydown', e => {
      if (e.target !== canvas || document.querySelector('dialog[open]') || !this.enabled) return;
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd'].includes(key)) {this.keys.add(key); this.path = []; this.targetStation = null; this.destination = null; e.preventDefault();}
      if (key === 'e' || key === 'Enter') {e.preventDefault(); this.interact();}
      if (key === 'f') {e.preventDefault(); if (!e.repeat) this.inspectNearby();}
    });
    document.addEventListener('keyup', e => this.keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
    canvas.addEventListener('blur', () => this.keys.clear());
    window.addEventListener('blur', () => this.keys.clear());
    requestAnimationFrame(t => this.frame(t));
  }
  resize() {
    const r = this.canvas.getBoundingClientRect();
    if (!(r.width > 0 && r.height > 0)) return;
    this.width = r.width; this.height = r.height;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(r.width * dpr); this.canvas.height = Math.round(r.height * dpr);
    this.dpr = dpr; this.scale = r.width < 620 ? r.width / 570 : Math.min(1.25, r.width / 1024);
    this.updateCamera(0, true);
  }
  updateCamera(dt, force = false) {
    const width = this.width || 1024, height = this.height || 560, scale = this.scale || 1;
    const maxX = Math.max(0, COLS * TILE - width / scale), maxY = Math.max(0, ROWS * TILE - height / scale);
    const targetX = Math.max(0, Math.min(maxX, this.avatar.x - width / scale / 2));
    const targetY = Math.max(0, Math.min(maxY, this.avatar.y - height / scale / 2));
    // New lots may reposition the avatar instantly; avoid panning across the whole farm.
    const snap = force || this.reduced || !this.cameraReady || Math.hypot(targetX - this.cameraX, targetY - this.cameraY) > 320;
    const mix = snap ? 1 : 1 - Math.exp(-Math.max(0, dt) * 8);
    this.cameraX = Math.max(0, Math.min(maxX, this.cameraX + (targetX - this.cameraX) * mix));
    this.cameraY = Math.max(0, Math.min(maxY, this.cameraY + (targetY - this.cameraY) * mix));
    this.camX = Math.round(this.cameraX); this.camY = Math.round(this.cameraY); this.cameraReady = true;
  }
  celebrate(station, kind = 'decision') {
    if (!Object.hasOwn(STATIONS, station)) return;
    this.feedback = {station, kind, startedAt: performance.now(), duration: 1100};
  }
  pointerHover(event) {
    if (!this.enabled || document.querySelector('dialog[open]')) {this.hoverStation = null; this.canvas.style.cursor = 'default'; return;}
    const rect = this.canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) / this.scale + this.camX, y = (event.clientY - rect.top) / this.scale + this.camY;
    this.hoverStation = Object.keys(STATIONS).find(id => {const s = STATIONS[id]; return x >= s.x * TILE && x < (s.x + s.w) * TILE && y >= s.y * TILE && y < (s.y + s.h) * TILE;}) || null;
    this.canvas.style.cursor = this.hoverStation || findSecretAt(x, y, this.scale) ? 'pointer' : this.blocked(Math.floor(x / TILE), Math.floor(y / TILE)) ? 'not-allowed' : 'crosshair';
  }
  blocked(x, y) {
    if (x < 1 || y < 1 || x >= 30 || y >= 20) return true;
    return Object.values(STATIONS).some(s => x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h);
  }
  route(tx, ty) {
    if (this.blocked(tx, ty)) return false;
    const sx = Math.floor(this.avatar.x / TILE), sy = Math.floor(this.avatar.y / TILE);
    const queue = [[sx, sy]], seen = new Map([[`${sx},${sy}`, null]]);
    let found = false;
    for (let i = 0; i < queue.length; i++) {
      const [x, y] = queue[i];
      if (x === tx && y === ty) {found = true; break;}
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, key = `${nx},${ny}`;
        if (!this.blocked(nx, ny) && !seen.has(key)) {seen.set(key, [x, y]); queue.push([nx, ny]);}
      }
    }
    if (!found) return false;
    const route = []; let p = [tx, ty];
    while (p) {route.push({x: (p[0] + .5) * TILE, y: (p[1] + .5) * TILE}); p = seen.get(`${p[0]},${p[1]}`);}
    this.path = route.reverse();
    this.destination = {x: (tx + .5) * TILE, y: (ty + .5) * TILE, station: this.targetStation, startedAt: performance.now()};
    return true;
  }
  goTo(id) {
    if (!this.enabled) return false;
    const s = STATIONS[id]; if (!s) return false;
    const previous = this.targetStation; this.targetStation = id;
    if (!this.route(...s.point)) {this.targetStation = previous; return false;}
    return true;
  }
  pointer(e) {
    if (!this.enabled || document.querySelector('dialog[open]')) return;
    const rect = this.canvas.getBoundingClientRect();
    const wx = (e.clientX - rect.left) / this.scale + this.camX, wy = (e.clientY - rect.top) / this.scale + this.camY;
    const s = Object.entries(STATIONS).find(([, q]) => wx >= q.x * TILE && wx < (q.x + q.w) * TILE && wy >= q.y * TILE && wy < (q.y + q.h) * TILE);
    if (s) {this.goTo(s[0]); return;}
    const secret = findSecretAt(wx, wy, this.scale);
    if (secret) {this.discoverSecret(secret.id); return;}
    this.targetStation = null; this.route(Math.floor(wx / TILE), Math.floor(wy / TILE));
  }
  discoverSecret(id) {
    this.path = []; this.targetStation = null; this.destination = null; this.keys.clear();
    this.onSecret(id);
  }
  inspectNearby() {
    if (!this.enabled || document.querySelector('dialog[open]')) return false;
    const candidates = SECRETS.filter(secret => !this.discoveredSecrets.has(secret.id))
      .map(secret => ({secret, distance: Math.hypot(secret.x - this.avatar.x, secret.y - this.avatar.y)}))
      .filter(item => item.distance <= 90).sort((a, b) => a.distance - b.distance);
    if (!candidates.length) return false;
    this.discoverSecret(candidates[0].secret.id); return true;
  }
  seekSecret(id) {
    if (!this.enabled || document.querySelector('dialog[open]')) return false;
    const secret = SECRETS.find(item => item.id === id); if (!secret) return false;
    const cx = Math.floor(secret.x / TILE), cy = Math.floor(secret.y / TILE), candidates = [];
    for (let y = cy - 2; y <= cy + 2; y++) for (let x = cx - 2; x <= cx + 2; x++) {
      if (this.blocked(x, y)) continue;
      const distance = Math.hypot((x + .5) * TILE - secret.x, (y + .5) * TILE - secret.y);
      if (distance >= 32 && distance <= 75) candidates.push({x, y, distance});
    }
    candidates.sort((a, b) => a.distance - b.distance || Math.hypot((a.x + .5) * TILE - this.avatar.x, (a.y + .5) * TILE - this.avatar.y) - Math.hypot((b.x + .5) * TILE - this.avatar.x, (b.y + .5) * TILE - this.avatar.y));
    this.targetStation = null; this.keys.clear();
    return candidates.some(point => this.route(point.x, point.y));
  }
  interact() {
    if (!this.enabled) return;
    const near = Object.entries(STATIONS).find(([, s]) => Math.hypot(this.avatar.x - (s.point[0] + .5) * TILE, this.avatar.y - (s.point[1] + .5) * TILE) < 65);
    if (near) this.onArrive(near[0]); else this.goTo(this.active);
  }
  frame(t) {
    const dt = Math.min((t - this.last) / 1000 || 0, .05); this.last = t;
    const paused = document.querySelector('dialog[open]');
    this.moving = false;
    if (this.enabled && !paused) {
      if (this.path.length) {
        const p = this.path[0], dx = p.x - this.avatar.x, dy = p.y - this.avatar.y, d = Math.hypot(dx, dy), step = dt * 165;
        this.avatar.facing = Math.abs(dx) > Math.abs(dy) ? dx > 0 ? 'right' : 'left' : dy > 0 ? 'down' : 'up';
        if (d <= step) {this.avatar.x = p.x; this.avatar.y = p.y; this.path.shift();}
        else {this.avatar.x += dx / d * step; this.avatar.y += dy / d * step;}
        this.moving = true;
        if (!this.path.length && this.targetStation) {const target = this.targetStation; this.targetStation = null; this.onArrive(target);}
      } else if (this.keys.size) {
        const dx = +(this.keys.has('d') || this.keys.has('ArrowRight')) - +(this.keys.has('a') || this.keys.has('ArrowLeft'));
        const dy = +(this.keys.has('s') || this.keys.has('ArrowDown')) - +(this.keys.has('w') || this.keys.has('ArrowUp'));
        const len = Math.hypot(dx, dy) || 1, nx = this.avatar.x + dx / len * dt * 165, ny = this.avatar.y + dy / len * dt * 165;
        if (!this.blocked(Math.floor(nx / TILE), Math.floor(this.avatar.y / TILE))) this.avatar.x = nx;
        if (!this.blocked(Math.floor(this.avatar.x / TILE), Math.floor(ny / TILE))) this.avatar.y = ny;
        this.avatar.facing = dx ? dx > 0 ? 'right' : 'left' : dy > 0 ? 'down' : 'up'; this.moving = !!(dx || dy);
      }
    }
    if (this.moving && !paused) this.walkTime += dt;
    if (!this.path.length) this.destination = null;
    if (this.feedback && t - this.feedback.startedAt >= this.feedback.duration) this.feedback = null;
    const weatherTarget = this.cloudy ? Math.max(0, Math.min(1.5, this.weatherIntensity)) : 0;
    this.weatherMix += (weatherTarget - this.weatherMix) * Math.min(1, dt * (this.reduced ? 100 : 1.3));
    this.updateCamera(dt);
    this.draw(t); requestAnimationFrame(n => this.frame(n));
  }
  cacheGround() {cacheSceneGround(this);}
  draw(t) {drawFarmScene(this, t);}
}
